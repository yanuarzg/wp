<?php $newspress_search_id = 's-' . wp_unique_id(); ?>
<form role="search" method="get" class="np-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <label class="screen-reader-text" for="<?php echo esc_attr( $newspress_search_id ); ?>"><?php esc_html_e( 'Search for:', 'newspress' ); ?></label>
    <input type="search" id="<?php echo esc_attr( $newspress_search_id ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search news...', 'newspress' ); ?>">
    <button type="submit"><?php echo newspress_icon_search(); ?><span><?php esc_html_e( 'Search', 'newspress' ); ?></span></button>
</form>
