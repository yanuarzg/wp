<?php get_header(); ?>
<?php if ( is_home() && is_paged() ) : ?>
    <?php
    $np_home_settings = function_exists( 'newspress_get_home_settings' ) ? newspress_get_home_settings() : array( 'main_rows' => 5, 'posts_per_row' => 5 );
    $np_rows          = isset( $np_home_settings['main_rows'] ) ? min( 8, max( 1, absint( $np_home_settings['main_rows'] ) ) ) : 5;
    $np_posts_per_row = isset( $np_home_settings['posts_per_row'] ) ? min( 10, max( 1, absint( $np_home_settings['posts_per_row'] ) ) ) : 5;
    $np_first_count   = max( 1, max( 0, $np_rows - 1 ) * $np_posts_per_row );
    $np_paged         = max( 2, absint( get_query_var( 'paged' ) ) );
    $np_offset        = $np_first_count + ( ( $np_paged - 2 ) * $np_posts_per_row );
    $np_published     = wp_count_posts( 'post' );
    $np_total_posts   = isset( $np_published->publish ) ? absint( $np_published->publish ) : 0;
    $np_total_pages   = 1;
    if ( $np_total_posts > $np_first_count ) {
        $np_total_pages += (int) ceil( ( $np_total_posts - $np_first_count ) / $np_posts_per_row );
    }
    $np_blog_query = new WP_Query( array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => $np_posts_per_row,
        'offset'              => $np_offset,
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
    ) );
    ?>
    <main id="primary" class="np-site-main np-home-page np-home-paged <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?>" aria-label="<?php esc_attr_e( 'Blog archive', 'newspress' ); ?>">
        <h1 class="screen-reader-text"><?php echo esc_html( get_the_title( get_option( 'page_for_posts' ) ) ?: __( 'Latest Posts', 'newspress' ) ); ?></h1>
        <section class="np-container np-home-layout <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?> np-home-row np-home-row-latest np-home-row-1 np-home-paged-row" aria-label="<?php esc_attr_e( 'Latest posts', 'newspress' ); ?>">
            <div class="np-home-content">
                <?php if ( $np_blog_query->have_posts() && $np_paged <= $np_total_pages ) : ?>
                    <section class="np-section np-latest-all np-latest-group np-latest-group-1" aria-labelledby="np-blog-paged-title">
                        <div class="np-section-head">
                            <h2 id="np-blog-paged-title"><?php esc_html_e( 'Berita Terkini', 'newspress' ); ?></h2>
                        </div>
                        <div class="np-latest-list <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'latest' ) : '' ); ?>">
                            <?php $np_previous_context = get_query_var( 'newspress_card_context' ); set_query_var( 'newspress_card_context', 'latest' ); while ( $np_blog_query->have_posts() ) : $np_blog_query->the_post(); ?>
                                <?php get_template_part( 'template-parts/content', 'card' ); ?>
                            <?php endwhile; set_query_var( 'newspress_card_context', $np_previous_context ); wp_reset_postdata(); ?>
                        </div>
                    </section>
                    <?php if ( $np_total_pages > 1 ) : ?>
                        <nav class="np-load-more-wrap np-latest-pagination" aria-label="<?php esc_attr_e( 'Posts navigation', 'newspress' ); ?>">
                            <?php
                            echo paginate_links( array(
                                'base'      => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                                'format'    => '',
                                'current'   => $np_paged,
                                'total'     => $np_total_pages,
                                'mid_size'  => 1,
                                'prev_text' => __( 'Previous', 'newspress' ),
                                'next_text' => __( 'Next', 'newspress' ),
                            ) );
                            ?>
                        </nav>
                    <?php endif; ?>
                <?php else : ?>
                    <?php wp_reset_postdata(); get_template_part( 'template-parts/content', 'none' ); ?>
                <?php endif; ?>
            </div>
            <?php get_sidebar(); ?>
        </section>
    </main>
<?php else : ?>
<main id="primary" class="np-site-main np-container np-layout <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?>">
    <div class="np-content">
        <?php if ( have_posts() ) : ?>
            <header class="np-archive-header"><h1><?php echo esc_html( is_home() ? ( get_the_title( get_option( 'page_for_posts' ) ) ?: __( 'Latest Posts', 'newspress' ) ) : get_bloginfo( 'name' ) ); ?></h1></header>
            <div class="np-archive-grid np-latest-list <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'latest' ) : '' ); ?>">
            <?php $np_previous_context = get_query_var( 'newspress_card_context' ); set_query_var( 'newspress_card_context', 'latest' ); while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; set_query_var( 'newspress_card_context', $np_previous_context ); ?>
            </div>
            <?php the_posts_pagination( array( 'mid_size' => 2, 'prev_text' => __( 'Previous', 'newspress' ), 'next_text' => __( 'Next', 'newspress' ) ) ); ?>
        <?php else : get_template_part( 'template-parts/content', 'none' ); endif; ?>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php endif; ?>
<?php get_footer(); ?>
