<?php get_header(); ?>
<main id="primary" class="np-site-main np-container">
    <section class="np-error-404">
        <h1><?php esc_html_e( 'Page Not Found', 'newspress' ); ?></h1>
        <p><?php esc_html_e( 'The page you are looking for may have been moved, deleted, or never existed.', 'newspress' ); ?></p>
        <?php get_search_form(); ?>
        <p><a class="np-button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Home', 'newspress' ); ?></a></p>
    </section>
    <?php
    $np_suggested = new WP_Query( array(
        'posts_per_page'      => 4,
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'no_found_rows'       => true,
    ) );
    if ( $np_suggested->have_posts() ) : ?>
        <section class="np-section np-404-suggested" aria-labelledby="np-404-suggested-title">
            <div class="np-section-head"><h2 id="np-404-suggested-title"><?php esc_html_e( 'Latest Articles', 'newspress' ); ?></h2></div>
            <div class="np-latest-list">
                <?php while ( $np_suggested->have_posts() ) : $np_suggested->the_post(); ?>
                    <?php get_template_part( 'template-parts/content', 'card' ); ?>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </section>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
