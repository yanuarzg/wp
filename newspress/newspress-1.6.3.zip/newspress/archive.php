<?php get_header(); ?>
<main id="primary" class="np-site-main np-container np-layout <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?>">
    <div class="np-content">
        <?php if ( is_author() ) :
            $np_author = get_queried_object();
            $np_author_id = isset( $np_author->ID ) ? (int) $np_author->ID : 0;
            $np_author_name = $np_author_id ? get_the_author_meta( 'display_name', $np_author_id ) : '';
            $np_author_bio = $np_author_id ? get_the_author_meta( 'description', $np_author_id ) : '';
            $np_author_site = $np_author_id ? get_the_author_meta( 'user_url', $np_author_id ) : '';
            $np_author_posts = 0;
            if ( $np_author_id ) {
                $np_author_cache_key = 'newspress_author_posts_' . $np_author_id;
                $np_author_posts = get_transient( $np_author_cache_key );
                if ( false === $np_author_posts ) {
                    $np_author_posts = count_user_posts( $np_author_id, 'post', true );
                    set_transient( $np_author_cache_key, absint( $np_author_posts ), 6 * HOUR_IN_SECONDS );
                }
                $np_author_posts = absint( $np_author_posts );
            }
            if ( ! $np_author_name ) {
                $np_author_name = get_bloginfo( 'name' );
            }
            ?>
            <header class="np-archive-header np-author-archive">
                <div class="np-author-archive-avatar">
                    <?php echo get_avatar( $np_author_id, 96, '', $np_author_name, array( 'class' => 'np-author-archive-img' ) ); ?>
                </div>
                <div class="np-author-archive-body">
                    <p class="np-author-kicker"><?php esc_html_e( 'Author', 'newspress' ); ?></p>
                    <h1><?php echo esc_html( $np_author_name ); ?></h1>
                    <?php if ( $np_author_bio ) : ?>
                        <div class="archive-description np-author-archive-description">
                            <?php echo wp_kses_post( wpautop( $np_author_bio ) ); ?>
                        </div>
                    <?php else : ?>
                        <div class="archive-description np-author-archive-description">
                            <p><?php printf( esc_html__( 'Daftar artikel yang ditulis oleh %s.', 'newspress' ), esc_html( $np_author_name ) ); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="np-author-archive-meta">
                        <span><?php printf( esc_html( _n( '%s article', '%s articles', $np_author_posts, 'newspress' ) ), esc_html( number_format_i18n( $np_author_posts ) ) ); ?></span>
                        <?php if ( $np_author_site ) : ?>
                            <a href="<?php echo esc_url( $np_author_site ); ?>" rel="nofollow noopener" target="_blank"><?php esc_html_e( 'Website', 'newspress' ); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </header>
        <?php else : ?>
            <header class="np-archive-header">
                <?php the_archive_title( '<h1>', '</h1>' ); the_archive_description( '<div class="archive-description">', '</div>' ); ?>
            </header>
        <?php endif; ?>
        <?php if ( have_posts() ) : ?>
            <div class="np-archive-grid np-latest-list <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'latest' ) : '' ); ?>">
                <?php $np_previous_context = get_query_var( 'newspress_card_context' ); set_query_var( 'newspress_card_context', 'latest' ); while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; set_query_var( 'newspress_card_context', $np_previous_context ); ?>
            </div>
            <?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
        <?php else : get_template_part( 'template-parts/content', 'none' ); endif; ?>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
