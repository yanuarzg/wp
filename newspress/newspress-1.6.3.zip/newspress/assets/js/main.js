(function(){
  const root=document.documentElement;
  const header=document.querySelector('.np-site-header');
  const progress=document.querySelector('.np-scroll-progress');
  const backTop=document.querySelector('.np-back-to-top');
  const menuToggle=document.querySelector('.np-menu-toggle');
  const nav=document.querySelector('.np-nav');
  const searchToggle=document.querySelector('.np-search-toggle');
  const searchPanel=document.getElementById('np-search-panel');
  const navBackdrop=document.querySelector('.np-nav-backdrop');
  const themeToggle=document.querySelector('.np-theme-toggle');
  const safeStorage={get(key){try{return localStorage.getItem(key);}catch(e){return null;}},set(key,value){try{localStorage.setItem(key,value);}catch(e){}}};
  const icons={dark:'<svg class="np-icon np-icon-dark-mode" width="21" height="21" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor"><path d="M21.64 13a1 1 0 0 0-1.05-.14 8.05 8.05 0 0 1-3.37.73 8.15 8.15 0 0 1-8.14-8.14c0-1.18.25-2.32.73-3.37A1 1 0 0 0 8.5.77 10.15 10.15 0 1 0 23 15.5a1 1 0 0 0-1.36-2.5ZM12.85 20A8.15 8.15 0 0 1 6.9 6.27a10.16 10.16 0 0 0 10.83 10.83A8.1 8.1 0 0 1 12.85 20Z"/></svg>',light:'<svg class="np-icon np-icon-light-mode" width="21" height="21" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor"><path d="M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Zm0-2a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM11 1h2v3h-2V1Zm0 19h2v3h-2v-3ZM3.51 4.93l1.42-1.42 2.12 2.13-1.41 1.41-2.13-2.12Zm13.44 13.43 1.41-1.41 2.13 2.12-1.42 1.42-2.12-2.13ZM1 11h3v2H1v-2Zm19 0h3v2h-3v-2ZM3.51 19.07l2.13-2.12 1.41 1.41-2.12 2.13-1.42-1.42ZM16.95 5.64l2.12-2.13 1.42 1.42-2.13 2.12-1.41-1.41Z"/></svg>'};
  function onScroll(){const y=window.scrollY||window.pageYOffset;if(header){header.classList.toggle('is-scrolled',y>8);}if(progress){const doc=root.scrollHeight-window.innerHeight;progress.style.width=(doc>0?Math.min(100,(y/doc)*100):0)+'%';}if(backTop){backTop.classList.toggle('is-visible',y>420);}}
  onScroll(); window.addEventListener('scroll',onScroll,{passive:true});
  if(backTop){backTop.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));}
  function closeMenu(){if(nav){nav.classList.remove('is-open');}document.body.classList.remove('np-menu-open');if(menuToggle){menuToggle.setAttribute('aria-expanded','false');}}
  if(menuToggle&&nav){menuToggle.addEventListener('click',()=>{const open=!nav.classList.contains('is-open');nav.classList.toggle('is-open',open);document.body.classList.toggle('np-menu-open',open);menuToggle.setAttribute('aria-expanded',open?'true':'false');});document.addEventListener('click',(event)=>{if(!nav.classList.contains('is-open'))return;if(nav.contains(event.target)||menuToggle.contains(event.target))return;closeMenu();});}
  if(navBackdrop){navBackdrop.addEventListener('click',closeMenu);}
  if(searchToggle&&searchPanel){searchToggle.addEventListener('click',()=>{const hidden=searchPanel.hasAttribute('hidden');if(hidden){searchPanel.removeAttribute('hidden');const input=searchPanel.querySelector('input[type="search"]');if(input){setTimeout(()=>input.focus(),40);}searchToggle.setAttribute('aria-label','Close search');}else{searchPanel.setAttribute('hidden','');searchToggle.setAttribute('aria-label','Open search');}searchToggle.setAttribute('aria-expanded',hidden?'true':'false');});}
  document.addEventListener('keydown',(event)=>{if(event.key!=='Escape')return;closeMenu();if(searchPanel&&!searchPanel.hasAttribute('hidden')){searchPanel.setAttribute('hidden','');if(searchToggle){searchToggle.setAttribute('aria-expanded','false');searchToggle.setAttribute('aria-label','Open search');}}});
  const clocks=[...document.querySelectorAll('[data-clock="1"],[data-clock-mobile="1"]')];
  if(clocks.length){const tick=()=>{const d=new Date();const text=d.toLocaleString(root.lang||'id-ID',{weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});clocks.forEach(el=>{el.textContent=text;});};tick();setInterval(tick,30000);}
  const savedTheme=safeStorage.get('newspress-theme');
  const prefersDark=window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches;
  const defaultTheme=(themeToggle&&themeToggle.dataset.defaultTheme)||'system';
  const initialTheme=savedTheme||(defaultTheme==='dark'?'dark':(defaultTheme==='light'?'light':(prefersDark?'dark':'light')));
  function applyTheme(theme){const dark=theme==='dark';root.setAttribute('data-theme',dark?'dark':'light');if(themeToggle){themeToggle.setAttribute('aria-pressed',dark?'true':'false');themeToggle.innerHTML=dark?icons.light:icons.dark;}}
  applyTheme(initialTheme);
  if(themeToggle){themeToggle.addEventListener('click',()=>{const next=root.getAttribute('data-theme')==='dark'?'light':'dark';safeStorage.set('newspress-theme',next);applyTheme(next);});}
  document.addEventListener('click',async(event)=>{
    const btn=event.target.closest('[data-load-more="1"]');
    if(!btn||btn.disabled||btn.classList.contains('is-loading'))return;
    const endpoint=btn.dataset.endpoint;
    const restEndpoint=btn.dataset.restEndpoint;
    const offset=parseInt(btn.dataset.offset||'0',10);
    const count=parseInt(btn.dataset.count||'5',10);
    const latestLists=[...document.querySelectorAll('.np-latest-list')];
    const target=document.querySelector('.np-latest-list-load-target')||(latestLists.length?latestLists[latestLists.length-1]:null);
    if(!target)return;
    const oldText=btn.textContent;
    btn.classList.add('is-loading');
    btn.disabled=true;
    btn.textContent='Loading...';
    try{
      let payload=null;
      if(endpoint){
        const form=new FormData();
        form.append('action','newspress_load_more');
        form.append('nonce',btn.dataset.nonce||'');
        form.append('offset',String(offset));
        form.append('count',String(count));
        const res=await fetch(endpoint,{method:'POST',body:form,credentials:'same-origin'});
        const json=await res.json();
        payload=json&&json.success?json.data:json;
      }
      if((!payload||typeof payload.html==='undefined')&&restEndpoint){
        const url=new URL(restEndpoint,window.location.href);
        url.searchParams.set('offset',String(offset));
        url.searchParams.set('count',String(count));
        const res=await fetch(url.toString(),{credentials:'same-origin'});
        payload=await res.json();
      }
      if(payload&&payload.html){target.insertAdjacentHTML('beforeend',payload.html);}
      const next=(payload&&payload.nextOffset)?payload.nextOffset:(offset+count);
      btn.dataset.offset=String(next);
      if(!payload||!payload.hasMore){
        btn.disabled=true;
        btn.classList.add('is-disabled');
        btn.textContent='No More Posts';
      }else{
        btn.disabled=false;
        btn.classList.remove('is-disabled');
        btn.textContent='Load More';
      }
    }catch(e){
      btn.disabled=false;
      btn.classList.remove('is-disabled');
      btn.textContent='Try Again';
    }finally{
      btn.classList.remove('is-loading');
    }
  });

  function npFormatNumber(value){try{return new Intl.NumberFormat(root.lang||'id-ID').format(value);}catch(e){return String(value);}}
  function npUpdateShareCount(count){
    const value=parseInt(count,10);
    if(Number.isNaN(value))return;
    document.querySelectorAll('[data-np-share-count]').forEach((el)=>{el.textContent=npFormatNumber(value);});
  }
  async function npTrackShare(service){
    if(!window.newspressData||!newspressData.isSinglePost||!newspressData.postId||!newspressData.shareEndpoint){return;}
    try{
      const res=await fetch(newspressData.shareEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({post_id:newspressData.postId,service:service||'share'}),keepalive:true,credentials:'same-origin'});
      const json=await res.json();
      if(json&&typeof json.count!=='undefined'){npUpdateShareCount(json.count);}
    }catch(e){}
  }
  document.addEventListener('click', async (event)=>{
    const shareBtn=event.target.closest('[data-np-share-track]');
    if(shareBtn){npTrackShare(shareBtn.getAttribute('data-np-share-track')||'share');}
    const nativeBtn=event.target.closest('[data-np-web-share]');
    if(nativeBtn){
      const shareData={title:document.title,url:window.location.href};
      if(navigator.share){try{await navigator.share(shareData);}catch(e){}}
      else{
        const url=window.location.href;
        try{await navigator.clipboard.writeText(url); nativeBtn.classList.add('is-copied'); setTimeout(()=>nativeBtn.classList.remove('is-copied'),1200);}catch(e){window.prompt('Copy link',url);}
      }
    }
    const copyBtn=event.target.closest('[data-copy-link]');
    if(copyBtn){
      const url=copyBtn.getAttribute('data-copy-link')||window.location.href;
      try{await navigator.clipboard.writeText(url); copyBtn.classList.add('is-copied'); setTimeout(()=>copyBtn.classList.remove('is-copied'),1200);}catch(e){window.prompt('Copy link',url);}
    }
    const tocBtn=event.target.closest('.np-toc-toggle');
    if(tocBtn){
      const toc=tocBtn.closest('.np-toc');
      const list=toc&&toc.querySelector('.np-toc-list');
      const open=tocBtn.getAttribute('aria-expanded')!=='false';
      tocBtn.setAttribute('aria-expanded',open?'false':'true');
      if(list){list.hidden=open;}
    }
    const closeAd=event.target.closest('.np-mobile-sticky-ad-close');
    if(closeAd){
      const ad=closeAd.closest('.np-mobile-sticky-ad');
      if(ad){ad.remove();document.body.classList.remove('np-has-mobile-sticky-ad');}
    }
  });
  if(document.querySelector('.np-mobile-sticky-ad')){document.body.classList.add('np-has-mobile-sticky-ad');}

  document.querySelectorAll('[data-np-slider="1"]').forEach((wrap)=>{
    const track=wrap.querySelector('.np-slider-track');
    const slides=[...wrap.querySelectorAll('.np-slide')];
    const dotsWrap=wrap.querySelector('.np-slider-dots');
    const prevBtn=wrap.querySelector('.np-slider-prev');
    const nextBtn=wrap.querySelector('.np-slider-next');
    const total=slides.length;
    if(!track||!total)return;
    let current=0;
    let timer=null;
    const autoplay=wrap.dataset.autoplay==='true';
    const speed=Math.max(1000,parseInt(wrap.dataset.speed||'5000',10)||5000);
    const dots=[];
    if(dotsWrap){
      slides.forEach((_,i)=>{
        const dot=document.createElement('button');
        dot.type='button';
        dot.className='np-slider-dot'+(i===0?' is-active':'');
        dot.setAttribute('aria-label','Slide '+(i+1));
        dot.addEventListener('click',()=>{goTo(i);resetTimer();});
        dotsWrap.appendChild(dot);
        dots.push(dot);
      });
    }
    function goTo(index){
      if(index<0)index=total-1;
      if(index>=total)index=0;
      current=index;
      track.style.transform='translateX(-'+(current*100)+'%)';
      dots.forEach((dot,i)=>dot.classList.toggle('is-active',i===current));
    }
    function next(){goTo(current+1);} function prev(){goTo(current-1);}
    function startTimer(){if(autoplay&&total>1){timer=setInterval(next,speed);}}
    function resetTimer(){if(timer)clearInterval(timer);startTimer();}
    nextBtn&&nextBtn.addEventListener('click',()=>{next();resetTimer();});
    prevBtn&&prevBtn.addEventListener('click',()=>{prev();resetTimer();});
    let startX=0;
    wrap.addEventListener('touchstart',(e)=>{startX=e.touches[0].clientX;},{passive:true});
    wrap.addEventListener('touchend',(e)=>{const diff=startX-e.changedTouches[0].clientX;if(Math.abs(diff)>42){diff>0?next():prev();resetTimer();}},{passive:true});
    wrap.addEventListener('mouseenter',()=>{if(timer)clearInterval(timer);});
    wrap.addEventListener('mouseleave',startTimer);
    startTimer();
  });

})();
(function(){
  if(!window.newspressData||!newspressData.isSinglePost||!newspressData.postId||!newspressData.viewEndpoint){return;}
  var key='np_viewed_'+newspressData.postId;
  try{if(sessionStorage.getItem(key)){return;}sessionStorage.setItem(key,'1');}catch(e){}
  var payload=JSON.stringify({post_id:newspressData.postId});
  if(navigator.sendBeacon){try{var blob=new Blob([payload],{type:'application/json'});navigator.sendBeacon(newspressData.viewEndpoint,blob);return;}catch(e){}}
  try{fetch(newspressData.viewEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:payload,keepalive:true,credentials:'same-origin'});}catch(e){}
})();
