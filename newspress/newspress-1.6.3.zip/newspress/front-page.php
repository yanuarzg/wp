<?php
/** Front page template: Kompas-style editorial rows with one semantic main landmark. */
get_header();

$home_sections = newspress_get_home_sections();
$home_settings = newspress_get_home_settings();
$hero_sections = array();
$queue         = array();

foreach ( $home_sections as $section ) {
    $type = isset( $section['type'] ) ? sanitize_key( $section['type'] ) : '';
    if ( 'category' === $type ) {
        $section['type'] = 'category_grid';
        $type = 'category_grid';
    }
    if ( 'hero' === $type ) {
        $hero_sections[] = $section;
    } elseif ( in_array( $type, array( 'category_grid', 'category_list', 'ad', 'widget' ), true ) ) {
        $queue[] = $section;
    }
}

$paged         = max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );
$rows          = min( 8, max( 1, absint( $home_settings['main_rows'] ) ) );
$posts_per_row = min( 10, max( 1, absint( $home_settings['posts_per_row'] ) ) );
$latest_rows   = max( 0, $rows - 1 );
$per_page      = max( 1, $latest_rows * $posts_per_row );
$base_offset   = ( $paged - 1 ) * $per_page;
$published     = wp_count_posts( 'post' );
$total_posts   = isset( $published->publish ) ? absint( $published->publish ) : 0;
$first_page_posts = max( 1, $latest_rows * $posts_per_row );
$paged_offset  = 1 === $paged ? 0 : $first_page_posts + ( ( $paged - 2 ) * $posts_per_row );
$total_pages   = 1;
if ( $total_posts > $first_page_posts ) {
    $total_pages += (int) ceil( ( $total_posts - $first_page_posts ) / $posts_per_row );
}
$total_pages   = max( 1, $total_pages );
$interlude_i   = 0;
$home_layout   = get_theme_mod( 'newspress_layout', 'right-sidebar' );
?>

<main id="primary" class="np-site-main np-home-page <?php echo esc_attr( $home_layout ); ?>" aria-label="<?php esc_attr_e( 'Homepage content', 'newspress' ); ?>">
    <h1 class="screen-reader-text"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>

    <?php if ( $paged > 1 ) : ?>
        <section class="np-container np-home-layout <?php echo esc_attr( $home_layout ); ?> np-home-row np-home-row-latest np-home-row-1 np-home-paged-row" aria-label="<?php esc_attr_e( 'Latest posts', 'newspress' ); ?>">
            <div class="np-home-content">
                <?php newspress_front_latest_section( $paged_offset, 1, $posts_per_row ); ?>
                <?php
                $shown_posts = $paged_offset + $posts_per_row;
                $has_more    = ( $total_posts >= absint( $home_settings['load_more_min'] ) ) && ( $total_posts > $shown_posts );
                ?>
                <?php if ( 'pagination' === $home_settings['latest_nav_mode'] ) : ?>
                    <?php
                    $pagination_total = $total_pages;
                    if ( $pagination_total > 1 && $paged <= $pagination_total ) :
                        ?>
                        <nav class="np-load-more-wrap np-latest-pagination" aria-label="<?php esc_attr_e( 'Latest posts pagination', 'newspress' ); ?>">
                            <?php
                            echo paginate_links( array(
                                'base'      => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                                'format'    => '',
                                'current'   => max( 1, $paged ),
                                'total'     => $pagination_total,
                                'mid_size'  => 1,
                                'prev_text' => __( 'Previous', 'newspress' ),
                                'next_text' => __( 'Next', 'newspress' ),
                            ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            ?>
                        </nav>
                    <?php endif; ?>
                <?php else : ?>
                    <div class="np-load-more-wrap">
                        <button
                            type="button"
                            class="np-load-more<?php echo $has_more ? '' : ' is-disabled'; ?>"
                            data-load-more="1"
                            data-endpoint="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
                            data-rest-endpoint="<?php echo esc_url( rest_url( 'newspress/v1/load-more' ) ); ?>"
                            data-nonce="<?php echo esc_attr( wp_create_nonce( 'newspress_load_more' ) ); ?>"
                            data-offset="<?php echo esc_attr( $shown_posts ); ?>"
                            data-count="<?php echo esc_attr( $posts_per_row ); ?>"
                            <?php disabled( ! $has_more ); ?>>
                            <?php esc_html_e( 'Load More', 'newspress' ); ?>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <?php get_sidebar(); ?>
        </section>
    <?php else : ?>

    <?php
    $np_trending_source    = get_theme_mod( 'newspress_trending_source', 'post_tag' );
    $np_trending_count     = min( 20, max( 1, absint( get_theme_mod( 'newspress_trending_count', 7 ) ) ) );
    $np_trending_show_hash = get_theme_mod( 'newspress_trending_show_hash', 1 );
    $np_home_trending_terms = function_exists( 'newspress_get_trending_terms' ) ? newspress_get_trending_terms( $np_trending_count, $np_trending_source ) : get_terms( array( 'taxonomy' => $np_trending_source, 'number' => $np_trending_count, 'orderby' => 'count', 'order' => 'DESC' ) );
    if ( ! empty( $np_home_trending_terms ) && ! is_wp_error( $np_home_trending_terms ) ) :
        ?>
        <section class="np-container np-home-trending" aria-label="<?php esc_attr_e( 'Trending topics', 'newspress' ); ?>">
            <div class="np-trending">
                <strong><?php esc_html_e( 'Trending', 'newspress' ); ?></strong>
                <?php foreach ( $np_home_trending_terms as $term ) : ?>
                    <a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo $np_trending_show_hash ? '#' : ''; ?><?php echo esc_html( $term->name ); ?></a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="np-container np-home-layout <?php echo esc_attr( $home_layout ); ?> np-home-row np-home-row-primary" aria-label="<?php esc_attr_e( 'Top stories', 'newspress' ); ?>">
        <div class="np-home-content">
            <?php if ( ! empty( $home_settings['show_home_top'] ) ) : ?>
                <?php newspress_front_echo_widget_area( 'home-top', __( 'Homepage Top', 'newspress' ) ); ?>
            <?php endif; ?>
            <?php
            set_query_var( 'newspress_section', ! empty( $hero_sections ) ? $hero_sections[0] : array( 'type' => 'hero' ) );
            get_template_part( 'template-parts/home', 'hero' );

            $primary_category = newspress_front_take_section( $queue, array( 'category_grid' ) );
            if ( ! empty( $primary_category ) ) {
                set_query_var( 'newspress_section', $primary_category );
                get_template_part( 'template-parts/home', 'category' );
            }
            ?>
        </div>
        <aside class="np-sidebar np-home-sidebar np-home-sidebar-primary" aria-label="<?php esc_attr_e( 'Primary sidebar', 'newspress' ); ?>">
            <?php newspress_front_echo_widget_area( 'home-popular', __( 'Homepage Popular Posts', 'newspress' ), 'np-home-popular-widget-area' ); ?>
            <?php newspress_front_echo_widget_area( 'home-primary-side', __( 'Homepage Primary Right Widget', 'newspress' ) ); ?>
        </aside>
    </section>

    <?php
    $after_primary = newspress_front_take_section( $queue, array( 'category_grid', 'ad', 'widget' ) );
    newspress_front_render_section( $after_primary, $interlude_i++ );
    ?>

    <?php for ( $row = 1; $row <= $latest_rows; $row++ ) : ?>
        <section class="np-container np-home-layout <?php echo esc_attr( $home_layout ); ?> np-home-row np-home-row-latest np-home-row-<?php echo esc_attr( $row ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Homepage latest news row %d', 'newspress' ), $row ) ); ?>">
            <div class="np-home-content">
                <?php if ( ! empty( $home_settings['row_ad_enabled'] ) ) : ?>
                    <?php
                    $row_ad_widget = newspress_front_widget_area(
                        'home-row-ad-' . $row,
                        sprintf( __( 'Homepage Row %d Ad Widget', 'newspress' ), $row ),
                        'np-home-row-top-ad'
                    );
                    if ( '' !== $row_ad_widget ) {
                        echo $row_ad_widget; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    } elseif ( ! is_customize_preview() ) {
                        newspress_front_ad_block( 'np-home-row-top-ad' );
                    }
                    ?>
                <?php endif; ?>
                <?php newspress_front_latest_section( $base_offset + ( ( $row - 1 ) * $posts_per_row ), $row, $posts_per_row ); ?>
                <?php if ( $row === $latest_rows ) :
                    $shown_posts   = $base_offset + $per_page;
                    $has_more      = ( $total_posts >= absint( $home_settings['load_more_min'] ) ) && ( $total_posts > $shown_posts );
                    ?>
                    <?php if ( 'pagination' === $home_settings['latest_nav_mode'] ) : ?>
                        <?php
                        $pagination_total = $total_pages;
                        if ( $pagination_total > 1 ) :
                            ?>
                            <nav class="np-load-more-wrap np-latest-pagination" aria-label="<?php esc_attr_e( 'Latest posts pagination', 'newspress' ); ?>">
                                <?php
                                echo paginate_links( array(
                                    'base'      => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                                    'format'    => '',
                                    'current'   => max( 1, $paged ),
                                    'total'     => $pagination_total,
                                    'mid_size'  => 1,
                                    'prev_text' => __( 'Previous', 'newspress' ),
                                    'next_text' => __( 'Next', 'newspress' ),
                                ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                ?>
                            </nav>
                        <?php endif; ?>
                    <?php else : ?>
                        <div class="np-load-more-wrap">
                            <button
                                type="button"
                                class="np-load-more<?php echo $has_more ? '' : ' is-disabled'; ?>"
                                data-load-more="1"
                                data-endpoint="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
                                data-rest-endpoint="<?php echo esc_url( rest_url( 'newspress/v1/load-more' ) ); ?>"
                                data-nonce="<?php echo esc_attr( wp_create_nonce( 'newspress_load_more' ) ); ?>"
                                data-offset="<?php echo esc_attr( $shown_posts ); ?>"
                                data-count="<?php echo esc_attr( $posts_per_row ); ?>"
                                <?php disabled( ! $has_more ); ?>>
                                <?php esc_html_e( 'Load More', 'newspress' ); ?>
                            </button>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <aside class="np-sidebar np-home-sidebar np-home-sidebar-row" aria-label="<?php echo esc_attr( sprintf( __( 'Homepage row %d sidebar', 'newspress' ), $row ) ); ?>">
                <?php
                $side_category = newspress_front_take_section( $queue, array( 'category_list', 'category_grid' ) );
                if ( ! empty( $side_category ) ) {
                    $side_category['type'] = 'category_list';
                    set_query_var( 'newspress_section', $side_category );
                    get_template_part( 'template-parts/home', 'category' );
                }
                newspress_front_echo_widget_area(
                    'home-row-side-' . $row,
                    sprintf( __( 'Homepage Row %d Right Widget', 'newspress' ), $row ),
                    'np-home-row-side-widget-area'
                );
                ?>
            </aside>
        </section>
        <?php if ( $row < $latest_rows ) : ?>
            <?php
            $between_rows = newspress_front_take_section( $queue, array( 'category_grid', 'ad', 'widget' ) );
            newspress_front_render_section( $between_rows, $interlude_i++ );
            ?>
        <?php endif; ?>
    <?php endfor; ?>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
