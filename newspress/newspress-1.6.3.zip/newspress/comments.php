<?php if ( post_password_required() ) { return; } ?>
<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>
        <h2 class="comments-title">
            <?php
            $np_comment_count = get_comments_number();
            echo esc_html( sprintf(
                _n( '%s Comment', '%s Comments', $np_comment_count, 'newspress' ),
                number_format_i18n( $np_comment_count )
            ) );
            ?>
        </h2>
        <ol class="comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true ) ); ?></ol>
        <?php the_comments_navigation(); ?>
    <?php endif; ?>
    <?php comment_form( array(
        'title_reply'          => __( 'Leave a Reply', 'newspress' ),
        'title_reply_before'   => '<h2 id="reply-title" class="comment-reply-title">',
        'title_reply_after'    => '</h2>',
        'label_submit'         => __( 'Post Comment', 'newspress' ),
        'comment_notes_before' => '<p class="comment-notes">' . esc_html__( 'Your email address will not be published. Required fields are marked *', 'newspress' ) . '</p>',
    ) ); ?>
</div>
