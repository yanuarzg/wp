<?php
/** Enqueue assets. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_enqueue_assets() {
    wp_enqueue_style( 'newspress-style', get_stylesheet_uri(), array(), NEWSPRESS_VERSION );
    $newspress_main_css = NEWSPRESS_DIR . '/assets/css/main.css';
    wp_enqueue_style( 'newspress-main', NEWSPRESS_URI . '/assets/css/main.css', array( 'newspress-style' ), file_exists( $newspress_main_css ) ? filemtime( $newspress_main_css ) : NEWSPRESS_VERSION );
    wp_enqueue_script( 'newspress-main', NEWSPRESS_URI . '/assets/js/main.js', array(), NEWSPRESS_VERSION, true );

    wp_localize_script( 'newspress-main', 'newspressData', array(
        'isSinglePost' => is_singular( 'post' ),
        'postId'       => is_singular( 'post' ) ? get_queried_object_id() : 0,
        'viewEndpoint'  => esc_url_raw( rest_url( 'newspress/v1/view' ) ),
        'shareEndpoint' => esc_url_raw( rest_url( 'newspress/v1/share' ) ),
    ) );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'newspress_enqueue_assets' );

function newspress_admin_assets( $hook ) {
    $is_home_builder = 'appearance_page_newspress-homepage' === $hook;
    $is_post_editor  = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

    if ( ! $is_home_builder && ! $is_post_editor ) {
        return;
    }

    wp_enqueue_style( 'newspress-admin', NEWSPRESS_URI . '/assets/css/admin.css', array(), NEWSPRESS_VERSION );

}
add_action( 'admin_enqueue_scripts', 'newspress_admin_assets' );
