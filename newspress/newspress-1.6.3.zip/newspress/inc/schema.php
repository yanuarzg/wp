<?php
/** Schema output. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_schema_enabled() {
    if ( ! get_theme_mod( 'newspress_enable_jsonld', 1 ) ) {
        return false;
    }

    // Avoid duplicate structured data when a major SEO plugin is intentionally handling schema.
    if ( get_theme_mod( 'newspress_disable_schema_when_seo_plugin_active', 0 ) && function_exists( 'newspress_has_seo_plugin' ) && newspress_has_seo_plugin() ) {
        return false;
    }

    return true;
}

function newspress_schema_clean_text( $text, $limit = 0 ) {
    $text = trim( wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES, get_bloginfo( 'charset' ) ) ) );
    $text = preg_replace( '/\s+/', ' ', $text );
    if ( $limit > 0 && function_exists( 'mb_substr' ) && mb_strlen( $text ) > $limit ) {
        $text = mb_substr( $text, 0, $limit );
    }
    return $text;
}

function newspress_publisher_schema() {
    $publisher = array(
        '@type' => 'Organization',
        '@id'   => home_url( '/#organization' ),
        'name'  => get_bloginfo( 'name' ),
        'url'   => home_url( '/' ),
    );

    $logo_id = get_theme_mod( 'custom_logo' );
    $logo    = $logo_id ? wp_get_attachment_image_src( $logo_id, 'full' ) : false;

    if ( $logo ) {
        $publisher['logo'] = array(
            '@type'  => 'ImageObject',
            '@id'    => home_url( '/#logo' ),
            'url'    => $logo[0],
            'width'  => absint( $logo[1] ),
            'height' => absint( $logo[2] ),
        );
    } elseif ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
        $icon = get_site_icon_url( 512 );
        if ( $icon ) {
            $publisher['logo'] = array(
                '@type'  => 'ImageObject',
                '@id'    => home_url( '/#logo' ),
                'url'    => $icon,
                'width'  => 512,
                'height' => 512,
            );
        }
    }

    return $publisher;
}

function newspress_author_schema( $post_id = 0 ) {
    $post_id = $post_id ? absint( $post_id ) : get_queried_object_id();
    $post    = $post_id ? get_post( $post_id ) : null;

    $author_id = $post ? absint( $post->post_author ) : 0;
    $name      = $author_id ? get_the_author_meta( 'display_name', $author_id ) : '';

    if ( ! $name && $author_id ) {
        $name = get_the_author_meta( 'nickname', $author_id );
    }
    if ( ! $name && $author_id ) {
        $name = get_the_author_meta( 'user_login', $author_id );
    }
    if ( ! $name ) {
        $name = sprintf( __( 'Redaksi %s', 'newspress' ), get_bloginfo( 'name' ) );
    }

    $author = array(
        '@type' => 'Person',
        '@id'   => $author_id ? get_author_posts_url( $author_id ) . '#author' : home_url( '/#author' ),
        'name'  => newspress_schema_clean_text( $name, 80 ),
        'url'   => $author_id ? get_author_posts_url( $author_id ) : home_url( '/' ),
    );

    $user_url = $author_id ? get_the_author_meta( 'user_url', $author_id ) : '';
    if ( $user_url ) {
        $author['sameAs'] = array( esc_url_raw( $user_url ) );
    }

    return $author;
}

function newspress_schema_image( $post_id = 0 ) {
    $post_id = $post_id ? absint( $post_id ) : get_queried_object_id();
    if ( ! $post_id || ! has_post_thumbnail( $post_id ) ) {
        return null;
    }

    $image_id = get_post_thumbnail_id( $post_id );
    $image    = wp_get_attachment_image_src( $image_id, 'full' );

    if ( ! $image ) {
        return null;
    }

    $image_schema = array(
        '@type' => 'ImageObject',
        'url'   => $image[0],
    );

    if ( ! empty( $image[1] ) ) {
        $image_schema['width'] = absint( $image[1] );
    }
    if ( ! empty( $image[2] ) ) {
        $image_schema['height'] = absint( $image[2] );
    }

    return $image_schema;
}

function newspress_schema_json() {
    if ( ! newspress_schema_enabled() ) {
        return;
    }

    if ( is_single() ) {
        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return;
        }

        $cats  = get_the_category( $post_id );
        $tags  = wp_get_post_tags( $post_id, array( 'fields' => 'names' ) );
        $image = newspress_schema_image( $post_id );

        $description = function_exists( 'newspress_get_meta_description' ) ? newspress_get_meta_description() : wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post_id ) ), 28, '' );

        $data = array(
            '@context'         => 'https://schema.org',
            '@type'            => defined( 'NEWSPRESS_SCHEMA_TYPE_KEY' ) ? newspress_sanitize_schema_type( get_post_meta( $post_id, NEWSPRESS_SCHEMA_TYPE_KEY, true ) ?: 'NewsArticle' ) : 'NewsArticle',
            '@id'              => get_permalink( $post_id ) . '#article',
            'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => get_permalink( $post_id ) ),
            'url'              => get_permalink( $post_id ),
            'headline'         => newspress_schema_clean_text( get_the_title( $post_id ), 110 ),
            'description'      => newspress_schema_clean_text( $description, 220 ),
            'datePublished'    => get_post_time( DATE_W3C, true, $post_id ),
            'dateModified'     => get_post_modified_time( DATE_W3C, true, $post_id ),
            'author'           => newspress_author_schema( $post_id ),
            'publisher'        => newspress_publisher_schema(),
        );

        if ( $image ) {
            $data['image'] = $image;
            $data['thumbnailUrl'] = $image['url'];
        }
        if ( ! empty( $cats ) ) {
            $data['articleSection'] = newspress_schema_clean_text( $cats[0]->name, 80 );
        }
        if ( ! empty( $tags ) ) {
            $data['keywords'] = implode( ', ', array_map( 'newspress_schema_clean_text', array_slice( $tags, 0, 12 ) ) );
        }

        echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
}
add_action( 'wp_head', 'newspress_schema_json' );

function newspress_breadcrumb_schema_json() {
    if ( ! newspress_schema_enabled() || is_front_page() ) {
        return;
    }

    $items = array(
        array(
            '@type' => 'ListItem',
            'position' => 1,
            'name' => __( 'Home', 'newspress' ),
            'item' => home_url( '/' ),
        ),
    );

    if ( is_single() ) {
        $post_id = get_queried_object_id();
        $cats = get_the_category( $post_id );
        if ( ! empty( $cats ) ) {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => count( $items ) + 1,
                'name' => $cats[0]->name,
                'item' => get_category_link( $cats[0]->term_id ),
            );
        }
        $items[] = array(
            '@type' => 'ListItem',
            'position' => count( $items ) + 1,
            'name' => get_the_title( $post_id ),
            'item' => get_permalink( $post_id ),
        );
    } elseif ( is_page() ) {
        $items[] = array(
            '@type' => 'ListItem',
            'position' => 2,
            'name' => get_the_title(),
            'item' => get_permalink(),
        );
    } elseif ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && ! is_wp_error( $term ) ) {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => 2,
                'name' => $term->name,
                'item' => get_term_link( $term ),
            );
        }
    }

    $data = array(
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        '@id' => is_singular() ? get_permalink() . '#breadcrumb' : home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) ) . '#breadcrumb',
        'itemListElement' => $items,
    );

    echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'newspress_breadcrumb_schema_json' );

function newspress_website_schema_json() {
    if ( ! newspress_schema_enabled() || ! is_front_page() ) {
        return;
    }

    $data = array(
        '@context' => 'https://schema.org',
        '@type' => 'WebSite',
        '@id' => home_url( '/#website' ),
        'name' => get_bloginfo( 'name' ),
        'url' => home_url( '/' ),
        'publisher' => newspress_publisher_schema(),
        'potentialAction' => array(
            '@type' => 'SearchAction',
            'target' => home_url( '/?s={search_term_string}' ),
            'query-input' => 'required name=search_term_string',
        ),
    );

    echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'newspress_website_schema_json' );


function newspress_webpage_schema_json() {
    if ( ! newspress_schema_enabled() || is_front_page() || is_single() ) {
        return;
    }

    if ( is_page() || is_home() || is_archive() || is_search() ) {
        $data = array(
            '@context' => 'https://schema.org',
            '@type'    => 'WebPage',
            '@id'      => esc_url_raw( home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) ) ) . '#webpage',
            'url'      => esc_url_raw( home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) ) ),
            'name'     => wp_get_document_title(),
            'isPartOf' => array( '@id' => home_url( '/#website' ) ),
            'publisher'=> newspress_publisher_schema(),
        );
        echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
}
add_action( 'wp_head', 'newspress_webpage_schema_json' );

function newspress_itemlist_schema_json() {
    if ( ! newspress_schema_enabled() || ! ( is_front_page() || is_home() || is_archive() ) ) {
        return;
    }

    global $wp_query;
    if ( empty( $wp_query->posts ) ) {
        return;
    }

    $items = array();
    $position = 1;
    foreach ( array_slice( $wp_query->posts, 0, 12 ) as $post ) {
        if ( 'post' !== $post->post_type ) {
            continue;
        }
        $items[] = array(
            '@type'    => 'ListItem',
            'position' => $position,
            'url'      => get_permalink( $post ),
            'name'     => newspress_schema_clean_text( get_the_title( $post ), 110 ),
        );
        $position++;
    }

    if ( ! $items ) {
        return;
    }

    $data = array(
        '@context' => 'https://schema.org',
        '@type'    => 'ItemList',
        '@id'      => home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) ) . '#itemlist',
        'itemListElement' => $items,
    );
    echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'newspress_itemlist_schema_json' );
