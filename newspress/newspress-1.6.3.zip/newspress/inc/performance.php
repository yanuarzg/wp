<?php
/**
 * Frontend performance helpers.
 *
 * These optimizations target the common Lighthouse/PageSpeed bottlenecks for a
 * lightweight news theme: unnecessary WordPress assets, render-blocking extras,
 * image priority, and cache-friendly resource hints.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_perf_enabled( $key, $default = 1 ) {
    return (bool) get_theme_mod( 'newspress_perf_' . $key, $default );
}

function newspress_disable_emoji_assets() {
    if ( ! newspress_perf_enabled( 'disable_emojis', 1 ) ) {
        return;
    }
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'newspress_disable_emoji_assets' );

function newspress_disable_embeds() {
    if ( ! newspress_perf_enabled( 'disable_embeds', 1 ) ) {
        return;
    }
    wp_deregister_script( 'wp-embed' );
}
add_action( 'wp_footer', 'newspress_disable_embeds' );

function newspress_cleanup_head() {
    if ( newspress_perf_enabled( 'clean_head', 1 ) ) {
        remove_action( 'wp_head', 'wp_generator' );
        remove_action( 'wp_head', 'wlwmanifest_link' );
        remove_action( 'wp_head', 'rsd_link' );
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
    }
}
add_action( 'init', 'newspress_cleanup_head' );

function newspress_dequeue_unneeded_frontend_assets() {
    if ( is_admin() ) {
        return;
    }

    if ( newspress_perf_enabled( 'remove_block_css', 1 ) ) {
        wp_dequeue_style( 'wp-block-library' );
        wp_dequeue_style( 'wp-block-library-theme' );
        wp_dequeue_style( 'classic-theme-styles' );
    }

    if ( newspress_perf_enabled( 'remove_global_styles', 1 ) ) {
        wp_dequeue_style( 'global-styles' );
        remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
        remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
    }

    if ( newspress_perf_enabled( 'remove_dashicons_logged_out', 1 ) && ! is_user_logged_in() ) {
        wp_dequeue_style( 'dashicons' );
    }
}
add_action( 'wp_enqueue_scripts', 'newspress_dequeue_unneeded_frontend_assets', 100 );

function newspress_add_defer_to_theme_js( $tag, $handle, $src ) {
    if ( 'newspress-main' === $handle && newspress_perf_enabled( 'defer_theme_js', 1 ) && false === strpos( $tag, ' defer' ) ) {
        return str_replace( '<script ', '<script defer ', $tag );
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'newspress_add_defer_to_theme_js', 10, 3 );

function newspress_get_cached_home_hero_image_id() {
    $cache_key = 'newspress_home_hero_image_id';
    $image_id  = get_transient( $cache_key );

    if ( false !== $image_id ) {
        return absint( $image_id );
    }

    $home_sections = function_exists( 'newspress_get_home_sections' ) ? newspress_get_home_sections() : array();
    $cat = 0;
    foreach ( $home_sections as $section ) {
        if ( isset( $section['type'] ) && 'hero' === $section['type'] && ! empty( $section['category'] ) ) {
            $cat = absint( $section['category'] );
            break;
        }
    }

    $args = array(
        'posts_per_page'      => 1,
        'ignore_sticky_posts' => false,
        'post_status'         => 'publish',
        'fields'              => 'ids',
        'no_found_rows'       => true,
    );
    if ( $cat ) {
        $args['cat'] = $cat;
    }

    $ids = get_posts( $args );
    $image_id = ! empty( $ids[0] ) && has_post_thumbnail( $ids[0] ) ? get_post_thumbnail_id( $ids[0] ) : 0;
    set_transient( $cache_key, absint( $image_id ), HOUR_IN_SECONDS );

    return absint( $image_id );
}

function newspress_flush_home_hero_image_cache() {
    delete_transient( 'newspress_home_hero_image_id' );
}
add_action( 'save_post_post', 'newspress_flush_home_hero_image_cache' );
add_action( 'customize_save_after', 'newspress_flush_home_hero_image_cache' );

function newspress_resource_priority_hints() {
    if ( ! is_front_page() || ! newspress_perf_enabled( 'preload_hero_image', 1 ) ) {
        return;
    }

    $image_id = newspress_get_cached_home_hero_image_id();
    if ( ! $image_id ) {
        return;
    }

    $src    = wp_get_attachment_image_url( $image_id, 'newspress-hero' );
    $srcset = wp_get_attachment_image_srcset( $image_id, 'newspress-hero' );
    $sizes  = wp_get_attachment_image_sizes( $image_id, 'newspress-hero' );

    if ( ! $src ) {
        return;
    }

    echo '<link rel="preload" as="image" fetchpriority="high" href="' . esc_url( $src ) . '"';
    if ( $srcset ) { echo ' imagesrcset="' . esc_attr( $srcset ) . '"'; }
    if ( $sizes ) { echo ' imagesizes="' . esc_attr( $sizes ) . '"'; }
    echo '>' . "\n";
}
add_action( 'wp_head', 'newspress_resource_priority_hints', 3 );

function newspress_add_image_perf_attributes( $attr, $attachment, $size ) {
    if ( is_admin() || wp_doing_ajax() ) {
        return $attr;
    }

    $attachment_id = $attachment instanceof WP_Post ? (int) $attachment->ID : 0;

    if ( is_singular( 'post' ) && $attachment_id && (int) get_post_thumbnail_id( get_queried_object_id() ) === $attachment_id ) {
        $attr['loading']       = 'eager';
        $attr['fetchpriority'] = 'high';
        $attr['decoding']      = 'async';
        return $attr;
    }

    if ( empty( $attr['loading'] ) ) {
        $attr['loading'] = 'lazy';
    }

    if ( empty( $attr['decoding'] ) ) {
        $attr['decoding'] = 'async';
    }

    return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'newspress_add_image_perf_attributes', 10, 3 );

function newspress_img_attr_get( $tag, $name ) {
    if ( preg_match( "/\s" . preg_quote( $name, "/" ) . "\s*=\s*(\"|\')(.*?)\\1/i", $tag, $matches ) ) {
        return html_entity_decode( $matches[2], ENT_QUOTES, get_bloginfo( 'charset' ) );
    }
    return '';
}

function newspress_img_attr_set( $tag, $name, $value ) {
    $value = esc_attr( $value );
    if ( preg_match( "/\s" . preg_quote( $name, "/" ) . "\s*=\s*(\"|\')(.*?)\\1/i", $tag ) ) {
        return preg_replace( "/\s" . preg_quote( $name, "/" ) . "\s*=\s*(\"|\')(.*?)\\1/i", ' ' . $name . '="' . $value . '"', $tag, 1 );
    }
    return preg_replace( '/<img\b/i', '<img ' . $name . '="' . $value . '"', $tag, 1 );
}

function newspress_img_attr_remove_class_token( $tag, $token ) {
    $class = newspress_img_attr_get( $tag, 'class' );
    if ( '' === $class ) {
        return $tag;
    }

    $classes = preg_split( '/\s+/', trim( $class ) );
    $classes = array_values( array_filter( $classes, static function( $item ) use ( $token ) {
        return strtolower( $item ) !== strtolower( $token );
    } ) );

    return newspress_img_attr_set( $tag, 'class', implode( ' ', $classes ) );
}

function newspress_is_placeholder_image_src( $src ) {
    $src = trim( (string) $src );

    if ( '' === $src ) {
        return true;
    }

    if ( 0 === stripos( $src, 'data:image/gif;base64,R0lGODlhAQAB' ) ) {
        return true;
    }

    if ( 0 === stripos( $src, 'data:image/svg+xml' ) ) {
        return true;
    }

    return false;
}

function newspress_normalize_content_lazy_image_tag( $tag ) {
    $src = newspress_img_attr_get( $tag, 'src' );

    $real_src = '';
    foreach ( array( 'data-src', 'data-lazy-src', 'data-original', 'data-ll-src' ) as $lazy_attr ) {
        $candidate = newspress_img_attr_get( $tag, $lazy_attr );
        if ( $candidate && ! newspress_is_placeholder_image_src( $candidate ) ) {
            $real_src = $candidate;
            break;
        }
    }

    if ( $real_src && newspress_is_placeholder_image_src( $src ) ) {
        $tag = newspress_img_attr_set( $tag, 'src', esc_url_raw( $real_src ) );
    }

    $data_srcset = newspress_img_attr_get( $tag, 'data-srcset' );
    if ( $data_srcset && ! newspress_img_attr_get( $tag, 'srcset' ) ) {
        $tag = newspress_img_attr_set( $tag, 'srcset', $data_srcset );
    }

    $data_sizes = newspress_img_attr_get( $tag, 'data-sizes' );
    if ( $data_sizes && ! newspress_img_attr_get( $tag, 'sizes' ) && 'auto' !== strtolower( trim( $data_sizes ) ) ) {
        $tag = newspress_img_attr_set( $tag, 'sizes', $data_sizes );
    }

    $tag = newspress_img_attr_remove_class_token( $tag, 'lazyload' );
    $tag = newspress_img_attr_remove_class_token( $tag, 'lazyloaded' );

    if ( ! newspress_img_attr_get( $tag, 'loading' ) ) {
        $tag = newspress_img_attr_set( $tag, 'loading', 'lazy' );
    }

    if ( ! newspress_img_attr_get( $tag, 'decoding' ) ) {
        $tag = newspress_img_attr_set( $tag, 'decoding', 'async' );
    }

    return $tag;
}

function newspress_add_lazy_to_content_images( $content ) {
    if ( is_admin() || false === stripos( $content, '<img' ) ) {
        return $content;
    }

    return preg_replace_callback( '/<img\b[^>]*>/i', static function( $matches ) {
        return newspress_normalize_content_lazy_image_tag( $matches[0] );
    }, $content );
}
add_filter( 'the_content', 'newspress_add_lazy_to_content_images', 20 );

function newspress_add_lazy_to_avatar( $avatar ) {
    if ( is_admin() || false === strpos( $avatar, '<img' ) ) {
        return $avatar;
    }
    if ( false === strpos( $avatar, ' loading=' ) ) {
        $avatar = preg_replace( '/<img/i', '<img loading="lazy"', $avatar, 1 );
    }
    if ( false === strpos( $avatar, ' decoding=' ) ) {
        $avatar = preg_replace( '/<img/i', '<img decoding="async"', $avatar, 1 );
    }
    return $avatar;
}
add_filter( 'get_avatar', 'newspress_add_lazy_to_avatar', 20 );
