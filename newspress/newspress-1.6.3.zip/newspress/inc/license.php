<?php
/**
 * NewsPress lightweight local license validation.
 *
 * Supports CryptoJS/OpenSSL-compatible salted AES passphrase keys.
 * This is deterrent-level protection for local/domain validation.
 *
 * @package NewsPress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function newspress_license_secret() {
    $parts = array(
        'bmV3',       // new
        'c3A=',       // sp
        'cmVzcw==',   // ress
        'QEA=',       // @@
        'IyM=',       // ##
        'Mjc=',       // 27
    );

    $secret = '';
    foreach ( $parts as $part ) {
        $decoded = base64_decode( $part, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        if ( false !== $decoded ) {
            $secret .= $decoded;
        }
    }

    return $secret;
}

function newspress_license_normalize_domain( $domain ) {
    $domain = strtolower( trim( (string) $domain ) );
    $domain = preg_replace( '#^https?://#', '', $domain );
    $domain = preg_replace( '#/.*$#', '', $domain );
    $domain = preg_replace( '#:\\d+$#', '', $domain );
    $domain = preg_replace( '#^www\\.#', '', $domain );

    return sanitize_text_field( $domain );
}

function newspress_license_current_domain() {
    $host = wp_parse_url( home_url(), PHP_URL_HOST );

    return newspress_license_normalize_domain( $host );
}

function newspress_license_evp_bytes_to_key( $password, $salt, $key_len = 32, $iv_len = 16 ) {
    $derived = '';
    $block   = '';

    while ( strlen( $derived ) < ( $key_len + $iv_len ) ) {
        $block    = md5( $block . $password . $salt, true );
        $derived .= $block;
    }

    return array(
        substr( $derived, 0, $key_len ),
        substr( $derived, $key_len, $iv_len ),
    );
}

function newspress_license_decrypt_cryptojs( $encrypted, $password = '' ) {
    if ( ! function_exists( 'openssl_decrypt' ) ) {
        return false;
    }

    $encrypted = trim( (string) $encrypted );
    $password  = '' !== $password ? $password : newspress_license_secret();
    $raw       = base64_decode( $encrypted, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

    if ( ! $raw || strlen( $raw ) < 17 ) {
        return false;
    }

    if ( 'Salted__' !== substr( $raw, 0, 8 ) ) {
        return false;
    }

    $salt       = substr( $raw, 8, 8 );
    $ciphertext = substr( $raw, 16 );
    list( $key, $iv ) = newspress_license_evp_bytes_to_key( $password, $salt );

    $plain = openssl_decrypt( $ciphertext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

    if ( false === $plain ) {
        return false;
    }

    return trim( $plain );
}

function newspress_license_date_timestamp( $date, $end_of_day = false ) {
    $date = trim( (string) $date );

    if ( '' === $date ) {
        return 0;
    }

    if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
        $date .= $end_of_day ? ' 23:59:59' : ' 00:00:00';
    }

    $timestamp = strtotime( $date );

    return $timestamp ? absint( $timestamp ) : 0;
}

function newspress_license_days_remaining( $expires_at ) {
    $expires_ts = newspress_license_date_timestamp( $expires_at, true );

    if ( ! $expires_ts ) {
        return null;
    }

    return (int) ceil( ( $expires_ts - current_time( 'timestamp' ) ) / DAY_IN_SECONDS );
}

function newspress_license_parse_payload( $plain ) {
    $plain = trim( (string) $plain );

    $payload = array(
        'format'           => 'legacy',
        'valid_payload'    => false,
        'error'            => '',
        'product'          => '',
        'product_name'     => '',
        'license_mode'     => 'encrypted_domain',
        'license_type'     => 'legacy',
        'issued_at'        => '',
        'expires_at'       => '',
        'root_domain'      => '',
        'domain_scope'     => '',
        'allow_subdomains' => false,
        'domains'          => array(),
    );

    if ( '' === $plain ) {
        $payload['error'] = 'empty';
        return $payload;
    }

    $json = json_decode( $plain, true );

    if ( is_array( $json ) ) {
        $product = ! empty( $json['product'] ) ? sanitize_key( $json['product'] ) : '';

        $payload['format']           = 'json';
        $payload['product']          = $product;
        $payload['product_name']     = ! empty( $json['product_name'] ) ? sanitize_text_field( $json['product_name'] ) : 'NewsPress';
        $payload['license_mode']     = ! empty( $json['license_mode'] ) ? sanitize_key( $json['license_mode'] ) : '';
        $payload['license_type']     = ! empty( $json['license_type'] ) ? sanitize_key( $json['license_type'] ) : '';
        $payload['issued_at']        = ! empty( $json['issued_at'] ) ? sanitize_text_field( $json['issued_at'] ) : '';
        $payload['expires_at']       = ! empty( $json['expires_at'] ) ? sanitize_text_field( $json['expires_at'] ) : '';
        $payload['root_domain']      = ! empty( $json['root_domain'] ) ? newspress_license_normalize_domain( $json['root_domain'] ) : '';
        $payload['domain_scope']     = ! empty( $json['domain_scope'] ) ? sanitize_text_field( $json['domain_scope'] ) : '';
        $payload['allow_subdomains'] = ! empty( $json['allow_subdomains'] );

        if ( '' !== $product && 'newspress' !== $product ) {
            $payload['error'] = 'invalid_product';
            return $payload;
        }

        $domains = array();

        if ( ! empty( $json['domain'] ) ) {
            $domains[] = newspress_license_normalize_domain( $json['domain'] );
        }

        if ( ! empty( $json['domains'] ) && is_array( $json['domains'] ) ) {
            $domains = array_merge( $domains, array_map( 'newspress_license_normalize_domain', $json['domains'] ) );
        }

        // Wildcard subdomain support is intentionally limited to the new lifetime JSON mode.
        if ( 'lifetime' === $payload['license_type'] && $payload['allow_subdomains'] && $payload['root_domain'] ) {
            $domains[] = $payload['root_domain'];
            $domains[] = '*.' . $payload['root_domain'];
        }

        $domains = array_values( array_unique( array_filter( $domains ) ) );

        $payload['domains']       = $domains;
        $payload['valid_payload'] = ! empty( $domains );

        if ( ! $payload['valid_payload'] ) {
            $payload['error'] = 'missing_domain';
        }

        return $payload;
    }

    $parts = preg_split( '/[\s,|;]+/', $plain );
    $domains = array_values( array_unique( array_filter( array_map( 'newspress_license_normalize_domain', (array) $parts ) ) ) );

    $payload['domains']       = $domains;
    $payload['valid_payload'] = ! empty( $domains );

    if ( ! $payload['valid_payload'] ) {
        $payload['error'] = 'missing_domain';
    }

    return $payload;
}

function newspress_license_parse_domains( $plain ) {
    $payload = newspress_license_parse_payload( $plain );

    return ! empty( $payload['domains'] ) ? $payload['domains'] : array();
}

function newspress_license_domain_matches( $current, $licensed ) {
    $current  = newspress_license_normalize_domain( $current );
    $licensed = strtolower( trim( (string) $licensed ) );

    if ( '' === $current || '' === $licensed ) {
        return false;
    }

    if ( 0 === strpos( $licensed, '*.' ) ) {
        $root = newspress_license_normalize_domain( substr( $licensed, 2 ) );

        if ( '' === $root ) {
            return false;
        }

        return $current === $root || substr( $current, -1 * ( strlen( $root ) + 1 ) ) === '.' . $root;
    }

    $licensed = newspress_license_normalize_domain( $licensed );

    return hash_equals( $licensed, $current );
}

function newspress_license_core_available() {
    return function_exists( 'newspress_license_secret' )
        && function_exists( 'newspress_license_decrypt_cryptojs' )
        && function_exists( 'newspress_license_current_domain' )
        && function_exists( 'newspress_license_domain_matches' );
}

function newspress_license_integrity_token() {
    if ( ! function_exists( 'newspress_license_secret' ) ) {
        return '';
    }

    return hash( 'sha256', 'newspress|local-license|cryptojs|domain|1.4|' . newspress_license_secret() );
}

function newspress_license_integrity_valid() {
    $expected = '9590bdeb621d093baac62ca329b7c9bb4a5ce2e8d09d701640097d5b4346c543';

    return hash_equals( $expected, newspress_license_integrity_token() );
}

function newspress_license_get_key() {
    return trim( (string) get_option( 'newspress_license_key', '' ) );
}

function newspress_license_get_status() {
    $key     = newspress_license_get_key();
    $current = newspress_license_current_domain();

    $status = array(
        'valid'            => false,
        'status'           => 'empty',
        'current_domain'   => $current,
        'licensed_domain'  => '',
        'message'          => __( 'License key is empty.', 'newspress' ),
        'plain'            => '',
        'format'           => '',
        'product'          => '',
        'product_name'     => '',
        'license_mode'     => '',
        'license_type'     => '',
        'issued_at'        => '',
        'expires_at'       => '',
        'remaining_days'   => null,
        'root_domain'      => '',
        'domain_scope'     => '',
        'allow_subdomains' => false,
        'integrity_valid'   => newspress_license_integrity_valid(),
        'integrity_message' => newspress_license_integrity_valid() ? __( 'Official license files detected.', 'newspress' ) : __( 'License validation files may differ from the official package. License validity is checked from the decrypted key data.', 'newspress' ),
        'validation_source' => __( 'Decrypted license key data: product, domain, license type, and expiration date.', 'newspress' ),
    );

    if ( ! newspress_license_core_available() ) {
        $status['status']  = 'tampered';
        $status['message'] = __( 'License validation core is not available. Please reinstall the official NewsPress package.', 'newspress' );
        return $status;
    }

    if ( '' === $key ) {
        return $status;
    }

    $plain = newspress_license_decrypt_cryptojs( $key );

    if ( ! $plain ) {
        $status['status']  = 'invalid_key';
        $status['message'] = __( 'License key cannot be decrypted.', 'newspress' );
        return $status;
    }

    $payload = newspress_license_parse_payload( $plain );

    $status['plain']            = $plain;
    $status['format']           = $payload['format'];
    $status['product']          = $payload['product'];
    $status['product_name']     = $payload['product_name'];
    $status['license_mode']     = $payload['license_mode'];
    $status['license_type']     = $payload['license_type'];
    $status['issued_at']        = $payload['issued_at'];
    $status['expires_at']       = $payload['expires_at'];
    $status['remaining_days']   = newspress_license_days_remaining( $payload['expires_at'] );
    $status['root_domain']      = $payload['root_domain'];
    $status['domain_scope']     = $payload['domain_scope'];
    $status['allow_subdomains'] = $payload['allow_subdomains'];

    if ( 'invalid_product' === $payload['error'] ) {
        $status['status']  = 'invalid_product';
        $status['message'] = __( 'License key is not for NewsPress.', 'newspress' );
        return $status;
    }

    if ( ! $payload['valid_payload'] ) {
        $status['status']  = 'invalid_payload';
        $status['message'] = __( 'License key does not contain a valid NewsPress domain.', 'newspress' );
        return $status;
    }

    if ( 'json' === $payload['format'] && 'lifetime' !== $payload['license_type'] && ! empty( $payload['expires_at'] ) ) {
        $expires_ts = newspress_license_date_timestamp( $payload['expires_at'], true );

        if ( $expires_ts && current_time( 'timestamp' ) > $expires_ts ) {
            $status['status']          = 'expired';
            $status['licensed_domain'] = implode( ', ', $payload['domains'] );
            $status['message']         = sprintf(
                /* translators: %s: license expiration date. */
                __( 'License expired on %s.', 'newspress' ),
                $payload['expires_at']
            );
            return $status;
        }
    }

    foreach ( $payload['domains'] as $domain ) {
        if ( newspress_license_domain_matches( $current, $domain ) ) {
            $status['valid']           = true;
            $status['status']          = 'active';
            $status['licensed_domain'] = $domain;
            $status['message']         = __( 'License is active.', 'newspress' );
            return $status;
        }
    }

    $status['status']          = 'domain_mismatch';
    $status['licensed_domain'] = implode( ', ', $payload['domains'] );
    $status['message']         = __( 'License key is not valid for this domain.', 'newspress' );

    return $status;
}

function newspress_license_is_valid() {
    $status = newspress_license_get_status();

    return ! empty( $status['valid'] );
}

function newspress_license_can_use_premium_feature() {
    return newspress_license_core_available() && newspress_license_is_valid();
}

function newspress_license_grace_period_seconds() {
    return (int) apply_filters( 'newspress_license_grace_period_seconds', DAY_IN_SECONDS );
}

function newspress_license_grace_started_at() {
    $started = absint( get_option( 'newspress_license_grace_started_at', 0 ) );

    if ( ! $started ) {
        $started = current_time( 'timestamp' );
        update_option( 'newspress_license_grace_started_at', $started, false );
    }

    return $started;
}

function newspress_license_grace_deadline() {
    return newspress_license_grace_started_at() + newspress_license_grace_period_seconds();
}

function newspress_license_grace_expired() {
    $status = newspress_license_get_status();

    if ( ! empty( $status['valid'] ) || 'expired' === $status['status'] ) {
        return false;
    }

    return current_time( 'timestamp' ) > newspress_license_grace_deadline();
}

function newspress_license_format_timestamp( $timestamp ) {
    $format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

    return date_i18n( $format, absint( $timestamp ) );
}

function newspress_license_deadline_text() {
    return newspress_license_format_timestamp( newspress_license_grace_deadline() );
}

function newspress_license_update_grace_state() {
    $status = newspress_license_get_status();

    if ( ! empty( $status['valid'] ) || 'expired' === $status['status'] ) {
        delete_option( 'newspress_license_grace_started_at' );
        return;
    }

    newspress_license_grace_started_at();
}
add_action( 'init', 'newspress_license_update_grace_state', 1 );
add_action( 'after_switch_theme', 'newspress_license_grace_started_at' );

function newspress_license_block_customizer() {
    if ( newspress_license_is_valid() ) {
        return;
    }

    $status = newspress_license_get_status();

    $message  = '<h1>' . esc_html__( 'NewsPress License Required', 'newspress' ) . '</h1>';
    $message .= '<p>' . esc_html( $status['message'] ) . '</p>';
    if ( 'expired' !== $status['status'] ) {
        $message .= '<p><strong>' . esc_html__( 'Activation deadline:', 'newspress' ) . '</strong> ' . esc_html( newspress_license_deadline_text() ) . '</p>';
    }
    $message .= '<p><a class="button button-primary" href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'Open NewsPress License', 'newspress' ) . '</a></p>';

    wp_die( $message, esc_html__( 'NewsPress License Required', 'newspress' ), array( 'response' => 403 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_license_maybe_block_customizer_request() {
    global $pagenow;

    if ( is_admin() && 'customize.php' === $pagenow ) {
        newspress_license_block_customizer();
    }
}
add_action( 'admin_init', 'newspress_license_maybe_block_customizer_request', 1 );
add_action( 'customize_controls_init', 'newspress_license_block_customizer', 1 );

function newspress_license_frontend_redirect_notice() {
    if ( is_admin() || wp_doing_ajax() || wp_is_json_request() || newspress_license_is_valid() || ! newspress_license_grace_expired() ) {
        return;
    }

    $current_domain = newspress_license_current_domain();
    if ( 'yztheme.my.id' === $current_domain ) {
        return;
    }

    $message = __( 'Situs ini belum mengaktifkan lisensi. Dapatkan lisensi resmi di member area YzTheme.', 'newspress' );
    $target  = 'https://yztheme.my.id/';
    ?>
    <script>
    (function(){
        var message = <?php echo wp_json_encode( $message ); ?>;
        var target = <?php echo wp_json_encode( $target ); ?>;
        try { window.alert(message); } catch(e) {}
        window.setTimeout(function(){ window.location.href = target; }, 10000);
    })();
    </script>
    <?php
}
add_action( 'wp_footer', 'newspress_license_frontend_redirect_notice', 999 );

function newspress_license_admin_menu() {
    add_theme_page(
        __( 'NewsPress License', 'newspress' ),
        __( 'NewsPress License', 'newspress' ),
        'manage_options',
        'newspress-license',
        'newspress_license_admin_page'
    );
}
add_action( 'admin_menu', 'newspress_license_admin_menu' );

function newspress_license_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( isset( $_POST['newspress_license_save'] ) && isset( $_POST['newspress_license_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['newspress_license_nonce'] ) ), 'newspress_license_action' ) ) {
        $key = isset( $_POST['newspress_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['newspress_license_key'] ) ) : '';
        update_option( 'newspress_license_key', $key, false );
        delete_transient( 'newspress_license_status' );
        if ( newspress_license_is_valid() ) {
            delete_option( 'newspress_license_grace_started_at' );
        } else {
            newspress_license_grace_started_at();
        }
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'License key saved.', 'newspress' ) . '</p></div>';
    }

    $status = newspress_license_get_status();
    ?>
    <div class="wrap newspress-license-page">
        <h1><?php esc_html_e( 'NewsPress License', 'newspress' ); ?></h1>

        <?php if ( $status['valid'] ) : ?>
            <div class="notice notice-success inline"><p><strong><?php esc_html_e( 'Active:', 'newspress' ); ?></strong> <?php echo esc_html( $status['licensed_domain'] ); ?></p></div>
        <?php elseif ( 'expired' === $status['status'] ) : ?>
            <div class="notice notice-warning inline"><p><strong><?php esc_html_e( 'Expired:', 'newspress' ); ?></strong> <?php echo esc_html( $status['message'] ); ?></p></div>
        <?php else : ?>
            <div class="notice notice-error inline"><p><strong><?php esc_html_e( 'Inactive:', 'newspress' ); ?></strong> <?php echo esc_html( $status['message'] ); ?></p></div>
        <?php endif; ?>

        <?php if ( empty( $status['integrity_valid'] ) ) : ?>
            <div class="notice notice-warning inline"><p><strong><?php esc_html_e( 'File integrity warning:', 'newspress' ); ?></strong> <?php echo esc_html( $status['integrity_message'] ); ?></p></div>
        <?php endif; ?>

        <table class="widefat striped" style="max-width:760px;margin:16px 0;">
            <tbody>
                <tr>
                    <th style="width:220px;"><?php esc_html_e( 'Current domain', 'newspress' ); ?></th>
                    <td><code><?php echo esc_html( $status['current_domain'] ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Licensed domain', 'newspress' ); ?></th>
                    <td><code><?php echo esc_html( $status['licensed_domain'] ? $status['licensed_domain'] : '-' ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'License type', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['license_type'] ? $status['license_type'] : '-' ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'License mode', 'newspress' ); ?></th>
                    <td><code><?php echo esc_html( $status['license_mode'] ? $status['license_mode'] : '-' ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Issued at', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['issued_at'] ? $status['issued_at'] : '-' ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Expires at', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['expires_at'] ? $status['expires_at'] : ( 'lifetime' === $status['license_type'] ? __( 'Lifetime', 'newspress' ) : '-' ) ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Remaining', 'newspress' ); ?></th>
                    <td><?php echo null !== $status['remaining_days'] ? esc_html( max( 0, (int) $status['remaining_days'] ) . ' ' . __( 'days', 'newspress' ) ) : '-'; ?></td>
                </tr>
                <?php if ( ! empty( $status['allow_subdomains'] ) && ! empty( $status['root_domain'] ) ) : ?>
                    <tr>
                        <th><?php esc_html_e( 'Subdomain wildcard', 'newspress' ); ?></th>
                        <td><code><?php echo esc_html( '*.' . $status['root_domain'] ); ?></code></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th><?php esc_html_e( 'Validation source', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['validation_source'] ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'File integrity', 'newspress' ); ?></th>
                    <td><?php echo ! empty( $status['integrity_valid'] ) ? esc_html__( 'OK', 'newspress' ) : esc_html__( 'Warning', 'newspress' ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Status', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['message'] ); ?></td>
                </tr>
                <?php if ( ! $status['valid'] && 'expired' !== $status['status'] ) : ?>
                    <tr>
                        <th><?php esc_html_e( 'Activation deadline', 'newspress' ); ?></th>
                        <td><strong><?php echo esc_html( newspress_license_deadline_text() ); ?></strong></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        $newspress_license_diagnostic = array(
            'theme_version'     => defined( 'NEWSPRESS_VERSION' ) ? NEWSPRESS_VERSION : wp_get_theme()->get( 'Version' ),
            'current_domain'    => $status['current_domain'],
            'license_status'    => $status['status'],
            'license_valid'     => ! empty( $status['valid'] ) ? 'yes' : 'no',
            'licensed_domain'   => $status['licensed_domain'],
            'license_type'      => $status['license_type'],
            'license_mode'      => $status['license_mode'],
            'issued_at'         => $status['issued_at'],
            'expires_at'        => $status['expires_at'],
            'remaining_days'    => null === $status['remaining_days'] ? '' : $status['remaining_days'],
            'root_domain'       => $status['root_domain'],
            'allow_subdomains'  => ! empty( $status['allow_subdomains'] ) ? 'yes' : 'no',
            'integrity_status'  => ! empty( $status['integrity_valid'] ) ? 'ok' : 'warning',
            'validation_source' => $status['validation_source'],
            'message'           => $status['message'],
        );
        $newspress_license_diagnostic_text = '';
        foreach ( $newspress_license_diagnostic as $diagnostic_key => $diagnostic_value ) {
            $newspress_license_diagnostic_text .= $diagnostic_key . ': ' . $diagnostic_value . "\n";
        }
        ?>
        <div style="max-width:760px;margin:16px 0;padding:14px 16px;border:1px solid #dcdcde;background:#fff;border-left:4px solid #2271b1;">
            <p style="margin:0 0 10px;"><strong><?php esc_html_e( 'License diagnostic', 'newspress' ); ?></strong></p>
            <textarea id="newspress-license-diagnostic" class="large-text code" rows="8" readonly><?php echo esc_textarea( $newspress_license_diagnostic_text ); ?></textarea>
            <p style="margin:10px 0 0;"><button type="button" class="button" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('newspress-license-diagnostic').value);"><?php esc_html_e( 'Copy License Diagnostic', 'newspress' ); ?></button></p>
        </div>

        <form method="post" style="max-width:760px;">
            <?php wp_nonce_field( 'newspress_license_action', 'newspress_license_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="newspress_license_key"><?php esc_html_e( 'License key', 'newspress' ); ?></label></th>
                    <td>
                        <textarea id="newspress_license_key" name="newspress_license_key" rows="4" class="large-text code" placeholder="U2FsdGVkX1..."><?php echo esc_textarea( newspress_license_get_key() ); ?></textarea>
                        <p class="description">
                            <?php esc_html_e( 'Paste license key for this domain.', 'newspress' ); ?>
                            <a href="<?php echo esc_url( 'https://www.yztheme.my.id/p/member-area.html' ); ?>" target="_blank" rel="noopener noreferrer">
                                <?php esc_html_e( 'Open YzTheme member Area.', 'newspress' ); ?>
                            </a>
                        </p>
                    </td>
                </tr>
            </table>
            <?php
            $newspress_license_support_text = rawurlencode( __( 'Halo Admin YzTheme, saya membutuhkan bantuan untuk lisensi NewsPress.', 'newspress' ) );
            $newspress_license_support_url  = 'https://wa.me/6289507785333?text=' . $newspress_license_support_text;
            ?>
            <p>
                <button type="submit" name="newspress_license_save" class="button button-primary"><?php esc_html_e( 'Save License', 'newspress' ); ?></button>
                <a class="button" href="<?php echo esc_url( $newspress_license_support_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'WA Support', 'newspress' ); ?></a>
            </p>
        </form>
    </div>
    <?php
}

function newspress_license_admin_notice() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( $screen && in_array( $screen->id, array( 'appearance_page_newspress-license', 'appearance_page_newspress-demo-import' ), true ) ) {
        return;
    }

    $status = newspress_license_get_status();

    if ( ! empty( $status['valid'] ) ) {
        if ( empty( $status['integrity_valid'] ) ) {
            echo '<div class="notice notice-warning"><p>';
            echo esc_html__( 'NewsPress license is active based on decrypted key data. File integrity has a warning; reinstall the official NewsPress package only if activation issues occur.', 'newspress' );
            echo ' <a href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'View diagnostic', 'newspress' ) . '</a>';
            echo '</p></div>';
        }
        return;
    }

    if ( 'expired' === $status['status'] ) {
        echo '<div class="notice notice-warning"><p>';
        echo esc_html__( 'NewsPress annual license has expired. The frontend remains active, but updates and premium admin features require renewal.', 'newspress' );
        echo ' <a href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'Renew license', 'newspress' ) . '</a>';
        echo '</p></div>';
        return;
    }

    $expired = newspress_license_grace_expired();

    echo '<div class="notice ' . ( $expired ? 'notice-error' : 'notice-warning' ) . '"><p>';
    echo esc_html__( 'NewsPress license is not active for this domain.', 'newspress' );
    echo ' <strong>' . esc_html__( 'Activation deadline:', 'newspress' ) . '</strong> ' . esc_html( newspress_license_deadline_text() ) . '.';
    if ( $expired ) {
        echo ' ' . esc_html__( 'The grace period has expired; frontend visitors will see a license alert and be redirected to YzTheme.', 'newspress' );
    }
    echo ' <a href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'Activate license', 'newspress' ) . '</a>';
    echo '</p></div>';
}
add_action( 'admin_notices', 'newspress_license_admin_notice' );
