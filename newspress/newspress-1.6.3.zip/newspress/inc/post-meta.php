<?php
/**
 * Post editor SEO fields for NewsPress.
 *
 * The dashboard panel is intentionally minimal: Google preview + meta description.
 * Advanced SEO fields were removed from the editor to avoid hidden behaviour.
 *
 * @package NewsPress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'NEWSPRESS_META_DESCRIPTION_KEY', '_newspress_meta_description' );
define( 'NEWSPRESS_SHOW_META_DESCRIPTION_KEY', '_newspress_show_meta_description' );
define( 'NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY', '_newspress_hide_author_profile' );
define( 'NEWSPRESS_SCHEMA_TYPE_KEY', '_newspress_schema_type' );
define( 'NEWSPRESS_DISABLE_TOC_KEY', '_newspress_disable_toc' );

// Legacy constants kept only for safe cleanup/backward compatibility.
define( 'NEWSPRESS_SEO_TITLE_KEY', '_newspress_seo_title' );
define( 'NEWSPRESS_FOCUS_KEYPHRASE_KEY', '_newspress_focus_keyphrase' );
define( 'NEWSPRESS_CANONICAL_URL_KEY', '_newspress_canonical_url' );
define( 'NEWSPRESS_ROBOTS_NOINDEX_KEY', '_newspress_robots_noindex' );
define( 'NEWSPRESS_OG_TITLE_KEY', '_newspress_og_title' );
define( 'NEWSPRESS_OG_DESCRIPTION_KEY', '_newspress_og_description' );
define( 'NEWSPRESS_OG_IMAGE_KEY', '_newspress_og_image' );
define( 'NEWSPRESS_TWITTER_TITLE_KEY', '_newspress_twitter_title' );
define( 'NEWSPRESS_TWITTER_DESCRIPTION_KEY', '_newspress_twitter_description' );

function newspress_seo_meta_definitions() {
    return array(
        NEWSPRESS_META_DESCRIPTION_KEY      => array( 'type' => 'string', 'sanitize_callback' => 'newspress_sanitize_meta_description' ),
        NEWSPRESS_SHOW_META_DESCRIPTION_KEY => array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean' ),
        NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY => array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean' ),
        NEWSPRESS_SCHEMA_TYPE_KEY => array( 'type' => 'string', 'sanitize_callback' => 'newspress_sanitize_schema_type' ),
        NEWSPRESS_DISABLE_TOC_KEY => array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean' ),
    );
}

function newspress_register_post_meta_fields() {
    foreach ( newspress_seo_meta_definitions() as $key => $args ) {
        register_post_meta(
            'post',
            $key,
            array(
                'type'              => $args['type'],
                'single'            => true,
                'show_in_rest'      => true,
                'sanitize_callback' => $args['sanitize_callback'],
                'auth_callback'     => function( $allowed, $meta_key, $post_id ) {
                    $post_id = absint( $post_id );
                    return $post_id ? current_user_can( 'edit_post', $post_id ) : current_user_can( 'edit_posts' );
                },
            )
        );
    }
}
add_action( 'init', 'newspress_register_post_meta_fields' );

function newspress_sanitize_schema_type( $value ) {
    return in_array( $value, array( 'Article', 'NewsArticle' ), true ) ? $value : 'NewsArticle';
}

function newspress_sanitize_meta_description( $value ) {
    $value = wp_strip_all_tags( (string) $value );
    $value = html_entity_decode( $value, ENT_QUOTES, get_bloginfo( 'charset' ) );
    $value = preg_replace( '/\s+/u', ' ', $value );
    $value = trim( sanitize_text_field( $value ) );

    if ( function_exists( 'mb_substr' ) && mb_strlen( $value ) > 320 ) {
        $value = mb_substr( $value, 0, 320 );
    } elseif ( strlen( $value ) > 320 ) {
        $value = substr( $value, 0, 320 );
    }

    return trim( $value );
}

function newspress_add_meta_description_box() {
    add_meta_box(
        'newspress_meta_description_box',
        __( 'NewsPress SEO Panel', 'newspress' ),
        'newspress_render_meta_description_box',
        'post',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'newspress_add_meta_description_box' );

function newspress_get_post_meta_string( $post_id, $key ) {
    $value = get_post_meta( $post_id, $key, true );
    return is_string( $value ) ? $value : '';
}

function newspress_render_meta_description_box( $post ) {
    wp_nonce_field( 'newspress_save_meta_description', 'newspress_meta_description_nonce' );

    $description      = newspress_get_post_meta_string( $post->ID, NEWSPRESS_META_DESCRIPTION_KEY );
    $show_description = (bool) get_post_meta( $post->ID, NEWSPRESS_SHOW_META_DESCRIPTION_KEY, true );
    $show_author      = ! (bool) get_post_meta( $post->ID, NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY, true );
    $schema_type      = newspress_sanitize_schema_type( get_post_meta( $post->ID, NEWSPRESS_SCHEMA_TYPE_KEY, true ) ?: 'NewsArticle' );
    $show_toc         = ! (bool) get_post_meta( $post->ID, NEWSPRESS_DISABLE_TOC_KEY, true );
    $permalink        = get_permalink( $post );
    $preview_image    = has_post_thumbnail( $post ) ? wp_get_attachment_image_url( get_post_thumbnail_id( $post ), 'medium_large' ) : '';
    ?>
    <div class="newspress-seo-panel" data-site-name="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" data-post-url="<?php echo esc_url( $permalink ); ?>">
        <div class="newspress-seo-preview" aria-live="polite">
            <div class="newspress-seo-preview-label"><?php esc_html_e( 'Google Preview', 'newspress' ); ?></div>
            <div class="newspress-seo-preview-card">
                <div class="newspress-seo-preview-text">
                    <div class="newspress-seo-preview-title" id="newspress_seo_preview_title"><?php echo esc_html( get_the_title( $post ) ); ?></div>
                    <div class="newspress-seo-preview-url"><?php echo esc_html( $permalink ); ?></div>
                    <div class="newspress-seo-preview-desc" id="newspress_seo_preview_desc"><?php echo esc_html( $description ? $description : __( 'Meta description preview will appear here.', 'newspress' ) ); ?></div>
                </div>
                <div class="newspress-seo-preview-image<?php echo $preview_image ? '' : ' is-empty'; ?>" id="newspress_seo_preview_image" aria-hidden="true">
                    <?php if ( $preview_image ) : ?>
                        <img src="<?php echo esc_url( $preview_image ); ?>" alt="">
                    <?php else : ?>
                        <span><?php esc_html_e( 'No image', 'newspress' ); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <p class="newspress-seo-field">
            <label for="newspress_meta_description"><strong><?php esc_html_e( 'Meta description', 'newspress' ); ?></strong></label>
            <textarea id="newspress_meta_description" name="newspress_meta_description" rows="4" maxlength="320" placeholder="<?php esc_attr_e( 'Write a concise summary of this article...', 'newspress' ); ?>"><?php echo esc_textarea( $description ); ?></textarea>
            <span class="newspress-seo-counter"><strong id="newspress_meta_description_count"><?php echo esc_html( function_exists( 'mb_strlen' ) ? mb_strlen( trim( $description ) ) : strlen( trim( $description ) ) ); ?></strong>/160</span>
            <span class="description"><?php esc_html_e( 'Recommended length: 140–160 characters. Empty field falls back to excerpt/content.', 'newspress' ); ?></span>
        </p>

        <p>
            <label for="newspress_show_meta_description" class="newspress-check-label">
                <input type="checkbox" id="newspress_show_meta_description" name="newspress_show_meta_description" value="1" <?php checked( $show_description ); ?> />
                <span><?php esc_html_e( 'Show this meta description between the post title and post meta on the article page.', 'newspress' ); ?></span>
            </label>
        </p>

        <p class="newspress-seo-field">
            <label for="newspress_schema_type"><strong><?php esc_html_e( 'Schema type', 'newspress' ); ?></strong></label>
            <select id="newspress_schema_type" name="newspress_schema_type">
                <option value="NewsArticle" <?php selected( $schema_type, 'NewsArticle' ); ?>><?php esc_html_e( 'NewsArticle — default for news', 'newspress' ); ?></option>
                <option value="Article" <?php selected( $schema_type, 'Article' ); ?>><?php esc_html_e( 'Article — better for blog/evergreen articles', 'newspress' ); ?></option>
            </select>
        </p>

        <p>
            <label for="newspress_show_toc" class="newspress-check-label">
                <input type="checkbox" id="newspress_show_toc" name="newspress_show_toc" value="1" <?php checked( $show_toc ); ?> />
                <span><?php esc_html_e( 'Show automatic table of contents when the article has enough headings.', 'newspress' ); ?></span>
            </label>
        </p>

        <p>
            <label for="newspress_show_author_profile" class="newspress-check-label">
                <input type="checkbox" id="newspress_show_author_profile" name="newspress_show_author_profile" value="1" <?php checked( $show_author ); ?> />
                <span><?php esc_html_e( 'Show author profile box on the article page.', 'newspress' ); ?></span>
            </label>
        </p>
    </div>
    <?php
}

function newspress_save_meta_description( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    if ( ! isset( $_POST['newspress_meta_description_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['newspress_meta_description_nonce'] ) ), 'newspress_save_meta_description' ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $description = isset( $_POST['newspress_meta_description'] ) ? newspress_sanitize_meta_description( wp_unslash( $_POST['newspress_meta_description'] ) ) : '';
    if ( '' === $description ) {
        delete_post_meta( $post_id, NEWSPRESS_META_DESCRIPTION_KEY );
    } else {
        update_post_meta( $post_id, NEWSPRESS_META_DESCRIPTION_KEY, $description );
    }

    if ( isset( $_POST['newspress_show_meta_description'] ) ) {
        update_post_meta( $post_id, NEWSPRESS_SHOW_META_DESCRIPTION_KEY, 1 );
    } else {
        delete_post_meta( $post_id, NEWSPRESS_SHOW_META_DESCRIPTION_KEY );
    }

    if ( isset( $_POST['newspress_show_author_profile'] ) ) {
        delete_post_meta( $post_id, NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY );
    } else {
        update_post_meta( $post_id, NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY, 1 );
    }

    $schema_type = isset( $_POST['newspress_schema_type'] ) ? newspress_sanitize_schema_type( sanitize_text_field( wp_unslash( $_POST['newspress_schema_type'] ) ) ) : 'NewsArticle';
    update_post_meta( $post_id, NEWSPRESS_SCHEMA_TYPE_KEY, $schema_type );

    if ( isset( $_POST['newspress_show_toc'] ) ) {
        delete_post_meta( $post_id, NEWSPRESS_DISABLE_TOC_KEY );
    } else {
        update_post_meta( $post_id, NEWSPRESS_DISABLE_TOC_KEY, 1 );
    }

    // Clean legacy fields that are no longer exposed in the editor to prevent hidden SEO output.
    foreach ( array( NEWSPRESS_SEO_TITLE_KEY, NEWSPRESS_FOCUS_KEYPHRASE_KEY, NEWSPRESS_CANONICAL_URL_KEY, NEWSPRESS_ROBOTS_NOINDEX_KEY, NEWSPRESS_OG_TITLE_KEY, NEWSPRESS_OG_DESCRIPTION_KEY, NEWSPRESS_OG_IMAGE_KEY, NEWSPRESS_TWITTER_TITLE_KEY, NEWSPRESS_TWITTER_DESCRIPTION_KEY ) as $legacy_key ) {
        delete_post_meta( $post_id, $legacy_key );
    }
}
add_action( 'save_post_post', 'newspress_save_meta_description' );

function newspress_meta_description_admin_script( $hook ) {
    if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || 'post' !== $screen->post_type ) {
        return;
    }
    ?>
    <script>
    (function(){
        var mediaCache = {};
        function charLength(value){
            value = (value || '').trim();
            if (window.Intl && Intl.Segmenter) {
                try {
                    var seg = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
                    return Array.from(seg.segment(value)).length;
                } catch(e) {}
            }
            return Array.from(value).length;
        }
        function getEditorTitle(){
            if (window.wp && wp.data && wp.data.select('core/editor')) {
                var title = wp.data.select('core/editor').getEditedPostAttribute('title');
                if (title) return String(title).replace(/<[^>]+>/g, '').trim();
            }
            var selectors = ['.editor-post-title__input', '#title', 'h1.wp-block-post-title'];
            for (var i=0;i<selectors.length;i++) {
                var el = document.querySelector(selectors[i]);
                if (el) return (el.value || el.textContent || '').trim();
            }
            return '';
        }
        function setPreviewImage(url){
            var box = document.getElementById('newspress_seo_preview_image');
            if (!box) return;
            box.classList.toggle('is-empty', !url);
            box.innerHTML = url ? '<img src="' + String(url).replace(/"/g, '&quot;') + '" alt="">' : '<span>No image</span>';
        }
        function getClassicFeaturedImage(){
            var img = document.querySelector('#postimagediv img, .editor-post-featured-image__preview img, .components-panel__body.edit-post-post-featured-image img');
            return img ? img.src : '';
        }
        function updateFeaturedImagePreview(){
            if (window.wp && wp.data && wp.data.select('core/editor')) {
                var mediaId = wp.data.select('core/editor').getEditedPostAttribute('featured_media');
                if (!mediaId) { setPreviewImage(''); return; }
                if (mediaCache[mediaId]) { setPreviewImage(mediaCache[mediaId]); return; }
                if (window.wp.apiFetch) {
                    wp.apiFetch({ path: '/wp/v2/media/' + mediaId }).then(function(media){
                        var sizes = media && media.media_details && media.media_details.sizes;
                        var url = (sizes && ((sizes.medium_large && sizes.medium_large.source_url) || (sizes.medium && sizes.medium.source_url))) || media.source_url || '';
                        mediaCache[mediaId] = url;
                        setPreviewImage(url);
                    }).catch(function(){ setPreviewImage(getClassicFeaturedImage()); });
                }
                return;
            }
            setPreviewImage(getClassicFeaturedImage());
        }
        function bindSeoPanel(){
            var desc = document.getElementById('newspress_meta_description');
            var descCount = document.getElementById('newspress_meta_description_count');
            var previewTitle = document.getElementById('newspress_seo_preview_title');
            var previewDesc = document.getElementById('newspress_seo_preview_desc');
            if (!desc || !descCount || descCount.dataset.bound === '1') return !!(desc && descCount);
            descCount.dataset.bound = '1';
            function update(){
                var len = charLength(desc.value);
                var titleValue = getEditorTitle();
                descCount.textContent = len;
                descCount.style.color = len > 160 ? '#b32d2e' : (len >= 140 ? '#008a20' : '#646970');
                if (previewTitle) previewTitle.textContent = titleValue || 'Title preview';
                if (previewDesc) previewDesc.textContent = desc.value.trim() || 'Meta description preview will appear here.';
            }
            ['input','keyup','change','paste','cut','blur'].forEach(function(evt){
                desc.addEventListener(evt, function(){ window.requestAnimationFrame(update); });
            });
            update();
            updateFeaturedImagePreview();
            return true;
        }
        if (!bindSeoPanel()) {
            var tries = 0;
            var timer = window.setInterval(function(){ tries++; if (bindSeoPanel() || tries > 40) window.clearInterval(timer); }, 250);
        }
        if ('MutationObserver' in window) {
            new MutationObserver(function(){ bindSeoPanel(); updateFeaturedImagePreview(); }).observe(document.body, { childList: true, subtree: true });
        }
        if (window.wp && wp.data && wp.data.subscribe) {
            var lastTitle = '';
            var lastMedia = null;
            wp.data.subscribe(function(){
                var title = getEditorTitle();
                var media = wp.data.select('core/editor') ? wp.data.select('core/editor').getEditedPostAttribute('featured_media') : null;
                if (title !== lastTitle) {
                    lastTitle = title;
                    var previewTitle = document.getElementById('newspress_seo_preview_title');
                    if (previewTitle) previewTitle.textContent = title || 'Title preview';
                }
                if (media !== lastMedia) {
                    lastMedia = media;
                    updateFeaturedImagePreview();
                }
            });
        }
    }());
    </script>
    <?php
}
add_action( 'admin_footer', 'newspress_meta_description_admin_script', 100 );
