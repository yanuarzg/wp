<?php
/** Theme setup. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_setup() {
    load_theme_textdomain( 'newspress', get_template_directory() . '/languages' );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'custom-logo', array(
        'height'      => 64,
        'width'       => 220,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_editor_style( 'assets/css/editor.css' );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'newspress' ),
        'footer'  => __( 'Footer Menu', 'newspress' ),
    ) );

    add_image_size( 'newspress-hero', 780, 440, true );
    add_image_size( 'newspress-card', 420, 260, true );
    add_image_size( 'newspress-thumb', 160, 100, true );
    add_image_size( 'newspress-og', 1200, 630, true );
}
add_action( 'after_setup_theme', 'newspress_setup' );

function newspress_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'newspress_content_width', 750 );
}
add_action( 'after_setup_theme', 'newspress_content_width', 0 );
