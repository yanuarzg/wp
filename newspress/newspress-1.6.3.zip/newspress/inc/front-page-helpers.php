<?php
/** Front page helpers and AJAX handlers. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_front_widget_area( $id, $label = '', $class = '' ) {
    $id    = sanitize_key( $id );
    $label = $label ? $label : $id;

    if ( ! is_registered_sidebar( $id ) ) {
        return '';
    }

    $is_active = is_active_sidebar( $id );
    if ( ! $is_active && ! is_customize_preview() ) {
        return '';
    }

    ob_start();
    echo '<div class="np-widget-area np-widget-area-' . esc_attr( $id ) . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" data-widget-area="' . esc_attr( $id ) . '">';
    if ( $is_active ) {
        dynamic_sidebar( $id );
    } elseif ( is_customize_preview() ) {
        echo '<div class="np-customizer-empty-widget-area" aria-hidden="true">' . esc_html( $label ) . '</div>';
        dynamic_sidebar( $id );
    }
    echo '</div>';
    return trim( ob_get_clean() );
}

function newspress_front_echo_widget_area( $id, $label = '', $class = '' ) {
    echo newspress_front_widget_area( $id, $label, $class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}


function newspress_front_render_numbered_between_widget_area( $index ) {
    $slot_index = max( 1, absint( $index ) );
    $slot_id    = 'home-between-' . $slot_index;

    if ( ! is_active_sidebar( $slot_id ) ) {
        return '';
    }

    return newspress_front_widget_area(
        $slot_id,
        sprintf( __( 'Homepage Between Main Rows %d', 'newspress' ), $slot_index ),
        'np-between-widget-area'
    );
}

function newspress_front_take_section( &$sections, $allowed = array() ) {
    foreach ( $sections as $index => $section ) {
        $type = isset( $section['type'] ) ? sanitize_key( $section['type'] ) : '';
        if ( in_array( $type, $allowed, true ) ) {
            unset( $sections[ $index ] );
            $sections = array_values( $sections );
            return $section;
        }
    }
    return array();
}

function newspress_front_ad_block( $class = '' ) {
    $slot_class = trim( 'np-home-ad-slot ' . $class );

    ob_start();
    if ( is_active_sidebar( 'home-ad-slot' ) ) {
        newspress_front_echo_widget_area( 'home-ad-slot', __( 'Homepage Ad Slot', 'newspress' ), 'np-home-ad-slot-widget' );
    } else {
        newspress_ad_slot( 'between' );
    }
    $ad = trim( ob_get_clean() );

    if ( '' === $ad ) {
        return;
    }

    echo '<div class="' . esc_attr( $slot_class ) . '">' . $ad . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_front_render_section( $section = array(), $index = 0 ) {
    $type         = isset( $section['type'] ) ? sanitize_key( $section['type'] ) : '';
    $interlude_no = max( 1, absint( $index ) + 1 );

    ob_start();

    if ( in_array( $type, array( 'category_grid', 'category_list' ), true ) ) {
        set_query_var( 'newspress_section', $section );
        get_template_part( 'template-parts/home', 'category' );
    } elseif ( 'ad' === $type ) {
        newspress_front_ad_block();
    } elseif ( 'widget' === $type ) {
        $widget_area = newspress_front_render_numbered_between_widget_area( $interlude_no );
        if ( '' !== $widget_area ) {
            echo $widget_area; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        } elseif ( is_active_sidebar( 'home-between' ) ) {
            echo '<div class="np-widget-area np-widget-area-home-between">';
            dynamic_sidebar( 'home-between' );
            echo '</div>';
        }
    }

    $content = trim( ob_get_clean() );
    $extra_widget_area = newspress_front_render_numbered_between_widget_area( $interlude_no );
    if ( 'widget' !== $type && '' !== $extra_widget_area ) {
        $content .= ( '' !== $content ? PHP_EOL : '' ) . $extra_widget_area;
    }

    if ( '' !== trim( $content ) ) {
        echo '<section class="np-home-interlude np-container np-home-interlude-' . esc_attr( $interlude_no ) . '" data-interlude="' . esc_attr( $interlude_no ) . '">' . $content . '</section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}

function newspress_front_latest_section( $offset = 0, $group = 1, $posts_per_row = 5 ) {
    $latest_posts = new WP_Query( array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => min( 10, max( 1, absint( $posts_per_row ) ) ),
        'offset'              => max( 0, absint( $offset ) ),
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
    ) );
    if ( ! $latest_posts->have_posts() ) {
        return;
    }
    $previous_context = get_query_var( 'newspress_card_context' );
    set_query_var( 'newspress_card_context', 'latest' );
    ?>
    <section class="np-section np-latest-all np-latest-group np-latest-group-<?php echo esc_attr( absint( $group ) ); ?>">
        <div class="np-latest-list <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'latest' ) : '' ); ?>">
            <?php while ( $latest_posts->have_posts() ) : $latest_posts->the_post(); ?>
                <?php get_template_part( 'template-parts/content', 'card' ); ?>
            <?php endwhile; ?>
        </div>
    </section>
    <?php
    set_query_var( 'newspress_card_context', $previous_context );
    wp_reset_postdata();
}

function newspress_front_get_load_more_posts( $offset = 0, $count = 5 ) {
    $offset = max( 0, absint( $offset ) );
    $count  = min( 20, max( 1, absint( $count ) ) );

    $q = new WP_Query( array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => $count,
        'offset'              => $offset,
        'ignore_sticky_posts' => true,
        'no_found_rows'       => false,
    ) );

    ob_start();
    $previous_context = get_query_var( 'newspress_card_context' );
    set_query_var( 'newspress_card_context', 'latest' );
    if ( $q->have_posts() ) {
        while ( $q->have_posts() ) {
            $q->the_post();
            get_template_part( 'template-parts/content', 'card' );
        }
    }
    set_query_var( 'newspress_card_context', $previous_context );
    wp_reset_postdata();

    $html     = trim( ob_get_clean() );
    $next     = $offset + $count;
    $has_more = $q->found_posts > $next;

    return array(
        'html'       => $html,
        'nextOffset' => $next,
        'hasMore'    => $has_more,
    );
}

function newspress_front_load_more_rest( WP_REST_Request $request ) {
    $data = newspress_front_get_load_more_posts( $request->get_param( 'offset' ), $request->get_param( 'count' ) );
    return new WP_REST_Response( $data, 200 );
}

function newspress_front_load_more_ajax() {
    check_ajax_referer( 'newspress_load_more', 'nonce' );
    $data = newspress_front_get_load_more_posts(
        isset( $_POST['offset'] ) ? absint( wp_unslash( $_POST['offset'] ) ) : 0,
        isset( $_POST['count'] ) ? absint( wp_unslash( $_POST['count'] ) ) : 5
    );
    wp_send_json_success( $data );
}
add_action( 'wp_ajax_newspress_load_more', 'newspress_front_load_more_ajax' );
add_action( 'wp_ajax_nopriv_newspress_load_more', 'newspress_front_load_more_ajax' );

function newspress_register_front_load_more_route() {
    register_rest_route( 'newspress/v1', '/load-more', array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'newspress_front_load_more_rest',
        'permission_callback' => '__return_true',
        'args'                => array(
            'offset' => array( 'sanitize_callback' => 'absint' ),
            'count'  => array( 'sanitize_callback' => 'absint' ),
        ),
    ) );
}
add_action( 'rest_api_init', 'newspress_register_front_load_more_route' );
