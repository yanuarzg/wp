<?php
/** Lightweight homepage builder. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_default_home_sections() {
    return array(
        array( 'type' => 'hero', 'category' => 0, 'title' => __( 'Headline', 'newspress' ) ),
        array( 'type' => 'category_grid', 'category' => 0, 'title' => __( 'Nasional', 'newspress' ) ),
        array( 'type' => 'ad', 'category' => 0, 'title' => __( 'Advertisement', 'newspress' ) ),
        array( 'type' => 'category_list', 'category' => 0, 'title' => __( 'Ekonomi', 'newspress' ) ),
        array( 'type' => 'widget', 'category' => 0, 'title' => __( 'Homepage Widget', 'newspress' ) ),
        array( 'type' => 'category_grid', 'category' => 0, 'title' => __( 'Internasional', 'newspress' ) ),
    );
}

function newspress_default_home_settings() {
    return array(
        'main_rows'          => 5,
        'posts_per_row'      => 5,
        'show_home_top'      => 1,
        'load_more_min'      => 10,
        'latest_nav_mode'    => 'load_more',
        'row_ad_enabled'     => 1,
    );
}

function newspress_get_home_settings() {
    $saved    = get_option( 'newspress_home_settings', array() );
    $settings = wp_parse_args( is_array( $saved ) ? $saved : array(), newspress_default_home_settings() );

    $settings['main_rows']          = min( 8, max( 1, absint( $settings['main_rows'] ) ) );
    $settings['posts_per_row']      = min( 10, max( 1, absint( $settings['posts_per_row'] ) ) );
    $settings['load_more_min']      = min( 50, max( 1, absint( $settings['load_more_min'] ) ) );
    $settings['latest_nav_mode']    = in_array( $settings['latest_nav_mode'], array( 'load_more', 'pagination' ), true ) ? $settings['latest_nav_mode'] : 'load_more';
    $settings['show_home_top']      = ! empty( $settings['show_home_top'] ) ? 1 : 0;
    $settings['row_ad_enabled']   = ! empty( $settings['row_ad_enabled'] ) ? 1 : 0;

    return $settings;
}

function newspress_get_home_sections() {
    $sections = get_option( 'newspress_home_sections', array() );
    return ! empty( $sections ) && is_array( $sections ) ? $sections : newspress_default_home_sections();
}

function newspress_homepage_menu() {
    add_theme_page( __( 'Homepage Builder', 'newspress' ), __( 'Homepage Builder', 'newspress' ), 'edit_theme_options', 'newspress-homepage', 'newspress_homepage_page' );
}
add_action( 'admin_menu', 'newspress_homepage_menu' );

function newspress_homepage_page() {
    if ( ! current_user_can( 'edit_theme_options' ) ) { return; }

    if ( isset( $_POST['newspress_home_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['newspress_home_nonce'] ) ), 'newspress_save_home' ) ) {

        $nav_choices      = array( 'load_more', 'pagination' );
        $settings = array(
            'main_rows'          => isset( $_POST['newspress_home_main_rows'] ) ? min( 8, max( 1, absint( $_POST['newspress_home_main_rows'] ) ) ) : 5,
            'posts_per_row'      => isset( $_POST['newspress_home_posts_per_row'] ) ? min( 10, max( 1, absint( $_POST['newspress_home_posts_per_row'] ) ) ) : 5,
            'show_home_top'      => isset( $_POST['newspress_home_show_home_top'] ) ? 1 : 0,
            'load_more_min'      => isset( $_POST['newspress_home_load_more_min'] ) ? min( 50, max( 1, absint( $_POST['newspress_home_load_more_min'] ) ) ) : 10,
            'latest_nav_mode'    => isset( $_POST['newspress_home_latest_nav_mode'] ) && in_array( sanitize_key( $_POST['newspress_home_latest_nav_mode'] ), $nav_choices, true ) ? sanitize_key( $_POST['newspress_home_latest_nav_mode'] ) : 'load_more',
            'row_ad_enabled'     => isset( $_POST['newspress_home_row_ad_enabled'] ) ? 1 : 0,
        );
        update_option( 'newspress_home_settings', $settings );

        echo '<div class="updated notice"><p>' . esc_html__( 'Homepage settings saved.', 'newspress' ) . '</p></div>';
    }

    $settings = newspress_get_home_settings();
    ?>
    <div class="wrap np-admin-builder">
        <h1><?php esc_html_e( 'NewsPress Homepage Builder', 'newspress' ); ?></h1>
        <p><?php esc_html_e( 'Control homepage rows, latest post batches, navigation style, and optional widget areas.', 'newspress' ); ?></p>
        <form method="post">
            <?php wp_nonce_field( 'newspress_save_home', 'newspress_home_nonce' ); ?>

            <h2><?php esc_html_e( 'Homepage Layout', 'newspress' ); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="newspress_home_main_rows"><?php esc_html_e( 'Number of main rows', 'newspress' ); ?></label></th>
                    <td><input id="newspress_home_main_rows" name="newspress_home_main_rows" type="number" min="1" max="8" value="<?php echo esc_attr( $settings['main_rows'] ); ?>"> <p class="description"><?php esc_html_e( 'Main row 1 is reserved for Hero. Rows 2+ contain continuous latest posts.', 'newspress' ); ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="newspress_home_posts_per_row"><?php esc_html_e( 'Posts per latest row', 'newspress' ); ?></label></th>
                    <td><input id="newspress_home_posts_per_row" name="newspress_home_posts_per_row" type="number" min="1" max="10" value="<?php echo esc_attr( $settings['posts_per_row'] ); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="newspress_home_load_more_min"><?php esc_html_e( 'Minimum posts before Load More is active', 'newspress' ); ?></label></th>
                    <td><input id="newspress_home_load_more_min" name="newspress_home_load_more_min" type="number" min="1" max="50" value="<?php echo esc_attr( $settings['load_more_min'] ); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="newspress_home_latest_nav_mode"><?php esc_html_e( 'Latest navigation style', 'newspress' ); ?></label></th>
                    <td><select id="newspress_home_latest_nav_mode" name="newspress_home_latest_nav_mode">
                        <option value="load_more" <?php selected( $settings['latest_nav_mode'], 'load_more' ); ?>><?php esc_html_e( 'Load More button', 'newspress' ); ?></option>
                        <option value="pagination" <?php selected( $settings['latest_nav_mode'], 'pagination' ); ?>><?php esc_html_e( 'Pagination', 'newspress' ); ?></option>
                    </select></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Homepage top widget area', 'newspress' ); ?></th>
                    <td><label><input name="newspress_home_show_home_top" type="checkbox" value="1" <?php checked( $settings['show_home_top'], 1 ); ?>> <?php esc_html_e( 'Show Homepage Top widget area above Hero', 'newspress' ); ?></label></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Latest row ad widget', 'newspress' ); ?></th>
                    <td><label><input name="newspress_home_row_ad_enabled" type="checkbox" value="1" <?php checked( $settings['row_ad_enabled'], 1 ); ?>> <?php esc_html_e( 'Show ad slot before latest posts in each latest row content column', 'newspress' ); ?></label></td>
                </tr>
            </table>
            <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Homepage Settings', 'newspress' ); ?></button></p>
        </form>
    </div>
    <?php
}
