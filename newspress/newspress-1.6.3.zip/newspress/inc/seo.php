<?php
/** Lightweight SEO helpers. Designed to stay out of the way when major SEO plugins are active. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_has_seo_plugin() {
    return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

function newspress_get_meta_description() {
    if ( is_singular() ) {
        $post = get_queried_object();
        if ( ! $post ) { return ''; }

        $custom_desc = get_post_meta( $post->ID, defined( 'NEWSPRESS_META_DESCRIPTION_KEY' ) ? NEWSPRESS_META_DESCRIPTION_KEY : '_newspress_meta_description', true );
        if ( is_string( $custom_desc ) && '' !== trim( $custom_desc ) ) {
            return function_exists( 'newspress_sanitize_meta_description' ) ? newspress_sanitize_meta_description( $custom_desc ) : wp_trim_words( wp_strip_all_tags( $custom_desc ), 32, '' );
        }

        $desc = has_excerpt( $post ) ? $post->post_excerpt : $post->post_content;
        return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $desc ) ), 28, '' );
    }
    if ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && ! is_wp_error( $term ) && ! empty( $term->description ) ) {
            return wp_trim_words( wp_strip_all_tags( $term->description ), 28, '' );
        }
    }
    if ( is_front_page() || is_home() ) {
        return get_bloginfo( 'description' );
    }
    if ( is_search() ) {
        return sprintf( __( 'Search results for %s', 'newspress' ), get_search_query() );
    }
    return '';
}

function newspress_get_og_image() {
    if ( is_singular() && has_post_thumbnail() ) {
        return wp_get_attachment_image_url( get_post_thumbnail_id(), 'newspress-og' );
    }
    $logo_id = get_theme_mod( 'custom_logo' );
    if ( $logo_id ) {
        return wp_get_attachment_image_url( $logo_id, 'full' );
    }
    return '';
}

function newspress_basic_seo_meta() {
    if ( newspress_has_seo_plugin() || ! get_theme_mod( 'newspress_enable_basic_seo', 1 ) ) {
        return;
    }

    $description = newspress_get_meta_description();
    if ( $description ) {
        echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
    }

    if ( is_singular() ) {
        $tags = wp_get_post_tags( get_the_ID(), array( 'fields' => 'names' ) );
        if ( ! empty( $tags ) ) {
            echo '<meta name="keywords" content="' . esc_attr( implode( ', ', array_slice( $tags, 0, 12 ) ) ) . '">' . "\n";
        }
    }
}
add_action( 'wp_head', 'newspress_basic_seo_meta', 2 );

function newspress_open_graph_meta() {
    if ( newspress_has_seo_plugin() || ! get_theme_mod( 'newspress_enable_og_meta', 1 ) ) {
        return;
    }

    $post_id     = is_singular( 'post' ) ? get_queried_object_id() : 0;
    $title       = wp_get_document_title();
    $description = newspress_get_meta_description();
    $url         = is_singular() ? get_permalink() : home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
    $type        = is_singular( 'post' ) ? 'article' : 'website';
    $image       = newspress_get_og_image();

    echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
    if ( $description ) {
        echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
    }
    echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
    if ( $image ) {
        echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    } else {
        echo '<meta name="twitter:card" content="summary">' . "\n";
    }
    $twitter_title = $title;
    $twitter_desc  = $description;
    echo '<meta name="twitter:title" content="' . esc_attr( $twitter_title ) . '">' . "\n";
    if ( $twitter_desc ) {
        echo '<meta name="twitter:description" content="' . esc_attr( $twitter_desc ) . '">' . "\n";
    }
}
add_action( 'wp_head', 'newspress_open_graph_meta', 3 );

function newspress_get_canonical_url() {
    $paged = max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );

    if ( is_singular() ) {
        return get_permalink();
    }

    if ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && ! is_wp_error( $term ) ) {
            $url = get_term_link( $term );
            if ( is_wp_error( $url ) ) {
                return '';
            }
            return $paged > 1 ? get_pagenum_link( $paged ) : $url;
        }
    }

    if ( is_search() ) {
        return $paged > 1 ? get_pagenum_link( $paged ) : get_search_link();
    }

    if ( is_home() || is_front_page() ) {
        return $paged > 1 ? get_pagenum_link( $paged ) : home_url( '/' );
    }

    if ( is_archive() ) {
        return $paged > 1 ? get_pagenum_link( $paged ) : get_pagenum_link( 1 );
    }

    return '';
}

function newspress_canonical_meta() {
    if ( newspress_has_seo_plugin() || ! get_theme_mod( 'newspress_enable_basic_seo', 1 ) ) {
        return;
    }
    $canonical = newspress_get_canonical_url();
    if ( $canonical ) {
        echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
    }
}
add_action( 'wp_head', 'newspress_canonical_meta', 1 );

function newspress_meta_robots() {
    if ( newspress_has_seo_plugin() || ! get_theme_mod( 'newspress_enable_basic_seo', 1 ) ) {
        return;
    }
    if ( is_search() || is_404() ) {
        echo '<meta name="robots" content="noindex,follow">' . "\n";
    }
}
add_action( 'wp_head', 'newspress_meta_robots', 1 );

function newspress_single_featured_image_preload() {
    if ( ! is_singular( 'post' ) || ! has_post_thumbnail() || ! get_theme_mod( 'newspress_preload_featured_image', 1 ) ) {
        return;
    }
    $image_id = get_post_thumbnail_id();
    $src = wp_get_attachment_image_url( $image_id, 'large' );
    if ( ! $src ) {
        return;
    }
    $srcset = wp_get_attachment_image_srcset( $image_id, 'large' );
    $sizes  = wp_get_attachment_image_sizes( $image_id, 'large' );
    echo '<link rel="preload" as="image" href="' . esc_url( $src ) . '"';
    if ( $srcset ) {
        echo ' imagesrcset="' . esc_attr( $srcset ) . '"';
    }
    if ( $sizes ) {
        echo ' imagesizes="' . esc_attr( $sizes ) . '"';
    }
    echo '>' . "\n";
}
add_action( 'wp_head', 'newspress_single_featured_image_preload', 4 );

function newspress_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type && get_theme_mod( 'newspress_preconnect_google_fonts', 0 ) ) {
        $urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'newspress_resource_hints', 10, 2 );
