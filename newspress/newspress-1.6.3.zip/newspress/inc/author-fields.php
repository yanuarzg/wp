<?php
/** Author profile extensions. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_author_contact_methods( $methods ) {
    $methods['instagram'] = __( 'Instagram URL', 'newspress' );
    $methods['twitter']   = __( 'X/Twitter URL', 'newspress' );
    $methods['facebook']  = __( 'Facebook URL', 'newspress' );
    $methods['linkedin']  = __( 'LinkedIn URL', 'newspress' );
    return $methods;
}
add_filter( 'user_contactmethods', 'newspress_author_contact_methods' );

function newspress_author_extra_fields( $user ) {
    if ( ! current_user_can( 'edit_user', $user->ID ) ) { return; }
    ?>
    <h2><?php esc_html_e( 'NewsPress Author Box', 'newspress' ); ?></h2>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="newspress_author_role"><?php esc_html_e( 'Author role/title', 'newspress' ); ?></label></th>
            <td><input type="text" class="regular-text" id="newspress_author_role" name="newspress_author_role" value="<?php echo esc_attr( get_user_meta( $user->ID, 'newspress_author_role', true ) ); ?>" placeholder="<?php esc_attr_e( 'Editor, Reporter, Contributor', 'newspress' ); ?>"></td>
        </tr>
        <tr>
            <th><label for="newspress_author_verified"><?php esc_html_e( 'Verified badge', 'newspress' ); ?></label></th>
            <td><label><input type="checkbox" id="newspress_author_verified" name="newspress_author_verified" value="1" <?php checked( get_user_meta( $user->ID, 'newspress_author_verified', true ) ); ?>> <?php esc_html_e( 'Show verified author badge', 'newspress' ); ?></label></td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'newspress_author_extra_fields' );
add_action( 'edit_user_profile', 'newspress_author_extra_fields' );

function newspress_save_author_extra_fields( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) { return false; }
    update_user_meta( $user_id, 'newspress_author_role', sanitize_text_field( wp_unslash( $_POST['newspress_author_role'] ?? '' ) ) );
    update_user_meta( $user_id, 'newspress_author_verified', ! empty( $_POST['newspress_author_verified'] ) ? 1 : 0 );
}
add_action( 'personal_options_update', 'newspress_save_author_extra_fields' );
add_action( 'edit_user_profile_update', 'newspress_save_author_extra_fields' );
