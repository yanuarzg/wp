<?php
/** Customizer options. */
if ( ! defined( 'ABSPATH' ) ) { exit; }


function newspress_sanitize_layout( $value ) {
    $allowed = array( 'right-sidebar', 'left-sidebar', 'no-sidebar' );
    return in_array( $value, $allowed, true ) ? $value : 'right-sidebar';
}


function newspress_sanitize_range_1_240( $value ) {
    return min( 240, max( 1, absint( $value ) ) );
}

function newspress_sanitize_dark_default( $value ) {
    return in_array( $value, array( 'system', 'light', 'dark' ), true ) ? $value : 'system';
}


function newspress_sanitize_sidebar_choice( $value ) {
    return in_array( $value, array( 'popular', 'recent', 'main', 'recent_plus_main', 'custom', 'none' ), true ) ? $value : 'none';
}

function newspress_sanitize_boolean( $value ) {
    return ! empty( $value ) ? 1 : 0;
}

function newspress_sanitize_date_format( $value ) {
    $value = trim( sanitize_text_field( $value ) );
    if ( '' === $value ) {
        return 'l, d F Y | H:i \\W\\I\\B';
    }

    return substr( $value, 0, 80 );
}

function newspress_sanitize_date_display_mode( $value ) {
    return in_array( $value, array( 'format', 'ago' ), true ) ? $value : 'format';
}




if ( ! class_exists( 'Newspress_Customize_Separator_Control' ) && class_exists( 'WP_Customize_Control' ) ) {
    /** Visual separator/heading for grouped Customizer controls. */
    class Newspress_Customize_Separator_Control extends WP_Customize_Control {
        public $type = 'newspress_separator';

        public function render_content() {
            if ( empty( $this->label ) ) {
                return;
            }
            ?>
            <span class="customize-control-title newspress-customize-separator" style="display:block;margin-top:14px;padding-top:14px;border-top:1px solid #dcdcde;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#50575e;">
                <?php echo esc_html( $this->label ); ?>
            </span>
            <?php
        }
    }
}

function newspress_add_customizer_separator( $wp_customize, $section, $id, $label, $priority ) {
    if ( ! class_exists( 'Newspress_Customize_Separator_Control' ) ) {
        return;
    }

    $setting_id = 'newspress_separator_' . sanitize_key( $id );
    $wp_customize->add_setting( $setting_id, array(
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( new Newspress_Customize_Separator_Control( $wp_customize, $setting_id, array(
        'label'    => $label,
        'section'  => $section,
        'priority' => absint( $priority ),
    ) ) );
}

function newspress_sanitize_trending_source( $value ) {
    return in_array( $value, array( 'post_tag', 'category' ), true ) ? $value : 'post_tag';
}

function newspress_sanitize_trending_range( $value ) {
    return in_array( $value, array( 'all', 'today', '7days', '30days' ), true ) ? $value : '7days';
}

function newspress_sanitize_trending_count( $value ) {
    return min( 20, max( 1, absint( $value ) ) );
}

function newspress_sanitize_breaking_source( $value ) {
    return in_array( $value, array( 'recent', 'category', 'tag' ), true ) ? $value : 'tag';
}

function newspress_sanitize_breaking_count( $value ) {
    return min( 20, max( 1, absint( $value ) ) );
}

function newspress_sanitize_footer_bottom_html( $value ) {
    return wp_kses( $value, array(
        'a'      => array(
            'href'   => true,
            'title'  => true,
            'target' => true,
            'rel'    => true,
        ),
        'span'   => array( 'class' => true ),
        'strong' => array(),
        'em'     => array(),
        'br'     => array(),
    ) );
}

function newspress_sanitize_latest_nav_mode( $value ) {
    return in_array( $value, array( 'load_more', 'pagination' ), true ) ? $value : 'load_more';
}

function newspress_sanitize_list_grid( $value ) {
    return in_array( $value, array( 'list', 'grid' ), true ) ? $value : 'list';
}

function newspress_sanitize_related_count( $value ) {
    return min( 12, max( 1, absint( $value ) ) );
}

function newspress_sanitize_ad_code( $value ) {
    if ( current_user_can( 'unfiltered_html' ) ) {
        return $value;
    }

    $allowed = wp_kses_allowed_html( 'post' );
    $allowed['script'] = array(
        'async' => true,
        'src'   => true,
        'crossorigin' => true,
    );
    $allowed['ins'] = array(
        'class' => true,
        'style' => true,
        'data-ad-client' => true,
        'data-ad-slot' => true,
        'data-ad-format' => true,
        'data-full-width-responsive' => true,
    );

    return wp_kses( $value, $allowed );
}


function newspress_hex_to_rgb_triplet( $hex ) {
    $hex = sanitize_hex_color( $hex );
    if ( ! $hex ) {
        return '0,87,156';
    }
    $hex = ltrim( $hex, '#' );
    if ( 3 === strlen( $hex ) ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    return hexdec( substr( $hex, 0, 2 ) ) . ',' . hexdec( substr( $hex, 2, 2 ) ) . ',' . hexdec( substr( $hex, 4, 2 ) );
}

function newspress_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'newspress_design', array(
        'title'    => __( 'NewsPress Design', 'newspress' ),
        'priority' => 30,
    ) );

    newspress_add_customizer_separator( $wp_customize, 'newspress_design', 'design_brand_colors', __( 'Brand colors', 'newspress' ), 5 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_design', 'design_dark_mode_colors', __( 'Dark mode colors', 'newspress' ), 20 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_design', 'design_layout', __( 'Layout', 'newspress' ), 35 );

    $settings = array(
        'primary_color'      => array( '#00579c', __( 'Primary Color', 'newspress' ) ),
        'accent_color'       => array( '#e21b2d', __( 'Accent Color', 'newspress' ) ),
        'text_color'         => array( '#171717', __( 'Text Color', 'newspress' ) ),
        'dark_bg_color'      => array( '#06080d', __( 'Dark Mode: Background Color', 'newspress' ) ),
        'dark_primary_color' => array( '#75bfff', __( 'Dark Mode: Primary Color', 'newspress' ) ),
        'dark_accent_color'  => array( '#ff9b3d', __( 'Dark Mode: Accent Color', 'newspress' ) ),
        'dark_text_color'    => array( '#e6edf7', __( 'Dark Mode: Text Color', 'newspress' ) ),
    );

    foreach ( $settings as $id => $data ) {
        $wp_customize->add_setting( 'newspress_' . $id, array(
            'default'           => $data[0],
            'sanitize_callback' => 'sanitize_hex_color',
            'transport'         => 'refresh',
        ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'newspress_' . $id, array(
            'label'   => $data[1],
            'section' => 'newspress_design',
        ) ) );
    }

    $wp_customize->add_setting( 'newspress_layout', array(
        'default'           => 'right-sidebar',
        'sanitize_callback' => 'newspress_sanitize_layout',
    ) );
    $wp_customize->add_control( 'newspress_layout', array(
        'type'    => 'select',
        'section' => 'newspress_design',
        'label'   => __( 'Default Layout', 'newspress' ),
        'choices' => array(
            'right-sidebar' => __( 'Right Sidebar', 'newspress' ),
            'left-sidebar'  => __( 'Left Sidebar', 'newspress' ),
            'no-sidebar'    => __( 'No Sidebar', 'newspress' ),
        ),
    ) );

    $wp_customize->add_section( 'newspress_ads', array(
        'title'    => __( 'NewsPress Ad Slots', 'newspress' ),
        'priority' => 31,
    ) );

    $ads = array(
        'leaderboard' => __( 'Leaderboard after header', 'newspress' ),
        'between'     => __( 'Between homepage blocks', 'newspress' ),
        'sidebar'             => __( 'Sidebar 300x250', 'newspress' ),
        'article_before'      => __( 'Article ad before first paragraph', 'newspress' ),
        'article_middle'      => __( 'Article ad in the middle of article', 'newspress' ),
        'article_after'       => __( 'Article ad after last paragraph', 'newspress' ),
        'inarticle'           => __( 'Legacy in-article ad fallback', 'newspress' ),
    );
    foreach ( $ads as $id => $label ) {
        $wp_customize->add_setting( 'newspress_ad_' . $id, array(
            'default'           => '',
            'sanitize_callback' => 'newspress_sanitize_ad_code',
        ) );
        $wp_customize->add_control( 'newspress_ad_' . $id, array(
            'type'    => 'textarea',
            'section' => 'newspress_ads',
            'label'   => $label,
        ) );
    }



    $wp_customize->add_setting( 'newspress_ad_hide_logged_in', array(
        'default'           => 0,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_ad_hide_logged_in', array(
        'type'    => 'checkbox',
        'section' => 'newspress_ads',
        'label'   => __( 'Hide ads for logged-in users', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_ad_label', array(
        'default'           => __( 'Advertisement', 'newspress' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'newspress_ad_label', array(
        'type'    => 'text',
        'section' => 'newspress_ads',
        'label'   => __( 'Ad label text', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_ad_middle_paragraph', array(
        'default'           => 4,
        'sanitize_callback' => 'absint',
    ) );
    $wp_customize->add_control( 'newspress_ad_middle_paragraph', array(
        'type'        => 'number',
        'section'     => 'newspress_ads',
        'label'       => __( 'Middle article ad after paragraph', 'newspress' ),
        'input_attrs' => array( 'min' => 2, 'max' => 12 ),
    ) );

    $wp_customize->add_setting( 'newspress_enable_mobile_sticky_ad', array(
        'default'           => 0,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_enable_mobile_sticky_ad', array(
        'type'    => 'checkbox',
        'section' => 'newspress_ads',
        'label'   => __( 'Enable sticky bottom ad on mobile', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_ad_mobile_sticky', array(
        'default'           => '',
        'sanitize_callback' => 'newspress_sanitize_ad_code',
    ) );
    $wp_customize->add_control( 'newspress_ad_mobile_sticky', array(
        'type'    => 'textarea',
        'section' => 'newspress_ads',
        'label'   => __( 'Mobile sticky ad code', 'newspress' ),
    ) );

    $wp_customize->add_section( 'newspress_options', array(
        'title'    => __( 'NewsPress Options', 'newspress' ),
        'priority' => 32,
    ) );

    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_header', __( 'Header & ticker', 'newspress' ), 10 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_trending', __( 'Trending & tags', 'newspress' ), 20 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_breaking', __( 'Breaking news', 'newspress' ), 30 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_single_meta', __( 'Single post meta', 'newspress' ), 40 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_share', __( 'Article share buttons', 'newspress' ), 50 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_footer', __( 'Footer', 'newspress' ), 65 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_display', __( 'Display & behavior', 'newspress' ), 70 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_home_latest', __( 'Home latest posts', 'newspress' ), 80 );
    newspress_add_customizer_separator( $wp_customize, 'newspress_options', 'options_related', __( 'Related posts', 'newspress' ), 90 );

    $wp_customize->add_setting( 'newspress_show_clock', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ) );
    $wp_customize->add_control( 'newspress_show_clock', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Show realtime date and clock', 'newspress' ),
    ) );
    $wp_customize->add_setting( 'newspress_breaking_speed', array(
        'default'           => 120,
        'sanitize_callback' => 'newspress_sanitize_range_1_240',
    ) );
    $wp_customize->add_control( 'newspress_breaking_speed', array(
        'type'        => 'number',
        'section'     => 'newspress_options',
        'label'       => __( 'Breaking ticker speed (seconds)', 'newspress' ),
        'input_attrs' => array( 'min' => 1, 'max' => 240 ),
    ) );

    $wp_customize->add_setting( 'newspress_trending_source', array(
        'default'           => 'post_tag',
        'sanitize_callback' => 'newspress_sanitize_trending_source',
    ) );
    $wp_customize->add_control( 'newspress_trending_source', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Trending source', 'newspress' ),
        'choices' => array(
            'post_tag' => __( 'Tags', 'newspress' ),
            'category' => __( 'Categories', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_trending_range', array(
        'default'           => '7days',
        'sanitize_callback' => 'newspress_sanitize_trending_range',
    ) );
    $wp_customize->add_control( 'newspress_trending_range', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Trending time range', 'newspress' ),
        'choices' => array(
            'all'    => __( 'All time', 'newspress' ),
            'today'  => __( 'Today', 'newspress' ),
            '7days'  => __( 'Last 7 days', 'newspress' ),
            '30days' => __( 'Last 30 days', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_trending_count', array(
        'default'           => 7,
        'sanitize_callback' => 'newspress_sanitize_trending_count',
    ) );
    $wp_customize->add_control( 'newspress_trending_count', array(
        'type'        => 'number',
        'section'     => 'newspress_options',
        'label'       => __( 'Maximum trending items', 'newspress' ),
        'input_attrs' => array( 'min' => 1, 'max' => 20 ),
    ) );

    $wp_customize->add_setting( 'newspress_trending_show_hash', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_trending_show_hash', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Show # before trending items', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_tags_show_hash', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_tags_show_hash', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Show # before post tags', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_single_date_format', array(
        'default'           => 'l, d F Y | H:i \\W\\I\\B',
        'sanitize_callback' => 'newspress_sanitize_date_format',
    ) );
    $wp_customize->add_control( 'newspress_single_date_format', array(
        'type'        => 'text',
        'section'     => 'newspress_options',
        'label'       => __( 'Article date/time format', 'newspress' ),
        'description' => __( 'Applies to post dates across theme templates. Use PHP date format. Example: d/m/Y H:i or l, d F Y | H:i \\W\\I\\B.', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_date_display_mode', array(
        'default'           => 'format',
        'sanitize_callback' => 'newspress_sanitize_date_display_mode',
    ) );
    $wp_customize->add_control( 'newspress_date_display_mode', array(
        'type'        => 'select',
        'section'     => 'newspress_options',
        'label'       => __( 'Article date display style', 'newspress' ),
        'description' => __( 'Choose formatted date/time or relative time such as 2 days ago.', 'newspress' ),
        'choices'     => array(
            'format' => __( 'Date/time format', 'newspress' ),
            'ago'    => __( 'Days ago / relative time', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_show_single_published_date', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_show_single_published_date', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Show published date on single post meta', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_show_single_updated_date', array(
        'default'           => 0,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_show_single_updated_date', array(
        'type'        => 'checkbox',
        'section'     => 'newspress_options',
        'label'       => __( 'Show updated date on single post meta', 'newspress' ),
        'description' => __( 'Displayed only when the post modified time is newer than the published time.', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_show_single_views', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_show_single_views', array(
        'type'        => 'checkbox',
        'section'     => 'newspress_options',
        'label'       => __( 'Show views count on single post meta', 'newspress' ),
        'description' => __( 'Displays the total article view count beside author, date, and reading time.', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_single_views_label', array(
        'default'           => __( 'Dilihat', 'newspress' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'newspress_single_views_label', array(
        'type'        => 'text',
        'section'     => 'newspress_options',
        'label'       => __( 'Views label text', 'newspress' ),
        'description' => __( 'Example: Dilihat, Views, Dibaca.', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_breaking_label', array(
        'default'           => __( 'Breaking', 'newspress' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'newspress_breaking_label', array(
        'type'    => 'text',
        'section' => 'newspress_options',
        'label'   => __( 'Breaking label text', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_breaking_source', array(
        'default'           => 'tag',
        'sanitize_callback' => 'newspress_sanitize_breaking_source',
    ) );
    $wp_customize->add_control( 'newspress_breaking_source', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Breaking source', 'newspress' ),
        'choices' => array(
            'tag'      => __( 'Tag: breaking-news', 'newspress' ),
            'category' => __( 'Selected category', 'newspress' ),
            'recent'   => __( 'Recent posts', 'newspress' ),
        ),
    ) );

    $breaking_categories = array( 0 => __( 'Select category', 'newspress' ) );
    foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) {
        $breaking_categories[ $category->term_id ] = $category->name;
    }

    $wp_customize->add_setting( 'newspress_breaking_category', array(
        'default'           => 0,
        'sanitize_callback' => 'absint',
    ) );
    $wp_customize->add_control( 'newspress_breaking_category', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Breaking category', 'newspress' ),
        'choices' => $breaking_categories,
    ) );

    $wp_customize->add_setting( 'newspress_breaking_count', array(
        'default'           => 8,
        'sanitize_callback' => 'newspress_sanitize_breaking_count',
    ) );
    $wp_customize->add_control( 'newspress_breaking_count', array(
        'type'        => 'number',
        'section'     => 'newspress_options',
        'label'       => __( 'Maximum breaking items', 'newspress' ),
        'input_attrs' => array( 'min' => 1, 'max' => 20 ),
    ) );

    $wp_customize->add_setting( 'newspress_footer_bottom_custom', array(
        'default'           => '',
        'sanitize_callback' => 'newspress_sanitize_footer_bottom_html',
    ) );
    $wp_customize->add_control( 'newspress_footer_bottom_custom', array(
        'type'        => 'textarea',
        'section'     => 'newspress_options',
        'label'       => __( 'Footer bottom custom text / links', 'newspress' ),
        'description' => __( 'Displayed after copyright. Example: | by <a href="https://yztheme.my.id">YzTheme</a>', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_enable_dark_toggle', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_enable_dark_toggle', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Show dark/light mode toggle', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_default_color_scheme', array(
        'default'           => 'system',
        'sanitize_callback' => 'newspress_sanitize_dark_default',
    ) );
    $wp_customize->add_control( 'newspress_default_color_scheme', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Default color scheme', 'newspress' ),
        'choices' => array(
            'system' => __( 'Follow device setting', 'newspress' ),
            'light'  => __( 'Light', 'newspress' ),
            'dark'   => __( 'Dark', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_sticky_sidebar', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_sticky_sidebar', array(
        'type'    => 'checkbox',
        'section' => 'newspress_options',
        'label'   => __( 'Enable sticky sidebar on desktop', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_show_share_count', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_show_share_count', array(
        'type'        => 'checkbox',
        'section'     => 'newspress_options',
        'label'       => __( 'Show share click count', 'newspress' ),
        'description' => __( 'Displays the total number of article share button clicks above the share buttons.', 'newspress' ),
    ) );

    $share_buttons = array(
        'native'    => __( 'Share button: native share', 'newspress' ),
        'copy'      => __( 'Share button: copy link', 'newspress' ),
        'bluesky'   => __( 'Share button: Bluesky', 'newspress' ),
        'facebook'  => __( 'Share button: Facebook', 'newspress' ),
        'instagram' => __( 'Share button: Instagram', 'newspress' ),
        'line'      => __( 'Share button: Line', 'newspress' ),
        'linkedin'  => __( 'Share button: LinkedIn', 'newspress' ),
        'pinterest' => __( 'Share button: Pinterest', 'newspress' ),
        'telegram'  => __( 'Share button: Telegram', 'newspress' ),
        'tiktok'    => __( 'Share button: TikTok', 'newspress' ),
        'threads'   => __( 'Share button: Threads', 'newspress' ),
        'whatsapp'  => __( 'Share button: WhatsApp', 'newspress' ),
        'x'         => __( 'Share button: X / Twitter', 'newspress' ),
    );

    foreach ( $share_buttons as $share_key => $share_label ) {
        $wp_customize->add_setting( 'newspress_share_' . $share_key, array(
            'default'           => in_array( $share_key, array( 'native', 'copy', 'facebook', 'x', 'whatsapp', 'telegram', 'line' ), true ) ? 1 : 0,
            'sanitize_callback' => 'newspress_sanitize_boolean',
        ) );
        $wp_customize->add_control( 'newspress_share_' . $share_key, array(
            'type'    => 'checkbox',
            'section' => 'newspress_options',
            'label'   => $share_label,
        ) );
    }

    $wp_customize->add_setting( 'newspress_home_latest_layout', array(
        'default'           => 'list',
        'sanitize_callback' => 'newspress_sanitize_list_grid',
    ) );
    $wp_customize->add_control( 'newspress_home_latest_layout', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Home latest display', 'newspress' ),
        'choices' => array(
            'list' => __( 'List', 'newspress' ),
            'grid' => __( 'Grid', 'newspress' ),
        ),
    ) );

    $latest_visibility = array(
        'show_thumb'    => __( 'Home latest: show thumbnail', 'newspress' ),
        'show_snippet'  => __( 'Home latest: show snippet', 'newspress' ),
        'show_meta'     => __( 'Home latest: show meta info', 'newspress' ),
        'show_category' => __( 'Home latest: show category', 'newspress' ),
    );
    foreach ( $latest_visibility as $key => $label ) {
        $wp_customize->add_setting( 'newspress_home_latest_' . $key, array(
            'default'           => 1,
            'sanitize_callback' => 'newspress_sanitize_boolean',
        ) );
        $wp_customize->add_control( 'newspress_home_latest_' . $key, array(
            'type'    => 'checkbox',
            'section' => 'newspress_options',
            'label'   => $label,
        ) );
    }

    $wp_customize->add_setting( 'newspress_related_layout', array(
        'default'           => 'grid',
        'sanitize_callback' => 'newspress_sanitize_list_grid',
    ) );
    $wp_customize->add_control( 'newspress_related_layout', array(
        'type'    => 'select',
        'section' => 'newspress_options',
        'label'   => __( 'Related posts display', 'newspress' ),
        'choices' => array(
            'list' => __( 'List', 'newspress' ),
            'grid' => __( 'Grid', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_related_count', array(
        'default'           => 6,
        'sanitize_callback' => 'newspress_sanitize_related_count',
    ) );
    $wp_customize->add_control( 'newspress_related_count', array(
        'type'        => 'number',
        'section'     => 'newspress_options',
        'label'       => __( 'Maximum related posts', 'newspress' ),
        'input_attrs' => array( 'min' => 1, 'max' => 12 ),
    ) );

    $related_visibility = array(
        'show_thumb'    => __( 'Related posts: show thumbnail', 'newspress' ),
        'show_snippet'  => __( 'Related posts: show snippet', 'newspress' ),
        'show_meta'     => __( 'Related posts: show meta info', 'newspress' ),
        'show_category' => __( 'Related posts: show category', 'newspress' ),
    );
    foreach ( $related_visibility as $key => $label ) {
        $wp_customize->add_setting( 'newspress_related_' . $key, array(
            'default'           => 1,
            'sanitize_callback' => 'newspress_sanitize_boolean',
        ) );
        $wp_customize->add_control( 'newspress_related_' . $key, array(
            'type'    => 'checkbox',
            'section' => 'newspress_options',
            'label'   => $label,
        ) );
    }


    $newspress_control_priorities = array(
        'newspress_primary_color'                => 6,
        'newspress_accent_color'                 => 7,
        'newspress_text_color'                   => 8,
        'newspress_dark_bg_color'                => 21,
        'newspress_dark_primary_color'           => 22,
        'newspress_dark_accent_color'            => 23,
        'newspress_dark_text_color'              => 24,
        'newspress_layout'                       => 36,
        'newspress_show_clock'                   => 11,
        'newspress_breaking_speed'               => 12,
        'newspress_trending_source'              => 21,
        'newspress_trending_range'               => 22,
        'newspress_trending_count'               => 23,
        'newspress_trending_show_hash'           => 24,
        'newspress_tags_show_hash'               => 25,
        'newspress_breaking_label'               => 31,
        'newspress_breaking_source'              => 32,
        'newspress_breaking_category'            => 33,
        'newspress_breaking_count'               => 34,
        'newspress_single_date_format'           => 41,
        'newspress_date_display_mode'            => 42,
        'newspress_show_single_published_date'   => 43,
        'newspress_show_single_updated_date'     => 44,
        'newspress_show_single_views'            => 45,
        'newspress_single_views_label'           => 46,
        'newspress_show_share_count'             => 51,
        'newspress_share_native'                 => 52,
        'newspress_share_copy'                   => 53,
        'newspress_share_facebook'               => 54,
        'newspress_share_x'                      => 55,
        'newspress_share_whatsapp'               => 56,
        'newspress_share_telegram'               => 57,
        'newspress_share_line'                   => 58,
        'newspress_share_linkedin'               => 59,
        'newspress_share_threads'                => 60,
        'newspress_share_bluesky'                => 61,
        'newspress_share_pinterest'              => 62,
        'newspress_share_instagram'              => 63,
        'newspress_share_tiktok'                 => 64,
        'newspress_footer_bottom_custom'         => 66,
        'newspress_enable_dark_toggle'           => 71,
        'newspress_default_color_scheme'         => 72,
        'newspress_sticky_sidebar'               => 73,
        'newspress_home_latest_layout'           => 81,
        'newspress_home_latest_show_thumb'       => 82,
        'newspress_home_latest_show_snippet'     => 83,
        'newspress_home_latest_show_meta'        => 84,
        'newspress_home_latest_show_category'    => 85,
        'newspress_related_layout'               => 91,
        'newspress_related_count'                => 92,
        'newspress_related_show_thumb'           => 93,
        'newspress_related_show_snippet'         => 94,
        'newspress_related_show_meta'            => 95,
        'newspress_related_show_category'        => 96,
    );

    foreach ( $newspress_control_priorities as $control_id => $priority ) {
        $control = $wp_customize->get_control( $control_id );
        if ( $control ) {
            $control->priority = $priority;
        }
    }


    $wp_customize->add_section( 'newspress_home_layout', array(
        'title'       => __( 'NewsPress Homepage Layout', 'newspress' ),
        'priority'    => 33,
        'description' => __( 'The full drag-and-drop interlude builder is available in Appearance > Homepage Builder. These controls sync with the same homepage settings.', 'newspress' ),
    ) );

    $home_number_settings = array(
        'main_rows'     => array( __( 'Number of main rows', 'newspress' ), 5, 1, 8 ),
        'posts_per_row' => array( __( 'Posts per latest row', 'newspress' ), 5, 1, 10 ),
        'load_more_min' => array( __( 'Minimum posts before Load More is active', 'newspress' ), 10, 1, 50 ),
    );
    foreach ( $home_number_settings as $key => $data ) {
        $wp_customize->add_setting( 'newspress_home_settings[' . $key . ']', array(
            'type'              => 'option',
            'default'           => $data[1],
            'sanitize_callback' => 'absint',
        ) );
        $wp_customize->add_control( 'newspress_home_settings[' . $key . ']', array(
            'type'        => 'number',
            'section'     => 'newspress_home_layout',
            'label'       => $data[0],
            'input_attrs' => array( 'min' => $data[2], 'max' => $data[3] ),
        ) );
    }

    $wp_customize->add_setting( 'newspress_home_settings[latest_nav_mode]', array(
        'type'              => 'option',
        'default'           => 'load_more',
        'sanitize_callback' => 'newspress_sanitize_latest_nav_mode',
    ) );
    $wp_customize->add_control( 'newspress_home_settings[latest_nav_mode]', array(
        'type'    => 'select',
        'section' => 'newspress_home_layout',
        'label'   => __( 'Latest navigation style', 'newspress' ),
        'choices' => array(
            'load_more'  => __( 'Load More button', 'newspress' ),
            'pagination' => __( 'Pagination', 'newspress' ),
        ),
    ) );

    $wp_customize->add_setting( 'newspress_home_settings[show_home_top]', array(
        'type'              => 'option',
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_home_settings[show_home_top]', array(
        'type'    => 'checkbox',
        'section' => 'newspress_home_layout',
        'label'   => __( 'Show Homepage Top widget area above Hero', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_home_settings[row_ad_enabled]', array(
        'type'              => 'option',
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_home_settings[row_ad_enabled]', array(
        'type'    => 'checkbox',
        'section' => 'newspress_home_layout',
        'label'   => __( 'Show ad slot before latest posts in each latest row', 'newspress' ),
    ) );


    $wp_customize->add_section( 'newspress_seo', array(
        'title'       => __( 'NewsPress SEO', 'newspress' ),
        'priority'    => 34,
        'description' => __( 'Basic SEO helpers are automatically disabled when Yoast, Rank Math, AIOSEO, or SEOPress is active.', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_enable_basic_seo', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_enable_basic_seo', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Enable fallback meta description and tag keywords', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_enable_og_meta', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_enable_og_meta', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Enable fallback Open Graph and Twitter Card meta', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_enable_jsonld', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_enable_jsonld', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Enable theme JSON-LD schema', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_disable_schema_when_seo_plugin_active', array(
        'default'           => 0,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_disable_schema_when_seo_plugin_active', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Disable theme JSON-LD when a major SEO plugin is active', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_preload_featured_image', array(
        'default'           => 1,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_preload_featured_image', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Preload featured image on single posts', 'newspress' ),
    ) );

    $wp_customize->add_setting( 'newspress_preconnect_google_fonts', array(
        'default'           => 0,
        'sanitize_callback' => 'newspress_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'newspress_preconnect_google_fonts', array(
        'type'    => 'checkbox',
        'section' => 'newspress_seo',
        'label'   => __( 'Preconnect to Google Fonts when you load external fonts', 'newspress' ),
    ) );


    $wp_customize->add_section( 'newspress_performance', array(
        'title'       => __( 'NewsPress Performance', 'newspress' ),
        'priority'    => 35,
        'description' => __( 'Safe frontend optimizations for PageSpeed. Disable individual options if a plugin or Gutenberg block needs the removed asset.', 'newspress' ),
    ) );

    $perf_options = array(
        'disable_emojis'             => array( __( 'Disable WordPress emoji script/styles', 'newspress' ), 1 ),
        'disable_embeds'             => array( __( 'Disable wp-embed script', 'newspress' ), 1 ),
        'clean_head'                 => array( __( 'Remove unused legacy head links', 'newspress' ), 1 ),
        'remove_block_css'           => array( __( 'Remove default block library CSS on frontend', 'newspress' ), 1 ),
        'remove_global_styles'       => array( __( 'Remove global styles inline CSS/SVG filters', 'newspress' ), 1 ),
        'remove_dashicons_logged_out'=> array( __( 'Remove Dashicons for logged-out visitors', 'newspress' ), 1 ),
        'defer_theme_js'             => array( __( 'Defer NewsPress frontend JavaScript', 'newspress' ), 1 ),
        'preload_hero_image'         => array( __( 'Preload homepage hero image', 'newspress' ), 1 ),
    );

    foreach ( $perf_options as $id => $data ) {
        $wp_customize->add_setting( 'newspress_perf_' . $id, array(
            'default'           => $data[1],
            'sanitize_callback' => 'newspress_sanitize_boolean',
        ) );
        $wp_customize->add_control( 'newspress_perf_' . $id, array(
            'type'    => 'checkbox',
            'section' => 'newspress_performance',
            'label'   => $data[0],
        ) );
    }

}
add_action( 'customize_register', 'newspress_customize_register' );

function newspress_customizer_css() {
    $primary      = sanitize_hex_color( get_theme_mod( 'newspress_primary_color', '#00579c' ) );
    $accent       = sanitize_hex_color( get_theme_mod( 'newspress_accent_color', '#f58220' ) );
    $text         = sanitize_hex_color( get_theme_mod( 'newspress_text_color', '#171717' ) );
    $dark_bg      = sanitize_hex_color( get_theme_mod( 'newspress_dark_bg_color', '#06080d' ) );
    $dark_primary = sanitize_hex_color( get_theme_mod( 'newspress_dark_primary_color', '#75bfff' ) );
    $dark_accent  = sanitize_hex_color( get_theme_mod( 'newspress_dark_accent_color', '#ff9b3d' ) );
    $dark_text    = sanitize_hex_color( get_theme_mod( 'newspress_dark_text_color', '#e6edf7' ) );

    $primary      = $primary ? $primary : '#00579c';
    $accent       = $accent ? $accent : '#f58220';
    $text         = $text ? $text : '#171717';
    $dark_bg      = $dark_bg ? $dark_bg : '#06080d';
    $dark_primary = $dark_primary ? $dark_primary : '#75bfff';
    $dark_accent  = $dark_accent ? $dark_accent : '#ff9b3d';
    $dark_text    = $dark_text ? $dark_text : '#e6edf7';

    $ticker_speed = min( 240, max( 1, absint( get_theme_mod( 'newspress_breaking_speed', 120 ) ) ) );

    $css  = ':root{';
    $css .= '--np-primary:' . esc_attr( $primary ) . ';';
    $css .= '--np-primary-dark:' . esc_attr( $primary ) . ';';
    $css .= '--np-primary-rgb:' . esc_attr( newspress_hex_to_rgb_triplet( $primary ) ) . ';';
    $css .= '--np-primary-soft:rgba(' . esc_attr( newspress_hex_to_rgb_triplet( $primary ) ) . ',.11);';
    $css .= '--np-accent:' . esc_attr( $accent ) . ';';
    $css .= '--np-accent-dark:' . esc_attr( $accent ) . ';';
    $css .= '--np-text:' . esc_attr( $text ) . ';';
    $css .= '--np-heading:' . esc_attr( $text ) . ';';
    $css .= '--np-breaking-speed:' . esc_attr( $ticker_speed ) . 's;';
    $css .= '}';
    $css .= 'html[data-theme="dark"]{';
    $css .= '--np-bg:' . esc_attr( $dark_bg ) . ';';
    $css .= '--np-surface:color-mix(in srgb,' . esc_attr( $dark_bg ) . ' 86%,#ffffff);';
    $css .= '--np-soft:color-mix(in srgb,' . esc_attr( $dark_bg ) . ' 76%,#ffffff);';
    $css .= '--np-soft-2:color-mix(in srgb,' . esc_attr( $dark_bg ) . ' 70%,#ffffff);';
    $css .= '--np-primary:' . esc_attr( $dark_primary ) . ';';
    $css .= '--np-primary-dark:' . esc_attr( $dark_primary ) . ';';
    $css .= '--np-primary-rgb:' . esc_attr( newspress_hex_to_rgb_triplet( $dark_primary ) ) . ';';
    $css .= '--np-primary-soft:rgba(' . esc_attr( newspress_hex_to_rgb_triplet( $dark_primary ) ) . ',.24);';
    $css .= '--np-accent:' . esc_attr( $dark_accent ) . ';';
    $css .= '--np-accent-dark:' . esc_attr( $dark_accent ) . ';';
    $css .= '--np-accent-soft:rgba(' . esc_attr( newspress_hex_to_rgb_triplet( $dark_accent ) ) . ',.18);';
    $css .= '--np-text:' . esc_attr( $dark_text ) . ';';
    $css .= '--np-heading:' . esc_attr( $dark_text ) . ';';
    $css .= '--np-muted:color-mix(in srgb,' . esc_attr( $dark_text ) . ' 72%,transparent);';
    $css .= '--np-soft-muted:color-mix(in srgb,' . esc_attr( $dark_text ) . ' 62%,transparent);';
    $css .= '--np-border:color-mix(in srgb,' . esc_attr( $dark_text ) . ' 22%,transparent);';
    $css .= '}';

    echo '<style id="newspress-custom-vars">' . $css . '</style>';
}
add_action( 'wp_head', 'newspress_customizer_css', 99 );

function newspress_body_classes( $classes ) {
    $classes[] = get_theme_mod( 'newspress_sticky_sidebar', 1 ) ? 'np-sticky-sidebar-enabled' : 'np-sticky-sidebar-disabled';
    $classes[] = get_theme_mod( 'newspress_enable_dark_toggle', 1 ) ? 'np-dark-toggle-enabled' : 'np-dark-toggle-disabled';
    return $classes;
}
add_filter( 'body_class', 'newspress_body_classes' );
