<?php
/** Widget areas and custom widgets. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_widgets_init() {
    $areas = array(
        'sidebar-1'           => __( 'Main Sidebar', 'newspress' ),
        'single-sidebar'      => __( 'Single Post Sidebar', 'newspress' ),
        'home-paged-sidebar'  => __( 'Blog Paged Sidebar', 'newspress' ),
        'home-top'            => __( 'Homepage Top', 'newspress' ),
        'ad-leaderboard'      => __( 'Ad Leaderboard', 'newspress' ),
        'home-slider'         => __( 'Homepage Slider Above Hero', 'newspress' ),
        'home-hero-grid'      => __( 'Homepage Hero Grid', 'newspress' ),
        'home-ad-slot'        => __( 'Homepage Ad Slot', 'newspress' ),
        'home-between'        => __( 'Homepage Between Blocks (Fallback)', 'newspress' ),
        'home-sidebar-hero'   => __( 'Homepage Hero Sidebar', 'newspress' ),
        'home-sidebar-latest' => __( 'Homepage Latest Sidebar', 'newspress' ),
        'home-primary-side'   => __( 'Homepage Primary Right Widget', 'newspress' ),
        'home-popular'        => __( 'Homepage Popular Posts', 'newspress' ),
        'sidebar-popular'     => __( 'Sidebar Popular Posts', 'newspress' ),
        'article-ad-before'   => __( 'Article Ad: Before First Paragraph', 'newspress' ),
        'article-ad-middle'   => __( 'Article Ad: Middle Article', 'newspress' ),
        'article-ad-after'    => __( 'Article Ad: After Last Paragraph', 'newspress' ),
        'footer-grid'         => __( 'Footer Grid', 'newspress' ),
        'footer-1'            => __( 'Footer Column 1', 'newspress' ),
        'footer-2'            => __( 'Footer Column 2', 'newspress' ),
        'footer-3'            => __( 'Footer Column 3', 'newspress' ),
        'footer-4'            => __( 'Footer Column 4', 'newspress' ),
    );
    $home_settings  = function_exists( 'newspress_get_home_settings' ) ? newspress_get_home_settings() : wp_parse_args( get_option( 'newspress_home_settings', array() ), array( 'main_rows' => 5 ) );
    $home_rows      = isset( $home_settings['main_rows'] ) ? min( 8, max( 1, absint( $home_settings['main_rows'] ) ) ) : 5;
    $latest_rows    = max( 0, $home_rows - 1 );
    $interlude_rows = max( 0, $home_rows - 1 );

    for ( $i = 1; $i <= $interlude_rows; $i++ ) {
        $areas[ 'home-between-' . $i ] = sprintf( __( 'Homepage Between Main Rows %d', 'newspress' ), $i );
    }

    for ( $i = 1; $i <= $latest_rows; $i++ ) {
        $areas[ 'home-row-ad-' . $i ]   = sprintf( __( 'Homepage Row %d Ad Widget', 'newspress' ), $i );
        $areas[ 'home-row-side-' . $i ] = sprintf( __( 'Homepage Row %d Right Widget', 'newspress' ), $i );
    }
    foreach ( $areas as $id => $name ) {
        $before_widget = '<section id="%1$s" class="widget %2$s">';
        $after_widget  = '</section>';

        if ( 'home-hero-grid' === $id ) {
            $before_widget = '<div id="%1$s" class="widget %2$s np-hero-widget-host">';
            $after_widget  = '</div>';
        } elseif ( in_array( $id, array( 'ad-leaderboard', 'home-ad-slot' ), true ) ) {
            $before_widget = '<div id="%1$s" class="widget %2$s np-ad-widget-host">';
            $after_widget  = '</div>';
        } elseif ( 'footer-grid' === $id ) {
            $before_widget = '<div id="%1$s" class="widget %2$s np-footer-grid-widget-host">';
            $after_widget  = '</div>';
        }

        register_sidebar( array(
            'name'          => $name,
            'id'            => $id,
            'description'   => __( 'Add widgets here.', 'newspress' ),
            'before_widget' => $before_widget,
            'after_widget'  => $after_widget,
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ) );
    }
}
add_action( 'widgets_init', 'newspress_widgets_init' );

function newspress_views_keys() {
    $time = current_time( 'timestamp' );
    return array(
        'day'   => '_newspress_views_day_' . gmdate( 'Ymd', $time + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
        'week'  => '_newspress_views_week_' . gmdate( 'oW', $time + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
        'month' => '_newspress_views_month_' . gmdate( 'Ym', $time + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
        'year'  => '_newspress_views_year_' . gmdate( 'Y', $time + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
        'all'   => '_newspress_views_total',
    );
}

function newspress_increment_post_meta_counter( $post_id, $meta_key ) {
    global $wpdb;

    $post_id  = absint( $post_id );
    $meta_key = sanitize_key( $meta_key );

    if ( ! $post_id || ! $meta_key ) {
        return;
    }

    $updated = $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = %s",
        $post_id,
        $meta_key
    ) );

    if ( ! $updated ) {
        add_post_meta( $post_id, $meta_key, 1, true );
    }

    wp_cache_delete( $post_id, 'post_meta' );
}

function newspress_get_view_client_hash() {
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
    $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

    if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
        $ip_parts = explode( '.', $ip );
        if ( 4 === count( $ip_parts ) ) {
            $ip = $ip_parts[0] . '.' . $ip_parts[1] . '.' . $ip_parts[2] . '.0';
        }
    } else {
        $ip = '';
    }

    return wp_hash( $ip . '|' . substr( $ua, 0, 180 ) );
}

function newspress_is_post_view_rate_limited( $post_id ) {
    $post_id = absint( $post_id );
    if ( ! $post_id ) {
        return true;
    }

    $client_hash = newspress_get_view_client_hash();
    if ( ! $client_hash ) {
        return true;
    }

    $transient_key = 'np_view_' . md5( $post_id . '|' . $client_hash );
    if ( get_transient( $transient_key ) ) {
        return true;
    }

    /**
     * Filters how long one visitor is counted only once per post.
     * Default: 30 minutes.
     */
    $ttl = (int) apply_filters( 'newspress_view_rate_limit_ttl', 30 * MINUTE_IN_SECONDS );
    set_transient( $transient_key, 1, max( MINUTE_IN_SECONDS, $ttl ) );

    return false;
}

function newspress_track_post_view_rest( WP_REST_Request $request ) {
    $post_id = absint( $request->get_param( 'post_id' ) );
    $post    = $post_id ? get_post( $post_id ) : null;

    if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
        return new WP_REST_Response( array( 'tracked' => false ), 400 );
    }

    if ( newspress_is_post_view_rate_limited( $post_id ) ) {
        return new WP_REST_Response( array( 'tracked' => false, 'reason' => 'rate_limited' ), 429 );
    }

    foreach ( newspress_views_keys() as $key ) {
        newspress_increment_post_meta_counter( $post_id, $key );
    }

    return new WP_REST_Response( array( 'tracked' => true ), 200 );
}


function newspress_is_post_share_rate_limited( $post_id, $service = '' ) {
    $post_id = absint( $post_id );
    $service = sanitize_key( $service );

    if ( ! $post_id ) {
        return true;
    }

    $client_hash = newspress_get_view_client_hash();
    if ( ! $client_hash ) {
        return true;
    }

    $transient_key = 'np_share_' . md5( $post_id . '|' . $service . '|' . $client_hash );
    if ( get_transient( $transient_key ) ) {
        return true;
    }

    /**
     * Filters how long the same visitor/service click is counted only once per post.
     * Default: 5 seconds, only to prevent accidental double clicks/programmatic duplicates.
     */
    $ttl = (int) apply_filters( 'newspress_share_rate_limit_ttl', 5 );
    set_transient( $transient_key, 1, max( 1, $ttl ) );

    return false;
}

function newspress_track_post_share_rest( WP_REST_Request $request ) {
    $post_id = absint( $request->get_param( 'post_id' ) );
    $service = sanitize_key( (string) $request->get_param( 'service' ) );
    $post    = $post_id ? get_post( $post_id ) : null;

    if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
        return new WP_REST_Response( array( 'tracked' => false ), 400 );
    }

    if ( newspress_is_post_share_rate_limited( $post_id, $service ) ) {
        return new WP_REST_Response( array(
            'tracked' => false,
            'reason'  => 'rate_limited',
            'count'   => function_exists( 'newspress_get_post_shares_count' ) ? newspress_get_post_shares_count( $post_id ) : absint( get_post_meta( $post_id, '_newspress_shares_total', true ) ),
        ), 429 );
    }

    newspress_increment_post_meta_counter( $post_id, '_newspress_shares_total' );

    return new WP_REST_Response( array(
        'tracked' => true,
        'count'   => function_exists( 'newspress_get_post_shares_count' ) ? newspress_get_post_shares_count( $post_id ) : absint( get_post_meta( $post_id, '_newspress_shares_total', true ) ),
    ), 200 );
}

function newspress_register_view_tracking_route() {
    register_rest_route( 'newspress/v1', '/view', array(
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'newspress_track_post_view_rest',
        'permission_callback' => '__return_true',
        'args'                => array(
            'post_id' => array(
                'required'          => true,
                'sanitize_callback' => 'absint',
            ),
        ),
    ) );

    register_rest_route( 'newspress/v1', '/share', array(
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'newspress_track_post_share_rest',
        'permission_callback' => '__return_true',
        'args'                => array(
            'post_id' => array(
                'required'          => true,
                'sanitize_callback' => 'absint',
            ),
            'service' => array(
                'required'          => false,
                'sanitize_callback' => 'sanitize_key',
            ),
        ),
    ) );
}
add_action( 'rest_api_init', 'newspress_register_view_tracking_route' );

function newspress_widget_thumb( $post_id, $size = 'thumbnail' ) {
    if ( has_post_thumbnail( $post_id ) ) {
        return get_the_post_thumbnail( $post_id, $size, array( 'class' => 'np-widget-thumb-img', 'loading' => 'lazy', 'decoding' => 'async' ) );
    }
    return '<span class="np-widget-thumb-placeholder">' . newspress_svg_icon( 'schedule', 22 ) . '</span>';
}

function newspress_render_post_widget_list( $query, $show_rank = false ) {
    if ( ! $query->have_posts() ) {
        echo '<p class="np-widget-empty">' . esc_html__( 'No posts found.', 'newspress' ) . '</p>';
        return;
    }
    echo '<ol class="np-widget-posts ' . ( $show_rank ? 'has-rank' : 'no-rank' ) . '">';
    $i = 1;
    while ( $query->have_posts() ) {
        $query->the_post();
        echo '<li class="np-widget-post-item">';
        echo '<a class="np-widget-thumb" href="' . esc_url( get_permalink() ) . '">' . newspress_widget_thumb( get_the_ID() ) . '</a>';
        echo '<div class="np-widget-post-body">';
        echo '<a class="np-widget-post-title" href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a>';
        $meta_text = esc_html( newspress_get_post_date_text() );
        if ( $show_rank ) {
            echo '<span class="np-widget-post-meta"><span class="np-widget-rank-inline">' . esc_html( sprintf( '%02d', $i ) ) . '</span> ' . $meta_text . '</span>';
        } else {
            echo '<span class="np-widget-post-meta">' . $meta_text . '</span>';
        }
        echo '</div></li>';
        $i++;
    }
    echo '</ol>';
    wp_reset_postdata();
}

class NewsPress_Popular_Posts_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_popular_posts', __( 'NP Popular List', 'newspress' ), array(
            'description' => __( 'Display popular posts with thumbnails by day, week, month, year, or all time.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        $range = ! empty( $instance['range'] ) ? sanitize_key( $instance['range'] ) : 'week';
        $count = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $keys = newspress_views_keys();
        $meta_key = isset( $keys[ $range ] ) ? $keys[ $range ] : $keys['week'];
        $q = new WP_Query( array(
            'posts_per_page'      => min( 10, max( 1, $count ) ),
            'ignore_sticky_posts' => true,
            'meta_key'            => $meta_key,
            'orderby'             => 'meta_value_num',
            'order'               => 'DESC',
            'post_status'         => 'publish',
            'no_found_rows'       => true,
        ) );
        if ( ! $q->have_posts() ) {
            $q = new WP_Query( array(
                'posts_per_page'      => min( 10, max( 1, $count ) ),
                'ignore_sticky_posts' => true,
                'orderby'             => 'comment_count',
                'order'               => 'DESC',
                'post_status'         => 'publish',
                'no_found_rows'       => true,
            ) );
        }
        newspress_render_post_widget_list( $q, true );
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $range = isset( $instance['range'] ) ? $instance['range'] : 'week';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        $ranges = array(
            'day'   => __( 'Today', 'newspress' ),
            'week'  => __( 'This Week', 'newspress' ),
            'month' => __( 'This Month', 'newspress' ),
            'year'  => __( 'This Year', 'newspress' ),
            'all'   => __( 'All Time', 'newspress' ),
        );
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'range' ) ); ?>"><?php esc_html_e( 'Popularity range:', 'newspress' ); ?></label>
        <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'range' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'range' ) ); ?>">
            <?php foreach ( $ranges as $key => $label ) : ?>
                <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $range, $key ); ?>><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="10" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title' => sanitize_text_field( $new_instance['title'] ),
            'range' => in_array( sanitize_key( $new_instance['range'] ), array( 'day', 'week', 'month', 'year', 'all' ), true ) ? sanitize_key( $new_instance['range'] ) : 'week',
            'count' => min( 10, max( 1, absint( $new_instance['count'] ) ) ),
        );
    }
}

class NewsPress_Recent_Posts_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_recent_posts', __( 'NP Recent List', 'newspress' ), array(
            'description' => __( 'Display recent posts with thumbnails.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        $count = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        $cat   = ! empty( $instance['category'] ) ? absint( $instance['category'] ) : 0;
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $query_args = array(
            'posts_per_page'      => min( 10, max( 1, $count ) ),
            'ignore_sticky_posts' => true,
            'post_status'         => 'publish',
            'no_found_rows'       => true,
        );
        if ( $cat ) {
            $query_args['cat'] = $cat;
        }
        $q = new WP_Query( $query_args );
        newspress_render_post_widget_list( $q, false );
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="10" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php newspress_widget_category_dropdown( $this, $instance ); ?>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'    => sanitize_text_field( $new_instance['title'] ),
            'count'    => min( 10, max( 1, absint( $new_instance['count'] ) ) ),
            'category' => isset( $new_instance['category'] ) ? absint( $new_instance['category'] ) : 0,
        );
    }
}



function newspress_thumbnail_html( $post_id, $size = 'newspress-thumb', $class = '' ) {
    $post_id = absint( $post_id );
    if ( $post_id && has_post_thumbnail( $post_id ) ) {
        return get_the_post_thumbnail( $post_id, $size, array( 'class' => trim( 'np-img ' . $class ), 'loading' => 'lazy', 'decoding' => 'async' ) );
    }
    return '<div class="np-img np-img-placeholder ' . esc_attr( $class ) . '">' . esc_html__( 'No Image', 'newspress' ) . '</div>';
}

function newspress_get_posted_on_html() {
    ob_start();
    newspress_posted_on();
    return trim( ob_get_clean() );
}

function newspress_widget_category_dropdown( $widget, $instance, $field = 'category' ) {
    $selected = isset( $instance[ $field ] ) ? absint( $instance[ $field ] ) : 0;
    $cats     = get_categories( array( 'hide_empty' => false ) );
    ?>
    <p><label for="<?php echo esc_attr( $widget->get_field_id( $field ) ); ?>"><?php esc_html_e( 'Category:', 'newspress' ); ?></label>
    <select class="widefat" id="<?php echo esc_attr( $widget->get_field_id( $field ) ); ?>" name="<?php echo esc_attr( $widget->get_field_name( $field ) ); ?>">
        <option value="0" <?php selected( $selected, 0 ); ?>><?php esc_html_e( 'Recent / All categories', 'newspress' ); ?></option>
        <?php foreach ( $cats as $cat ) : ?>
            <option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $selected, $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
        <?php endforeach; ?>
    </select></p>
    <?php
}

function newspress_widget_query_posts( $instance, $default_count = 6 ) {
    $count = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : $default_count;
    $cat   = ! empty( $instance['category'] ) ? absint( $instance['category'] ) : 0;
    $args  = array(
        'posts_per_page'      => min( 12, max( 1, $count ) ),
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'no_found_rows'       => true,
    );
    if ( $cat ) {
        $args['cat'] = $cat;
    }
    return new WP_Query( $args );
}

function newspress_render_hero_grid_posts( WP_Query $query, $show_excerpt = true ) {
    if ( ! $query->have_posts() ) {
        echo '<p class="np-widget-empty">' . esc_html__( 'No posts found.', 'newspress' ) . '</p>';
        return;
    }

    echo '<div class="np-hero-grid">';
    $i = 0;
    while ( $query->have_posts() ) {
        $query->the_post();
        $i++;
        $is_main = 1 === $i;
        echo '<article class="np-hero-card ' . ( $is_main ? 'is-main' : 'is-sub' ) . '">';
        echo '<a class="np-hero-img" href="' . esc_url( get_permalink() ) . '">';
        newspress_thumbnail( $is_main ? 'newspress-hero' : 'newspress-card', '', $is_main ? array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async' ) : array( 'loading' => 'lazy', 'decoding' => 'async' ) );
        echo '</a>';
        echo '<div class="np-hero-body">';
        newspress_category_badge();
        echo '<h2><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h2>';
        if ( $is_main && $show_excerpt ) {
            echo '<p>' . esc_html( newspress_excerpt( 20 ) ) . '</p>';
        }
        echo '<div class="np-meta">';
        newspress_posted_by();
        echo ' <span>•</span> ';
        newspress_posted_on();
        echo '</div>';
        echo '</div></article>';
    }
    echo '</div>';
    wp_reset_postdata();
}

class NewsPress_Hero_Grid_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_hero_grid', __( 'NP Hero Grid', 'newspress' ), array(
            'description' => __( 'Editable homepage hero grid. Place this widget in Homepage Hero Grid to show the Customizer pencil control.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title        = ! empty( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';
        $category     = ! empty( $instance['category'] ) ? absint( $instance['category'] ) : 0;
        $count        = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : 3;
        $show_excerpt = ! array_key_exists( 'show_excerpt', $instance ) || ! empty( $instance['show_excerpt'] );
        $source       = ! empty( $instance['source'] ) ? sanitize_key( $instance['source'] ) : 'latest';

        $query_args = array(
            'post_type'           => 'post',
            'post_status'         => 'publish',
            'posts_per_page'      => min( 5, max( 3, $count ) ),
            'ignore_sticky_posts' => 'sticky' === $source ? false : true,
            'no_found_rows'       => true,
        );

        if ( $category ) {
            $query_args['cat'] = $category;
        }

        if ( 'sticky' === $source ) {
            $sticky = get_option( 'sticky_posts', array() );
            if ( ! empty( $sticky ) ) {
                $query_args['post__in'] = array_map( 'absint', $sticky );
                $query_args['orderby']  = 'post__in';
            }
        }

        $q = new WP_Query( $query_args );

        echo $args['before_widget'];
        if ( $title ) {
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        }
        newspress_render_hero_grid_posts( $q, $show_excerpt );
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title        = isset( $instance['title'] ) ? $instance['title'] : '';
        $category     = isset( $instance['category'] ) ? absint( $instance['category'] ) : 0;
        $count        = isset( $instance['count'] ) ? absint( $instance['count'] ) : 3;
        $show_excerpt = ! array_key_exists( 'show_excerpt', $instance ) || ! empty( $instance['show_excerpt'] );
        $source       = isset( $instance['source'] ) ? sanitize_key( $instance['source'] ) : 'latest';
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title (optional):', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'source' ) ); ?>"><?php esc_html_e( 'Source:', 'newspress' ); ?></label>
        <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'source' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'source' ) ); ?>">
            <option value="latest" <?php selected( $source, 'latest' ); ?>><?php esc_html_e( 'Latest posts', 'newspress' ); ?></option>
            <option value="sticky" <?php selected( $source, 'sticky' ); ?>><?php esc_html_e( 'Sticky posts first', 'newspress' ); ?></option>
        </select></p>
        <?php newspress_widget_category_dropdown( $this, array( 'category' => $category ) ); ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="3" max="5" value="<?php echo esc_attr( $count ); ?>"></p>
        <p><input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_excerpt' ) ); ?>" value="1" <?php checked( $show_excerpt ); ?>>
        <label for="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>"><?php esc_html_e( 'Show excerpt on main hero', 'newspress' ); ?></label></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $source = ! empty( $new_instance['source'] ) ? sanitize_key( $new_instance['source'] ) : 'latest';
        return array(
            'title'        => sanitize_text_field( $new_instance['title'] ?? '' ),
            'source'       => in_array( $source, array( 'latest', 'sticky' ), true ) ? $source : 'latest',
            'category'     => absint( $new_instance['category'] ?? 0 ),
            'count'        => min( 5, max( 3, absint( $new_instance['count'] ?? 3 ) ) ),
            'show_excerpt' => ! empty( $new_instance['show_excerpt'] ) ? 1 : 0,
        );
    }
}

class NewsPress_Recent_First_Big_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_recent_first_big', __( 'NP Recent First Big', 'newspress' ), array(
            'description' => __( 'Display recent or category posts with the first post highlighted and the rest as compact list.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $q = newspress_widget_query_posts( $instance, 6 );
        if ( ! $q->have_posts() ) {
            echo '<p class="np-widget-empty">' . esc_html__( 'No posts found.', 'newspress' ) . '</p>';
            echo $args['after_widget'];
            return;
        }
        echo '<div class="np-widget-firstbig np-category-grid">';
        $i = 0;
        while ( $q->have_posts() ) {
            $q->the_post();
            $i++;
            if ( 1 === $i ) {
                echo '<article class="np-cat-main np-widget-firstbig-main">';
                echo '<a href="' . esc_url( get_permalink() ) . '">' . newspress_thumbnail_html( get_the_ID(), 'newspress-card' ) . '</a>';
                newspress_category_badge();
                echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                echo '<p>' . esc_html( newspress_excerpt( 18 ) ) . '</p>';
                echo '<div class="np-meta">' . newspress_get_posted_on_html() . '</div>';
                echo '</article><div class="np-cat-list np-widget-firstbig-list">';
            } else {
                echo '<article class="np-mini-card">';
                echo '<a href="' . esc_url( get_permalink() ) . '">' . newspress_thumbnail_html( get_the_ID(), 'newspress-thumb' ) . '</a>';
                echo '<div>';
                newspress_category_badge();
                echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                echo '<div class="np-meta">' . newspress_get_posted_on_html() . '</div>';
                echo '</div></article>';
            }
        }
        if ( $i > 1 ) {
            echo '</div>';
        }
        echo '</div>';
        wp_reset_postdata();
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 6;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <?php newspress_widget_category_dropdown( $this, $instance ); ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="2" max="12" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'    => sanitize_text_field( $new_instance['title'] ?? '' ),
            'category' => absint( $new_instance['category'] ?? 0 ),
            'count'    => min( 12, max( 2, absint( $new_instance['count'] ?? 6 ) ) ),
        );
    }
}

class NewsPress_Recent_Grid_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_recent_grid', __( 'NP Recent Grid', 'newspress' ), array(
            'description' => __( 'Display recent or category posts in a flat editorial grid.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $q = newspress_widget_query_posts( $instance, 6 );
        if ( ! $q->have_posts() ) {
            echo '<p class="np-widget-empty">' . esc_html__( 'No posts found.', 'newspress' ) . '</p>';
            echo $args['after_widget'];
            return;
        }
        echo '<div class="np-widget-recent-grid">';
        while ( $q->have_posts() ) {
            $q->the_post();
            echo '<article class="np-widget-grid-card">';
            echo '<a class="np-widget-grid-img" href="' . esc_url( get_permalink() ) . '">' . newspress_thumbnail_html( get_the_ID(), 'newspress-thumb' ) . '</a>';
            echo '<div class="np-widget-grid-body">';
            newspress_category_badge();
            echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
            echo '<div class="np-meta">' . newspress_get_posted_on_html() . '</div>';
            echo '</div></article>';
        }
        echo '</div>';
        wp_reset_postdata();
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 6;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <?php newspress_widget_category_dropdown( $this, $instance ); ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="12" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'    => sanitize_text_field( $new_instance['title'] ?? '' ),
            'category' => absint( $new_instance['category'] ?? 0 ),
            'count'    => min( 12, max( 1, absint( $new_instance['count'] ?? 6 ) ) ),
        );
    }
}



class NewsPress_Recent_Slider_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_recent_slider', __( 'NP Recent Slider', 'newspress' ), array(
            'description' => __( 'Display a responsive recent post slider with category, snippet, and autoplay options.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title          = ! empty( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';
        $num_posts      = ! empty( $instance['num_posts'] ) ? absint( $instance['num_posts'] ) : 5;
        $category_id    = ! empty( $instance['category_id'] ) ? absint( $instance['category_id'] ) : 0;
        $show_category  = ! empty( $instance['show_category'] );
        $show_snippet   = ! empty( $instance['show_snippet'] );
        $snippet_length = ! empty( $instance['snippet_length'] ) ? absint( $instance['snippet_length'] ) : 120;
        $autoplay       = ! array_key_exists( 'autoplay', $instance ) || ! empty( $instance['autoplay'] );
        $autoplay_speed = ! empty( $instance['autoplay_speed'] ) ? absint( $instance['autoplay_speed'] ) : 5000;

        $query_args = array(
            'post_type'           => 'post',
            'post_status'         => 'publish',
            'posts_per_page'      => min( 12, max( 1, $num_posts ) ),
            'orderby'             => 'date',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        );

        if ( $category_id > 0 ) {
            $query_args['cat'] = $category_id;
        }

        $posts = new WP_Query( $query_args );

        if ( ! $posts->have_posts() ) {
            return;
        }

        echo $args['before_widget'];
        $slider_id = 'np-slider-' . sanitize_html_class( $this->id );
        ?>
        <div class="np-recent-slider-wrap"
             data-np-slider="1"
             data-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>"
             data-speed="<?php echo esc_attr( max( 1000, min( 30000, $autoplay_speed ) ) ); ?>"
             id="<?php echo esc_attr( $slider_id ); ?>">

            <?php if ( $title ) : ?>
                <?php echo $args['before_title'] . esc_html( $title ) . $args['after_title']; ?>
            <?php endif; ?>

            <div class="np-slider-container">
                <div class="np-slider-track">
                    <?php while ( $posts->have_posts() ) : $posts->the_post(); ?>
                        <article class="np-slide">
                            <a class="np-slide-thumb" href="<?php the_permalink(); ?>">
                                <?php echo newspress_thumbnail_html( get_the_ID(), 'newspress-hero', 'np-slide-img' ); ?>
                            </a>
                            <div class="np-slide-content">
                                <?php if ( $show_category ) : ?>
                                    <div class="np-slide-cats">
                                        <?php
                                        $cats = get_the_category();
                                        if ( $cats ) {
                                            $primary_cat = $cats[0];
                                            echo '<a class="np-category-badge" href="' . esc_url( get_category_link( $primary_cat->term_id ) ) . '">' . esc_html( $primary_cat->name ) . '</a>';
                                        }
                                        ?>
                                    </div>
                                <?php endif; ?>
                                <h2 class="np-slide-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                <?php if ( $show_snippet ) : ?>
                                    <p class="np-slide-snippet"><?php echo esc_html( wp_html_excerpt( wp_strip_all_tags( get_the_excerpt() ?: get_the_content() ), max( 50, min( 500, $snippet_length ) ), '...' ) ); ?></p>
                                <?php endif; ?>
                                <div class="np-slide-meta"><?php echo esc_html( newspress_get_post_date_text() ); ?></div>
                            </div>
                        </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
            </div>

            <button class="np-slider-prev" type="button" aria-label="<?php esc_attr_e( 'Previous slide', 'newspress' ); ?>"><?php echo newspress_svg_icon( 'chevron-left', 20 ); ?></button>
            <button class="np-slider-next" type="button" aria-label="<?php esc_attr_e( 'Next slide', 'newspress' ); ?>"><?php echo newspress_svg_icon( 'chevron-right', 20 ); ?></button>
            <div class="np-slider-dots" aria-label="<?php esc_attr_e( 'Slider pagination', 'newspress' ); ?>"></div>
        </div>
        <?php
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title          = isset( $instance['title'] ) ? $instance['title'] : '';
        $num_posts      = isset( $instance['num_posts'] ) ? absint( $instance['num_posts'] ) : 5;
        $category_id    = isset( $instance['category_id'] ) ? absint( $instance['category_id'] ) : 0;
        $show_category  = ! array_key_exists( 'show_category', $instance ) || ! empty( $instance['show_category'] );
        $show_snippet   = ! empty( $instance['show_snippet'] );
        $snippet_length = isset( $instance['snippet_length'] ) ? absint( $instance['snippet_length'] ) : 120;
        $autoplay       = ! array_key_exists( 'autoplay', $instance ) || ! empty( $instance['autoplay'] );
        $autoplay_speed = isset( $instance['autoplay_speed'] ) ? absint( $instance['autoplay_speed'] ) : 5000;
        $categories     = get_categories( array( 'hide_empty' => false ) );
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'num_posts' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'num_posts' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'num_posts' ) ); ?>" type="number" min="1" max="12" value="<?php echo esc_attr( $num_posts ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'category_id' ) ); ?>"><?php esc_html_e( 'Category:', 'newspress' ); ?></label>
        <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'category_id' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'category_id' ) ); ?>">
            <option value="0" <?php selected( $category_id, 0 ); ?>><?php esc_html_e( 'Recent / All categories', 'newspress' ); ?></option>
            <?php foreach ( $categories as $cat ) : ?>
                <option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $category_id, $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
            <?php endforeach; ?>
        </select></p>
        <p><input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_category' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_category' ) ); ?>" value="1" <?php checked( $show_category ); ?>>
        <label for="<?php echo esc_attr( $this->get_field_id( 'show_category' ) ); ?>"><?php esc_html_e( 'Show category badge', 'newspress' ); ?></label></p>
        <p><input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_snippet' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_snippet' ) ); ?>" value="1" <?php checked( $show_snippet ); ?>>
        <label for="<?php echo esc_attr( $this->get_field_id( 'show_snippet' ) ); ?>"><?php esc_html_e( 'Show snippet', 'newspress' ); ?></label></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'snippet_length' ) ); ?>"><?php esc_html_e( 'Snippet length:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'snippet_length' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'snippet_length' ) ); ?>" type="number" min="50" max="500" value="<?php echo esc_attr( $snippet_length ); ?>"></p>
        <p><input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'autoplay' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'autoplay' ) ); ?>" value="1" <?php checked( $autoplay ); ?>>
        <label for="<?php echo esc_attr( $this->get_field_id( 'autoplay' ) ); ?>"><?php esc_html_e( 'Autoplay slider', 'newspress' ); ?></label></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'autoplay_speed' ) ); ?>"><?php esc_html_e( 'Autoplay speed (ms):', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'autoplay_speed' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'autoplay_speed' ) ); ?>" type="number" min="1000" max="30000" step="500" value="<?php echo esc_attr( $autoplay_speed ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'          => sanitize_text_field( $new_instance['title'] ?? '' ),
            'num_posts'      => min( 12, max( 1, absint( $new_instance['num_posts'] ?? 5 ) ) ),
            'category_id'    => absint( $new_instance['category_id'] ?? 0 ),
            'show_category'  => ! empty( $new_instance['show_category'] ) ? 1 : 0,
            'show_snippet'   => ! empty( $new_instance['show_snippet'] ) ? 1 : 0,
            'snippet_length' => min( 500, max( 50, absint( $new_instance['snippet_length'] ?? 120 ) ) ),
            'autoplay'       => ! empty( $new_instance['autoplay'] ) ? 1 : 0,
            'autoplay_speed' => min( 30000, max( 1000, absint( $new_instance['autoplay_speed'] ?? 5000 ) ) ),
        );
    }
}


function newspress_widget_random_query_posts( $instance, $default_count = 6 ) {
    $count = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : $default_count;
    $cat   = ! empty( $instance['category'] ) ? absint( $instance['category'] ) : 0;
    $args  = array(
        'posts_per_page'      => min( 12, max( 1, $count ) ),
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'orderby'             => 'rand',
        'no_found_rows'       => true,
    );
    if ( $cat ) {
        $args['cat'] = $cat;
    }
    return new WP_Query( $args );
}

class NewsPress_Random_List_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_random_list', __( 'NP Random List', 'newspress' ), array(
            'description' => __( 'Display random posts with thumbnails using the same style as NP Recent List.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $q = newspress_widget_random_query_posts( $instance, 5 );
        newspress_render_post_widget_list( $q, false );
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <?php newspress_widget_category_dropdown( $this, $instance ); ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="12" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'    => sanitize_text_field( $new_instance['title'] ?? '' ),
            'category' => absint( $new_instance['category'] ?? 0 ),
            'count'    => min( 12, max( 1, absint( $new_instance['count'] ?? 5 ) ) ),
        );
    }
}

class NewsPress_Random_Grid_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_random_grid', __( 'NP Random Grid', 'newspress' ), array(
            'description' => __( 'Display random posts in a flat grid using the same style as NP Recent Grid.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        if ( '' !== $title ) { echo $args['before_title'] . esc_html( $title ) . $args['after_title']; }
        $q = newspress_widget_random_query_posts( $instance, 6 );
        if ( ! $q->have_posts() ) {
            echo '<p class="np-widget-empty">' . esc_html__( 'No posts found.', 'newspress' ) . '</p>';
            echo $args['after_widget'];
            return;
        }
        echo '<div class="np-widget-recent-grid np-widget-random-grid">';
        while ( $q->have_posts() ) {
            $q->the_post();
            echo '<article class="np-widget-grid-card">';
            echo '<a class="np-widget-grid-img" href="' . esc_url( get_permalink() ) . '">' . newspress_thumbnail_html( get_the_ID(), 'newspress-thumb' ) . '</a>';
            echo '<div class="np-widget-grid-body">';
            newspress_category_badge();
            echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
            echo '<div class="np-meta">' . newspress_get_posted_on_html() . '</div>';
            echo '</div></article>';
        }
        echo '</div>';
        wp_reset_postdata();
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 6;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <?php newspress_widget_category_dropdown( $this, $instance ); ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="12" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title'    => sanitize_text_field( $new_instance['title'] ?? '' ),
            'category' => absint( $new_instance['category'] ?? 0 ),
            'count'    => min( 12, max( 1, absint( $new_instance['count'] ?? 6 ) ) ),
        );
    }
}

class NewsPress_Social_Follow_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_social_follow', __( 'NP Social Follow', 'newspress' ), array(
            'description' => __( 'Display manual social media follow links.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        $links = newspress_social_follow_fields();
        $items = array();

        foreach ( $links as $key => $label ) {
            $url = isset( $instance[ $key ] ) ? trim( (string) $instance[ $key ] ) : '';
            if ( $url ) {
                $items[ $key ] = array( 'label' => $label, 'url' => $url );
            }
        }

        if ( empty( $items ) ) {
            return;
        }

        echo $args['before_widget'];
        if ( '' !== $title ) {
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        }
        echo '<nav class="np-social-follow" aria-label="' . esc_attr__( 'Follow us', 'newspress' ) . '">';
        foreach ( $items as $key => $item ) {
            echo '<a class="np-social-follow-link np-social-' . esc_attr( $key ) . '" href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener noreferrer">' . newspress_svg_icon( $key, 18 ) . '<span>' . esc_html( $item['label'] ) . '</span></a>';
        }
        echo '</nav>';
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <?php foreach ( newspress_social_follow_fields() as $key => $label ) : ?>
            <p><label for="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>"><?php echo esc_html( $label ); ?> URL:</label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" type="url" value="<?php echo esc_url( $instance[ $key ] ?? '' ); ?>"></p>
        <?php endforeach;
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array( 'title' => sanitize_text_field( $new_instance['title'] ?? '' ) );
        foreach ( newspress_social_follow_fields() as $key => $label ) {
            $instance[ $key ] = isset( $new_instance[ $key ] ) ? esc_url_raw( $new_instance[ $key ] ) : '';
        }
        return $instance;
    }
}

function newspress_social_follow_fields() {
    return array(
        'facebook'  => 'Facebook',
        'instagram' => 'Instagram',
        'x'         => 'X / Twitter',
        'threads'   => 'Threads',
        'bluesky'   => 'Bluesky',
        'tiktok'    => 'TikTok',
        'youtube'   => 'YouTube',
        'linkedin'  => 'LinkedIn',
        'telegram'  => 'Telegram',
        'whatsapp'  => 'WhatsApp',
        'line'      => 'Line',
        'pinterest' => 'Pinterest',
    );
}

class NewsPress_Author_List_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_author_list', __( 'NP Author List', 'newspress' ), array(
            'description' => __( 'Display authors with avatar and total articles.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        $count = ! empty( $instance['count'] ) ? min( 20, max( 1, absint( $instance['count'] ) ) ) : 6;
        $users = get_users( array(
            'who'     => 'authors',
            'number'  => $count,
            'orderby' => 'post_count',
            'order'   => 'DESC',
            'fields'  => array( 'ID', 'display_name', 'user_url' ),
        ) );

        if ( empty( $users ) ) {
            return;
        }

        echo $args['before_widget'];
        if ( '' !== $title ) {
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        }
        echo '<div class="np-author-list-widget">';
        foreach ( $users as $user ) {
            $total = count_user_posts( $user->ID, 'post', true );
            if ( $total < 1 ) {
                continue;
            }
            echo '<a class="np-author-list-item" href="' . esc_url( get_author_posts_url( $user->ID ) ) . '">';
            echo '<span class="np-author-list-avatar">' . get_avatar( $user->ID, 56 ) . '</span>';
            echo '<span class="np-author-list-body"><strong>' . esc_html( $user->display_name ) . '</strong><span>' . sprintf( esc_html( _n( '%s article', '%s articles', $total, 'newspress' ) ), number_format_i18n( $total ) ) . '</span></span>';
            echo '</a>';
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 6;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of authors:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="20" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title' => sanitize_text_field( $new_instance['title'] ?? '' ),
            'count' => min( 20, max( 1, absint( $new_instance['count'] ?? 6 ) ) ),
        );
    }
}

class NewsPress_Recent_Comments_Preview_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'newspress_recent_comments_preview', __( 'NP Recent Comments', 'newspress' ), array(
            'description' => __( 'Display recent comments with article preview.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = isset( $instance['title'] ) ? trim( (string) $instance['title'] ) : '';
        $count = ! empty( $instance['count'] ) ? min( 10, max( 1, absint( $instance['count'] ) ) ) : 5;
        $comments = get_comments( array(
            'number'      => min( 50, max( $count * 4, $count ) ),
            'status'      => 'approve',
            'post_status' => 'publish',
            'type'        => 'comment',
        ) );

        if ( empty( $comments ) ) {
            return;
        }

        echo $args['before_widget'];
        if ( '' !== $title ) {
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        }
        echo '<div class="np-comment-preview-list">';
        $shown_posts = array();
        $shown_count = 0;
        foreach ( $comments as $comment ) {
            $post = get_post( $comment->comment_post_ID );
            if ( ! $post || 'publish' !== $post->post_status || isset( $shown_posts[ $post->ID ] ) ) {
                continue;
            }
            $shown_posts[ $post->ID ] = true;
            $shown_count++;
            $cat = get_the_category( $post->ID );
            $cat_name = ! empty( $cat ) ? $cat[0]->name : '';
            $comment_text = wp_trim_words( wp_strip_all_tags( $comment->comment_content ), 22, '...' );
            if ( function_exists( 'mb_strimwidth' ) ) {
                $comment_text = mb_strimwidth( wp_strip_all_tags( $comment->comment_content ), 0, 140, '...' );
            }
            echo '<article class="np-comment-preview-item">';
            echo '<a class="np-comment-preview-post" href="' . esc_url( get_comment_link( $comment ) ) . '">';
            echo '<span class="np-comment-preview-img">' . newspress_thumbnail_html( $post->ID, 'newspress-thumb' ) . '</span>';
            echo '<span class="np-comment-preview-postbody"><strong>' . esc_html( get_the_title( $post ) ) . '</strong><span>' . ( $cat_name ? esc_html( $cat_name ) . ' · ' : '' ) . esc_html( newspress_get_post_date_text( $post->ID ) ) . '</span></span>';
            echo '</a>';
            echo '<div class="np-comment-preview-comment"><strong>' . esc_html( get_comment_author( $comment ) ) . '</strong><p>' . esc_html( $comment_text ) . '</p></div>';
            echo '</article>';
            if ( $shown_count >= $count ) {
                break;
            }
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        ?>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'newspress' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>"></p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of comments:', 'newspress' ); ?></label>
        <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" max="10" value="<?php echo esc_attr( $count ); ?>"></p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        return array(
            'title' => sanitize_text_field( $new_instance['title'] ?? '' ),
            'count' => min( 10, max( 1, absint( $new_instance['count'] ?? 5 ) ) ),
        );
    }
}


/** Backward compatibility with older package widget name. */
class NewsPress_Post_List_Widget extends NewsPress_Popular_Posts_Widget {}

function newspress_register_custom_widgets() {
    register_widget( 'NewsPress_Popular_Posts_Widget' );
    register_widget( 'NewsPress_Recent_Posts_Widget' );
    register_widget( 'NewsPress_Hero_Grid_Widget' );
    register_widget( 'NewsPress_Recent_First_Big_Widget' );
    register_widget( 'NewsPress_Recent_Grid_Widget' );
    register_widget( 'NewsPress_Random_List_Widget' );
    register_widget( 'NewsPress_Random_Grid_Widget' );
    register_widget( 'NewsPress_Recent_Slider_Widget' );
    register_widget( 'NewsPress_Social_Follow_Widget' );
    register_widget( 'NewsPress_Author_List_Widget' );
    register_widget( 'NewsPress_Recent_Comments_Preview_Widget' );
}
add_action( 'widgets_init', 'newspress_register_custom_widgets' );

function newspress_seed_default_hero_grid_widget() {
    $seed_key = 'newspress_seeded_hero_grid_widget_1212';
    if ( get_option( $seed_key ) ) {
        return;
    }

    $sidebars = wp_get_sidebars_widgets();
    if ( ! empty( $sidebars['home-hero-grid'] ) ) {
        update_option( $seed_key, 1 );
        return;
    }

    $option_name = 'widget_newspress_hero_grid';
    $widgets     = get_option( $option_name, array() );
    if ( ! is_array( $widgets ) ) {
        $widgets = array();
    }

    $next_id = 2;
    foreach ( array_keys( $widgets ) as $id ) {
        if ( is_numeric( $id ) ) {
            $next_id = max( $next_id, absint( $id ) + 1 );
        }
    }

    $widgets[ $next_id ] = array(
        'title'        => '',
        'source'       => 'latest',
        'category'     => 0,
        'count'        => 3,
        'show_excerpt' => 1,
    );
    $widgets['_multiwidget'] = 1;

    $sidebars['home-hero-grid'] = array( 'newspress_hero_grid-' . $next_id );

    update_option( $option_name, $widgets );
    wp_set_sidebars_widgets( $sidebars );
    update_option( $seed_key, 1 );
}
add_action( 'widgets_init', 'newspress_seed_default_hero_grid_widget', 30 );


function newspress_seed_default_popular_widgets() {
    $seed_key = 'newspress_seeded_popular_widgets_1218';
    if ( get_option( $seed_key ) ) {
        return;
    }

    $sidebars = wp_get_sidebars_widgets();
    $option_name = 'widget_newspress_popular_posts';
    $widgets = get_option( $option_name, array() );
    if ( ! is_array( $widgets ) ) {
        $widgets = array();
    }

    $next_id = 2;
    foreach ( array_keys( $widgets ) as $id ) {
        if ( is_numeric( $id ) ) {
            $next_id = max( $next_id, absint( $id ) + 1 );
        }
    }

    $targets = array(
        'home-popular'    => __( 'Popular This Week', 'newspress' ),
        'sidebar-popular' => __( 'Popular This Week', 'newspress' ),
    );

    foreach ( $targets as $sidebar_id => $title ) {
        if ( ! empty( $sidebars[ $sidebar_id ] ) ) {
            continue;
        }
        $widgets[ $next_id ] = array(
            'title' => $title,
            'range' => 'week',
            'count' => 5,
        );
        $sidebars[ $sidebar_id ] = array( 'newspress_popular_posts-' . $next_id );
        $next_id++;
    }

    $widgets['_multiwidget'] = 1;
    update_option( $option_name, $widgets );
    wp_set_sidebars_widgets( $sidebars );
    update_option( $seed_key, 1 );
}
add_action( 'widgets_init', 'newspress_seed_default_popular_widgets', 31 );
