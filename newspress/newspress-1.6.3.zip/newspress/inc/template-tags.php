<?php
/** Template helper functions. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_get_date_format() {
    $format = trim( (string) get_theme_mod( 'newspress_single_date_format', 'l, d F Y | H:i \\W\\I\\B' ) );
    return '' !== $format ? $format : 'l, d F Y | H:i \\W\\I\\B';
}

function newspress_get_date_display_mode() {
    $mode = get_theme_mod( 'newspress_date_display_mode', 'format' );
    return in_array( $mode, array( 'format', 'ago' ), true ) ? $mode : 'format';
}

function newspress_format_datetime( $timestamp ) {
    $timestamp = absint( $timestamp );
    if ( ! $timestamp ) {
        return '';
    }

    if ( 'ago' === newspress_get_date_display_mode() ) {
        return sprintf(
            /* translators: %s: human readable time difference. */
            __( '%s ago', 'newspress' ),
            human_time_diff( $timestamp, current_time( 'timestamp' ) )
        );
    }

    return date_i18n( newspress_get_date_format(), $timestamp );
}

function newspress_get_post_date_text( $post_id = null, $type = 'published' ) {
    $post_id   = $post_id ? absint( $post_id ) : get_the_ID();
    $timestamp = 'modified' === $type ? get_post_modified_time( 'U', false, $post_id ) : get_post_time( 'U', false, $post_id );

    return newspress_format_datetime( $timestamp );
}

function newspress_posted_on( $context = 'archive' ) {
    $timestamp = get_the_time( 'U' );
    $display   = newspress_format_datetime( $timestamp );
    $class     = 'single' === $context && get_theme_mod( 'newspress_show_single_updated_date', 0 ) ? 'entry-date published' : 'entry-date published updated';

    printf(
        '<span class="posted-on"><time class="%1$s" datetime="%2$s">%3$s</time></span>',
        esc_attr( $class ),
        esc_attr( get_the_date( DATE_W3C ) ),
        esc_html( $display )
    );
}

function newspress_updated_on() {
    $published = absint( get_the_time( 'U' ) );
    $updated   = absint( get_the_modified_time( 'U' ) );

    if ( ! $updated || $updated <= $published + MINUTE_IN_SECONDS ) {
        return;
    }

    printf(
        '<span class="updated-on"><span class="np-meta-label">%1$s</span> <time class="updated" datetime="%2$s">%3$s</time></span>',
        esc_html__( 'Update', 'newspress' ),
        esc_attr( get_the_modified_date( DATE_W3C ) ),
        esc_html( newspress_format_datetime( $updated ) )
    );
}

function newspress_single_entry_meta() {
    $items = array();

    ob_start();
    newspress_posted_by();
    $items[] = ob_get_clean();

    if ( get_theme_mod( 'newspress_show_single_published_date', 1 ) ) {
        ob_start();
        newspress_posted_on( 'single' );
        $published_html = ob_get_clean();
        if ( $published_html ) {
            $items[] = $published_html;
        }
    }

    if ( get_theme_mod( 'newspress_show_single_updated_date', 0 ) ) {
        ob_start();
        newspress_updated_on();
        $updated_html = ob_get_clean();
        if ( $updated_html ) {
            $items[] = $updated_html;
        }
    }

    $items[] = esc_html( newspress_reading_time() );

    $views_html = newspress_get_post_views_html();
    if ( $views_html ) {
        $items[] = $views_html;
    }

    echo implode( ' <span class="np-meta-sep">/</span> ', array_filter( $items ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_posted_by() {
    printf(
        '<span class="byline"><span class="np-meta-label">%s</span> <a class="url fn n" href="%s">%s</a></span>',
        esc_html__( 'Penulis', 'newspress' ),
        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
        esc_html( get_the_author() )
    );
}

function newspress_reading_time( $post_id = null ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    $content = wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $post_id ) ) );

    if ( function_exists( 'mb_strlen' ) ) {
        preg_match_all( '/[\p{L}\p{N}]+/u', $content, $matches );
        $words = ! empty( $matches[0] ) ? count( $matches[0] ) : 0;
    } else {
        $words = str_word_count( $content );
    }

    $minutes = max( 1, (int) ceil( $words / 250 ) );
    return sprintf( _n( '%s min read', '%s min read', $minutes, 'newspress' ), number_format_i18n( $minutes ) );
}

function newspress_get_post_views_count( $post_id = null, $range = 'all' ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return 0;
    }

    $range = sanitize_key( $range );
    $key   = '_newspress_views_total';

    if ( function_exists( 'newspress_views_keys' ) ) {
        $keys = newspress_views_keys();
        if ( isset( $keys[ $range ] ) ) {
            $key = $keys[ $range ];
        }
    }

    return max( 0, absint( get_post_meta( $post_id, $key, true ) ) );
}

function newspress_get_post_shares_count( $post_id = null ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return 0;
    }

    return max( 0, absint( get_post_meta( $post_id, '_newspress_shares_total', true ) ) );
}

function newspress_get_post_views_html( $post_id = null ) {
    if ( ! get_theme_mod( 'newspress_show_single_views', 1 ) ) {
        return '';
    }

    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $views = newspress_get_post_views_count( $post_id, 'all' );
    $label = trim( (string) get_theme_mod( 'newspress_single_views_label', __( 'Dilihat', 'newspress' ) ) );
    $label = '' !== $label ? $label : __( 'Dilihat', 'newspress' );

    return sprintf(
        '<span class="np-post-views"><span class="np-post-views-count">%1$s</span> <span class="np-post-views-label">%2$s</span></span>',
        esc_html( number_format_i18n( $views ) ),
        esc_html( $label )
    );
}

function newspress_post_views() {
    echo newspress_get_post_views_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_excerpt( $words = 20 ) {
    return esc_html( wp_trim_words( get_the_excerpt(), $words, '...' ) );
}

function newspress_card_context() {
    $context = get_query_var( 'newspress_card_context' );
    $context = is_string( $context ) ? sanitize_key( $context ) : 'latest';
    return in_array( $context, array( 'latest', 'related', 'archive' ), true ) ? $context : 'latest';
}

function newspress_card_context_key( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    return 'related' === $context ? 'newspress_related_' : 'newspress_home_latest_';
}

function newspress_card_layout( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    $default = 'related' === $context ? 'grid' : 'list';
    $layout  = get_theme_mod( newspress_card_context_key( $context ) . 'layout', $default );
    return in_array( $layout, array( 'list', 'grid' ), true ) ? $layout : $default;
}

function newspress_card_show( $part, $context = '' ) {
    $part = sanitize_key( $part );
    if ( ! in_array( $part, array( 'thumb', 'snippet', 'meta', 'category' ), true ) ) {
        return true;
    }
    return (bool) get_theme_mod( newspress_card_context_key( $context ) . 'show_' . $part, 1 );
}

function newspress_card_container_classes( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    $classes = array(
        'np-card-list',
        'np-card-context-' . $context,
        'np-card-layout-' . newspress_card_layout( $context ),
    );
    foreach ( array( 'thumb', 'snippet', 'meta', 'category' ) as $part ) {
        $classes[] = newspress_card_show( $part, $context ) ? 'has-' . $part : 'hide-' . $part;
    }
    return implode( ' ', array_map( 'sanitize_html_class', $classes ) );
}

function newspress_get_trending_terms( $limit = 7, $taxonomy = '', $range = '' ) {
    $limit    = min( 20, max( 1, absint( $limit ) ) );
    $taxonomy = in_array( $taxonomy, array( 'post_tag', 'category' ), true ) ? $taxonomy : get_theme_mod( 'newspress_trending_source', 'post_tag' );
    $taxonomy = in_array( $taxonomy, array( 'post_tag', 'category' ), true ) ? $taxonomy : 'post_tag';
    $range    = in_array( $range, array( 'all', 'today', '7days', '30days' ), true ) ? $range : get_theme_mod( 'newspress_trending_range', '7days' );
    $range    = in_array( $range, array( 'all', 'today', '7days', '30days' ), true ) ? $range : '7days';
    $cache_key = 'newspress_trending_' . sanitize_key( $taxonomy ) . '_' . sanitize_key( $range ) . '_' . $limit;
    $terms = get_transient( $cache_key );

    if ( false !== $terms ) {
        return is_array( $terms ) ? $terms : array();
    }

    if ( 'all' === $range ) {
        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'number'     => $limit,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'hide_empty' => true,
        ) );
        $terms = is_wp_error( $terms ) ? array() : $terms;
        set_transient( $cache_key, $terms, 30 * MINUTE_IN_SECONDS );
        return $terms;
    }

    $after = 'today' === $range ? '1 day ago' : ( '30days' === $range ? '30 days ago' : '7 days ago' );
    $query = new WP_Query( array(
        'post_type'              => 'post',
        'post_status'            => 'publish',
        'posts_per_page'         => 200,
        'fields'                 => 'ids',
        'ignore_sticky_posts'    => true,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'date_query'             => array(
            array(
                'after'     => $after,
                'inclusive' => true,
            ),
        ),
    ) );

    $term_counts = array();
    foreach ( $query->posts as $post_id ) {
        $post_terms = wp_get_post_terms( $post_id, $taxonomy );
        if ( is_wp_error( $post_terms ) || empty( $post_terms ) ) {
            continue;
        }
        foreach ( $post_terms as $term ) {
            $term_id = absint( $term->term_id );
            if ( ! isset( $term_counts[ $term_id ] ) ) {
                $term_counts[ $term_id ] = array( 'term' => $term, 'count' => 0 );
            }
            $term_counts[ $term_id ]['count']++;
        }
    }

    uasort( $term_counts, function( $a, $b ) {
        if ( $a['count'] === $b['count'] ) {
            return strcasecmp( $a['term']->name, $b['term']->name );
        }
        return $b['count'] <=> $a['count'];
    } );

    $terms = array_map( function( $item ) {
        return $item['term'];
    }, array_slice( $term_counts, 0, $limit ) );

    if ( empty( $terms ) ) {
        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'number'     => $limit,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'hide_empty' => true,
        ) );
        $terms = is_wp_error( $terms ) ? array() : $terms;
    }

    set_transient( $cache_key, $terms, 30 * MINUTE_IN_SECONDS );
    return is_array( $terms ) ? $terms : array();
}

function newspress_get_trending_tags( $limit = 5 ) {
    return newspress_get_trending_terms( $limit, 'post_tag' );
}

function newspress_flush_trending_tags_cache() {
    for ( $i = 1; $i <= 20; $i++ ) {
        delete_transient( 'newspress_trending_tags_' . $i );
        foreach ( array( 'post_tag', 'category' ) as $taxonomy ) {
            foreach ( array( 'all', 'today', '7days', '30days' ) as $range ) {
                delete_transient( 'newspress_trending_' . $taxonomy . '_' . $range . '_' . $i );
            }
        }
    }
}
add_action( 'created_term', 'newspress_flush_trending_tags_cache' );
add_action( 'edited_term', 'newspress_flush_trending_tags_cache' );
add_action( 'delete_term', 'newspress_flush_trending_tags_cache' );
add_action( 'save_post_post', 'newspress_flush_trending_tags_cache' );
add_action( 'trashed_post', 'newspress_flush_trending_tags_cache' );
add_action( 'deleted_post', 'newspress_flush_trending_tags_cache' );

function newspress_flush_author_post_count_cache( $post_id ) {
    $post = get_post( $post_id );
    if ( $post && ! empty( $post->post_author ) ) {
        delete_transient( 'newspress_author_posts_' . absint( $post->post_author ) );
    }
}
add_action( 'save_post_post', 'newspress_flush_author_post_count_cache' );
add_action( 'trashed_post', 'newspress_flush_author_post_count_cache' );
add_action( 'deleted_post', 'newspress_flush_author_post_count_cache' );

function newspress_thumbnail( $size = 'newspress-card', $class = '', $attr = array() ) {
    if ( has_post_thumbnail() ) {
        $defaults = array(
            'class'    => trim( 'np-img ' . $class ),
            'loading'  => 'lazy',
            'decoding' => 'async',
        );
        $attr = wp_parse_args( $attr, $defaults );
        $attr['class'] = esc_attr( $attr['class'] );
        the_post_thumbnail( $size, $attr );
    } else {
        echo '<div class="np-img np-img-placeholder ' . esc_attr( $class ) . '">' . esc_html__( 'No Image', 'newspress' ) . '</div>';
    }
}

function newspress_breadcrumbs() {
    if ( is_front_page() ) { return; }
    echo '<nav class="np-breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'newspress' ) . '</a>';
    if ( is_category() || is_single() ) {
        $cat = get_the_category();
        if ( ! empty( $cat ) ) {
            echo '<span>/</span><a href="' . esc_url( get_category_link( $cat[0]->term_id ) ) . '">' . esc_html( $cat[0]->name ) . '</a>';
        }
        // Intentionally hide the current article title to keep breadcrumbs compact.
    } elseif ( is_page() ) {
        echo '<span>/</span><span>' . esc_html( get_the_title() ) . '</span>';
    } elseif ( is_search() ) {
        echo '<span>/</span><span>' . esc_html__( 'Search', 'newspress' ) . '</span>';
    }
    echo '</nav>';
}

function newspress_ads_should_display() {
    return ! ( is_user_logged_in() && get_theme_mod( 'newspress_ad_hide_logged_in', 0 ) );
}

function newspress_ad_label_text() {
    $label = get_theme_mod( 'newspress_ad_label', __( 'Advertisement', 'newspress' ) );
    return $label ? $label : __( 'Advertisement', 'newspress' );
}

function newspress_ad_slot( $key ) {
    if ( ! newspress_ads_should_display() ) { return; }
    $html = trim( (string) get_theme_mod( 'newspress_ad_' . $key, '' ) );
    if ( '' === $html ) {
        return;
    }
    echo '<div class="np-ad np-ad-' . esc_attr( $key ) . '">' . newspress_get_safe_ad_code( $html ) . '</div>';
}

function newspress_get_article_ad_markup( $key, $widget_area, $dummy_label ) {
    if ( ! newspress_ads_should_display() ) { return ''; }
    if ( is_active_sidebar( $widget_area ) ) {
        ob_start();
        dynamic_sidebar( $widget_area );
        $widgets = trim( ob_get_clean() );
        if ( $widgets ) {
            return '<div class="np-article-ad-widget np-article-ad-' . esc_attr( $key ) . '">' . $widgets . '</div>';
        }
    }

    $html = trim( (string) get_theme_mod( 'newspress_ad_' . $key, '' ) );

    if ( ! $html && 'article_middle' === $key ) {
        $html = trim( (string) get_theme_mod( 'newspress_ad_inarticle', '' ) );
    }

    if ( $html ) {
        return '<div class="np-ad np-ad-inarticle np-ad-' . esc_attr( $key ) . '">' . newspress_get_safe_ad_code( $html ) . '</div>';
    }

    return '';
}

function newspress_insert_article_ads( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || is_preview() ) {
        return $content;
    }

    $before = newspress_get_article_ad_markup( 'article_before', 'article-ad-before', 'Advertisement before article' );
    $middle = newspress_get_article_ad_markup( 'article_middle', 'article-ad-middle', 'Advertisement' );
    $after  = newspress_get_article_ad_markup( 'article_after', 'article-ad-after', 'Advertisement after article' );

    if ( false === stripos( $content, '</p>' ) ) {
        return $before . $content . $middle . $after;
    }

    $paragraphs = explode( '</p>', $content );
    $rebuilt = array();
    $paragraph_count = 0;
    $middle_inserted = false;

    foreach ( $paragraphs as $paragraph ) {
        if ( '' === trim( $paragraph ) ) {
            continue;
        }
        $rebuilt[] = $paragraph . '</p>';
        $paragraph_count++;
    }

    if ( empty( $rebuilt ) ) {
        return $before . $content . $middle . $after;
    }

    $middle_at = max( 1, min( count( $rebuilt ), absint( get_theme_mod( 'newspress_ad_middle_paragraph', 4 ) ) ) );
    $output = $before;

    foreach ( $rebuilt as $index => $paragraph ) {
        $output .= $paragraph;
        if ( ! $middle_inserted && ( $index + 1 ) === $middle_at ) {
            $output .= $middle;
            $middle_inserted = true;
        }
    }

    $output .= $after;

    return $output;
}

function newspress_slugify_heading_id( $text, $fallback ) {
    $slug = sanitize_title( wp_strip_all_tags( $text ) );
    return $slug ? $slug : 'section-' . absint( $fallback );
}

function newspress_add_table_of_contents( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( defined( 'NEWSPRESS_DISABLE_TOC_KEY' ) && get_post_meta( get_the_ID(), NEWSPRESS_DISABLE_TOC_KEY, true ) ) {
        return $content;
    }
    if ( ! preg_match_all( '/<h([2-6])([^>]*)>(.*?)<\/h\1>/is', $content, $matches, PREG_SET_ORDER ) || count( $matches ) < 2 ) {
        return $content;
    }

    $items    = array();
    $used_ids = array();
    $counts   = array( 2 => 0, 3 => 0, 4 => 0, 5 => 0 );
    $i        = 0;

    $content = preg_replace_callback( '/<h([2-6])([^>]*)>(.*?)<\/h\1>/is', function( $m ) use ( &$items, &$used_ids, &$counts, &$i ) {
        $i++;
        $level = absint( $m[1] );
        $attrs = $m[2];
        $inner = $m[3];
        $text  = trim( wp_strip_all_tags( $inner ) );

        if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $attrs, $id_match ) ) {
            $id = sanitize_title( $id_match[1] );
        } else {
            $id   = newspress_slugify_heading_id( $text, $i );
            $base = $id;
            $n    = 2;
            while ( in_array( $id, $used_ids, true ) ) {
                $id = $base . '-' . $n;
                $n++;
            }
            $attrs .= ' id="' . esc_attr( $id ) . '"';
        }

        $used_ids[] = $id;

        if ( $level >= 2 && $level <= 5 ) {
            for ( $parent = 2; $parent < $level; $parent++ ) {
                if ( empty( $counts[ $parent ] ) ) {
                    $counts[ $parent ] = 1;
                }
            }
            $counts[ $level ]++;
            for ( $child = $level + 1; $child <= 5; $child++ ) {
                $counts[ $child ] = 0;
            }
            $parts = array();
            for ( $n_level = 2; $n_level <= $level; $n_level++ ) {
                if ( ! empty( $counts[ $n_level ] ) ) {
                    $parts[] = $counts[ $n_level ];
                }
            }
            $marker = implode( '.', $parts ) . '.';
        } else {
            $marker = '-';
        }

        $items[] = array(
            'id'     => $id,
            'text'   => $text,
            'level'  => $level,
            'marker' => $marker,
        );

        return '<h' . $level . $attrs . '>' . $inner . '</h' . $level . '>';
    }, $content );

    if ( count( $items ) < 2 ) {
        return $content;
    }

    $toc = '<nav class="np-toc" aria-label="' . esc_attr__( 'Table of contents', 'newspress' ) . '"><button class="np-toc-toggle" type="button" aria-expanded="true">' . esc_html__( 'Daftar Isi', 'newspress' ) . '</button><ol class="np-toc-list">';
    foreach ( $items as $item ) {
        $toc .= '<li class="np-toc-level-' . absint( $item['level'] ) . '"><a href="#' . esc_attr( $item['id'] ) . '"><span class="np-toc-marker" aria-hidden="true">' . esc_html( $item['marker'] ) . '</span><span class="np-toc-text">' . esc_html( $item['text'] ) . '</span></a></li>';
    }
    $toc .= '</ol></nav>';

    return $toc . $content;
}

function newspress_svg_icon( $name, $size = 20 ) {
    $size = absint( $size );
    $icons = array(
        'search'   => '<path d="M9.5 3a6.5 6.5 0 0 1 5.17 10.45l4.44 4.44-1.42 1.42-4.44-4.44A6.5 6.5 0 1 1 9.5 3m0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9Z"/>',
        'menu'     => '<path d="M3 6h18v2H3V6Zm0 5h18v2H3v-2Zm0 5h18v2H3v-2Z"/>',
        'facebook' => '<path d="M13.5 9H16l-.4 3h-2.1v8h-3.2v-8H8V9h2.3V7.1c0-2.6 1.5-4.1 3.9-4.1 1.1 0 2.2.2 2.2.2v2.7h-1.3c-1.3 0-1.6.8-1.6 1.6V9Z"/>',
        'x'        => '<path d="M16.8 3h3.1l-6.8 7.8 8 10.2h-6.3l-4.9-6.3L4.3 21H1.2l7.3-8.4L.8 3h6.5l4.4 5.7L16.8 3Zm-1.1 16.2h1.7L6.4 4.7H4.6l11.1 14.5Z"/>',
        'whatsapp' => '<path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.98L2.4 21.2l4.35-1.1A9.96 9.96 0 1 0 12.04 2Zm0 2a7.96 7.96 0 0 1 6.76 12.18 7.9 7.9 0 0 1-10.86 2.25l-.33-.2-2.58.66.68-2.48-.22-.35A7.96 7.96 0 0 1 12.04 4Zm-3.1 3.7c-.18 0-.48.07-.73.34-.25.27-.96.94-.96 2.3 0 1.35.98 2.65 1.12 2.83.14.18 1.9 3.03 4.72 4.12 2.34.92 2.82.74 3.33.69.51-.05 1.65-.67 1.88-1.32.23-.65.23-1.2.16-1.32-.07-.12-.25-.19-.53-.33-.28-.14-1.65-.82-1.9-.91-.26-.1-.45-.14-.64.14-.18.27-.73.91-.9 1.1-.16.18-.33.2-.6.06-.28-.14-1.18-.43-2.25-1.38-.83-.74-1.39-1.65-1.55-1.93-.16-.27-.02-.42.12-.56.13-.13.28-.33.42-.49.14-.16.18-.28.28-.47.09-.18.04-.35-.03-.49-.07-.14-.64-1.55-.88-2.12-.23-.55-.47-.47-.64-.48h-.54Z"/>',
        'link'     => '<path d="M3.9 12a5 5 0 0 1 5-5H12v2H8.9a3 3 0 1 0 0 6H12v2H8.9a5 5 0 0 1-5-5Zm5.1 1h6v-2H9v2Zm3-6h3.1a5 5 0 0 1 0 10H12v-2h3.1a3 3 0 1 0 0-6H12V7Z"/>',
        'share'    => '<path d="M18 16.1c-.76 0-1.44.3-1.96.77L8.91 12.7a3.3 3.3 0 0 0 0-1.39l7.05-4.11A3 3 0 1 0 15 5c0 .22.02.44.07.64L8.02 9.75a3 3 0 1 0 0 4.5l7.12 4.18c-.04.18-.06.37-.06.57a3 3 0 1 0 3-2.9Z"/>',
        'telegram' => '<path d="M20.6 4.2 17.7 19c-.2 1-.8 1.2-1.6.8l-4.4-3.2-2.1 2c-.24.24-.44.44-.9.44l.32-4.5 8.18-7.38c.36-.32-.08-.5-.55-.18L6.55 13.35 2.2 12c-.95-.3-.97-.95.2-1.4L19.4 4c.78-.3 1.47.18 1.2 1.2Z"/>',
        'line'     => '<path d="M12 3C6.48 3 2 6.65 2 11.15c0 4.03 3.58 7.4 8.42 8.04.33.07.78.22.89.5.1.25.07.64.03.9l-.15.86c-.04.25-.2.98.87.54 1.06-.45 5.75-3.38 7.85-5.8A7.16 7.16 0 0 0 22 11.15C22 6.65 17.52 3 12 3Zm-4.24 10.8H5.7V8.66h1.04v4.17h1.02v.97Zm2.03 0H8.75V8.66h1.04v5.14Zm5.2 0h-1.04l-2.38-3.2v3.2h-1.04V8.66h1.04l2.38 3.2v-3.2H15v5.14Zm3.28-4.17h-1.88v1h1.78v.97h-1.78v1.23h1.88v.97h-2.92V8.66h2.92v.97Z"/>',
        'linkedin' => '<path d="M4.98 3.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM3 9.5h4v11H3v-11Zm6 0h3.8v1.5h.05c.53-1 1.82-1.9 3.75-1.9 4 0 4.75 2.63 4.75 6.05v5.35h-4v-4.75c0-1.13-.02-2.58-1.57-2.58-1.58 0-1.82 1.23-1.82 2.5v4.83H9v-11Z"/>',
        'pinterest'=> '<path d="M12.2 2C6.65 2 3 5.86 3 10.2c0 2.7 1.52 4.22 2.44 4.22.38 0 .6-1.06.6-1.36 0-.36-.92-1.13-.92-2.63 0-3.12 2.37-5.33 5.44-5.33 2.64 0 4.6 1.5 4.6 4.26 0 2.06-.83 5.93-3.5 5.93-.96 0-1.78-.7-1.54-1.72.3-1.22.88-2.54.88-3.43 0-2.23-3.16-1.83-3.16 1.05 0 .6.2 1.26.2 1.26l-1.45 6.14c-.43 1.8-.06 4 .02 4.22.05.13.18.16.27.06.14-.18 1.94-2.4 2.55-4.14.17-.5.99-3.88.99-3.88.49.94 1.92 1.76 3.44 1.76 4.53 0 7.6-4.13 7.6-9.66C21.45 4.86 17.93 2 12.2 2Z"/>',
        'bluesky'  => '<path d="M6.5 4.2C8.7 5.85 11.07 9.2 12 11c.93-1.8 3.3-5.15 5.5-6.8 1.6-1.2 4.2-2.13 4.2.82 0 .59-.34 4.95-.54 5.66-.7 2.5-3.25 3.14-5.52 2.75 3.97.68 4.98 2.93 2.8 5.18-4.13 4.27-5.94-1.07-6.4-2.44l-.04-.12-.04.12c-.46 1.37-2.27 6.71-6.4 2.44-2.18-2.25-1.17-4.5 2.8-5.18-2.27.39-4.82-.25-5.52-2.75-.2-.71-.54-5.07-.54-5.66 0-2.95 2.6-2.02 4.2-.82Z"/>',
        'threads'  => '<path d="M12.2 2C6.55 2 3.2 5.62 3.2 12.02c0 6.33 3.31 9.98 8.98 9.98 5.1 0 8.22-2.73 8.22-7.1 0-3.22-1.85-5.13-4.99-5.8-.42-2.05-1.77-3.08-3.94-3.08-1.62 0-2.9.56-3.77 1.66l1.48 1.3c.57-.66 1.25-.98 2.14-.98 1.02 0 1.7.44 2.02 1.32-.36-.02-.73-.03-1.1-.03-3.28 0-5.28 1.54-5.28 4.03 0 2.32 1.82 3.82 4.48 3.82 2.77 0 4.5-1.58 4.5-4.1v-.12c1.56.6 2.35 1.7 2.35 3.16 0 2.48-2.13 4.04-5.56 4.04-4.32 0-6.78-2.85-6.78-7.9 0-5.12 2.5-7.93 6.78-7.93 2.27 0 4.02.8 5.28 2.42l1.7-1.43C18.06 3.1 15.55 2 12.2 2Zm.06 9.12c.48 0 .93.03 1.35.09v.26c0 1.36-.84 2.08-2.16 2.08-1.11 0-1.8-.48-1.8-1.26 0-.76.86-1.17 2.61-1.17Z"/>',
        'instagram'=> '<path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7Zm5 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm5.25-3.1a.85.85 0 1 1 0 1.7.85.85 0 0 1 0-1.7Z"/>',
        'tiktok'   => '<path d="M15 3c.32 2.23 1.6 3.55 3.75 3.86v3.1A7.15 7.15 0 0 1 15 8.9v6.55A5.55 5.55 0 1 1 9.45 9.9c.34 0 .68.03 1 .1v3.23a2.48 2.48 0 1 0 1.55 2.3V3h3Z"/>',
        'youtube'  => '<path d="M21.58 7.19a2.5 2.5 0 0 0-1.76-1.77C18.27 5 12 5 12 5s-6.27 0-7.82.42A2.5 2.5 0 0 0 2.42 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .42 4.81 2.5 2.5 0 0 0 1.76 1.77C5.73 19 12 19 12 19s6.27 0 7.82-.42a2.5 2.5 0 0 0 1.76-1.77A26 26 0 0 0 22 12a26 26 0 0 0-.42-4.81ZM10 15V9l5.2 3L10 15Z"/>',
        'chevron-left' => '<path d="M15.4 7.4 14 6l-6 6 6 6 1.4-1.4L10.8 12l4.6-4.6Z"/>',
        'chevron-right'=> '<path d="m8.6 16.6 1.4 1.4 6-6-6-6-1.4 1.4 4.6 4.6-4.6 4.6Z"/>',
        'schedule' => '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 10.2V7h-2v6l5 3 .95-1.6L13 12.2Z"/>',
        'dark-mode' => '<path d="M21.64 13a1 1 0 0 0-1.05-.14 8.05 8.05 0 0 1-3.37.73 8.15 8.15 0 0 1-8.14-8.14c0-1.18.25-2.32.73-3.37A1 1 0 0 0 8.5.77 10.15 10.15 0 1 0 23 15.5a1 1 0 0 0-1.36-2.5ZM12.85 20A8.15 8.15 0 0 1 6.9 6.27a10.16 10.16 0 0 0 10.83 10.83A8.1 8.1 0 0 1 12.85 20Z"/>',
        'light-mode' => '<path d="M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Zm0-2a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM11 1h2v3h-2V1Zm0 19h2v3h-2v-3ZM3.51 4.93l1.42-1.42 2.12 2.13-1.41 1.41-2.13-2.12Zm13.44 13.43 1.41-1.41 2.13 2.12-1.42 1.42-2.12-2.13ZM1 11h3v2H1v-2Zm19 0h3v2h-3v-2ZM3.51 19.07l2.13-2.12 1.41 1.41-2.12 2.13-1.42-1.42ZM16.95 5.64l2.12-2.13 1.42 1.42-2.13 2.12-1.41-1.41Z"/>',
    );
    $path = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['search'];
    return '<svg class="np-icon np-icon-' . esc_attr( $name ) . '" width="' . esc_attr( $size ) . '" height="' . esc_attr( $size ) . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor">' . $path . '</svg>';
}

function newspress_share_button_enabled( $key ) {
    $defaults = array(
        'native' => 1, 'copy' => 1, 'facebook' => 1, 'x' => 1, 'whatsapp' => 1, 'telegram' => 1, 'line' => 1,
        'bluesky' => 0, 'instagram' => 0, 'linkedin' => 0, 'pinterest' => 0, 'tiktok' => 0, 'threads' => 0,
    );
    $key = sanitize_key( $key );
    $default = isset( $defaults[ $key ] ) ? $defaults[ $key ] : 0;
    return (bool) get_theme_mod( 'newspress_share_' . $key, $default );
}

function newspress_get_share_count_html( $post_id = null ) {
    if ( ! get_theme_mod( 'newspress_show_share_count', 1 ) ) {
        return '';
    }

    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $shares = newspress_get_post_shares_count( $post_id );

    return sprintf(
        '<span class="np-share-total" data-np-share-count-wrap><span class="np-share-total-count" data-np-share-count>%1$s</span> <span class="np-share-total-label">%2$s</span></span>',
        esc_html( number_format_i18n( $shares ) ),
        esc_html__( 'Share', 'newspress' )
    );
}

function newspress_share_buttons() {
    $raw_url   = get_permalink();
    $raw_title = get_the_title();
    $url       = rawurlencode( $raw_url );
    $title     = rawurlencode( $raw_title );
    $image     = has_post_thumbnail() ? rawurlencode( get_the_post_thumbnail_url( get_the_ID(), 'large' ) ) : '';

    $links = array(
        'bluesky'   => array( 'label' => 'Bluesky', 'href' => 'https://bsky.app/intent/compose?text=' . $title . '%20' . $url ),
        'facebook'  => array( 'label' => 'Facebook', 'href' => 'https://www.facebook.com/sharer/sharer.php?u=' . $url ),
        'instagram' => array( 'label' => 'Instagram', 'href' => 'https://www.instagram.com/' ),
        'line'      => array( 'label' => 'Line', 'href' => 'https://social-plugins.line.me/lineit/share?url=' . $url ),
        'linkedin'  => array( 'label' => 'LinkedIn', 'href' => 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url ),
        'pinterest' => array( 'label' => 'Pinterest', 'href' => 'https://pinterest.com/pin/create/button/?url=' . $url . ( $image ? '&media=' . $image : '' ) . '&description=' . $title ),
        'telegram'  => array( 'label' => 'Telegram', 'href' => 'https://t.me/share/url?url=' . $url . '&text=' . $title ),
        'tiktok'    => array( 'label' => 'TikTok', 'href' => 'https://www.tiktok.com/' ),
        'threads'   => array( 'label' => 'Threads', 'href' => 'https://www.threads.net/intent/post?text=' . $title . '%20' . $url ),
        'whatsapp'  => array( 'label' => 'WhatsApp', 'href' => 'https://api.whatsapp.com/send?text=' . $title . '%20' . $url ),
        'x'         => array( 'label' => 'X', 'href' => 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title ),
    );

    echo '<div class="np-share" aria-label="' . esc_attr__( 'Share this article', 'newspress' ) . '">';
    $share_count_html = newspress_get_share_count_html();
    echo '<span class="np-share-label">';
    if ( $share_count_html ) {
        echo $share_count_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else {
        echo esc_html__( 'Share', 'newspress' );
    }
    echo '</span>';

    if ( newspress_share_button_enabled( 'native' ) ) {
        echo '<button type="button" class="np-share-btn np-share-native" data-np-share-track="native" data-np-web-share aria-label="' . esc_attr__( 'Share with device', 'newspress' ) . '">' . newspress_svg_icon( 'share', 18 ) . '<span>' . esc_html__( 'Share', 'newspress' ) . '</span></button>';
    }
    if ( newspress_share_button_enabled( 'copy' ) ) {
        echo '<button type="button" class="np-share-btn np-share-copy" data-np-share-track="copy" data-copy-link="' . esc_url( $raw_url ) . '" aria-label="' . esc_attr__( 'Copy link', 'newspress' ) . '">' . newspress_svg_icon( 'link', 18 ) . '<span>' . esc_html__( 'Copy', 'newspress' ) . '</span></button>';
    }

    foreach ( $links as $icon => $data ) {
        if ( ! newspress_share_button_enabled( $icon ) || empty( $data['href'] ) || empty( $data['label'] ) ) {
            continue;
        }
        echo '<a class="np-share-btn np-share-' . esc_attr( $icon ) . '" target="_blank" rel="noopener noreferrer" data-np-share-track="' . esc_attr( $icon ) . '" href="' . esc_url( $data['href'] ) . '" aria-label="' . esc_attr( $data['label'] ) . '">' . newspress_svg_icon( $icon, 18 ) . '<span>' . esc_html( $data['label'] ) . '</span></a>';
    }
    echo '</div>';
}

function newspress_icon_search() {
    return newspress_svg_icon( 'search', 22 );
}

function newspress_mobile_sticky_ad() {
    if ( ! get_theme_mod( 'newspress_enable_mobile_sticky_ad', 0 ) || ! newspress_ads_should_display() ) {
        return;
    }
    $html = trim( (string) get_theme_mod( 'newspress_ad_mobile_sticky', '' ) );
    if ( '' === $html ) {
        return;
    }
    echo '<div class="np-mobile-sticky-ad"><button type="button" class="np-mobile-sticky-ad-close" aria-label="' . esc_attr__( 'Close advertisement', 'newspress' ) . '">×</button>' . newspress_get_safe_ad_code( $html ) . '</div>';
}
add_action( 'wp_footer', 'newspress_mobile_sticky_ad', 20 );

function newspress_get_safe_ad_code( $html ) {
    // Ad code is saved through Customizer by users with edit_theme_options.
    // Output it as stored so AdSense scripts are not stripped for logged-out visitors.
    return (string) $html;
}

/**
 * Print a compact linked primary category badge.
 */
function newspress_category_badge() {
    $categories = get_the_category();
    if ( empty( $categories ) || is_wp_error( $categories ) ) {
        return;
    }
    $category = $categories[0];
    echo '<a class="np-category-badge" href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>';
}


/**
 * Print previous/next post navigation with thumbnails.
 */
function newspress_post_navigation_with_thumbs() {
    $previous = get_previous_post();
    $next     = get_next_post();

    if ( ! $previous && ! $next ) {
        return;
    }

    echo '<nav class="navigation post-navigation np-post-navigation" aria-label="' . esc_attr__( 'Post navigation', 'newspress' ) . '">';
    echo '<div class="nav-links">';

    if ( $previous ) {
        $thumb = has_post_thumbnail( $previous->ID )
            ? get_the_post_thumbnail( $previous->ID, 'thumbnail', array( 'class' => 'np-post-nav-img', 'loading' => 'lazy', 'decoding' => 'async' ) )
            : '<span class="np-post-nav-placeholder">' . newspress_svg_icon( 'chevron-left', 22 ) . '</span>';

        echo '<div class="nav-previous"><a href="' . esc_url( get_permalink( $previous ) ) . '">';
        echo '<span class="np-post-nav-thumb">' . $thumb . '</span>';
        echo '<span class="np-post-nav-body"><span class="np-post-nav-label">' . esc_html__( 'Previous Article', 'newspress' ) . '</span><span class="np-post-nav-title">' . esc_html( get_the_title( $previous ) ) . '</span></span>';
        echo '</a></div>';
    }

    if ( $next ) {
        $thumb = has_post_thumbnail( $next->ID )
            ? get_the_post_thumbnail( $next->ID, 'thumbnail', array( 'class' => 'np-post-nav-img', 'loading' => 'lazy', 'decoding' => 'async' ) )
            : '<span class="np-post-nav-placeholder">' . newspress_svg_icon( 'chevron-right', 22 ) . '</span>';

        echo '<div class="nav-next"><a href="' . esc_url( get_permalink( $next ) ) . '">';
        echo '<span class="np-post-nav-body"><span class="np-post-nav-label">' . esc_html__( 'Next Article', 'newspress' ) . '</span><span class="np-post-nav-title">' . esc_html( get_the_title( $next ) ) . '</span></span>';
        echo '<span class="np-post-nav-thumb">' . $thumb . '</span>';
        echo '</a></div>';
    }

    echo '</div></nav>';
}
