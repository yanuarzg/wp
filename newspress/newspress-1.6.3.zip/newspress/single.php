<?php get_header(); ?>
<main id="primary" class="np-site-main np-container np-layout <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?>">
    <div class="np-content np-single-content">
        <?php while ( have_posts() ) : the_post(); ?>
            <?php newspress_breadcrumbs(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'np-article' ); ?>>
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                    <?php
                    $newspress_single_meta_description = defined( 'NEWSPRESS_META_DESCRIPTION_KEY' ) ? get_post_meta( get_the_ID(), NEWSPRESS_META_DESCRIPTION_KEY, true ) : '';
                    $newspress_show_meta_description   = defined( 'NEWSPRESS_SHOW_META_DESCRIPTION_KEY' ) ? get_post_meta( get_the_ID(), NEWSPRESS_SHOW_META_DESCRIPTION_KEY, true ) : '';
                    if ( $newspress_show_meta_description && $newspress_single_meta_description ) :
                        ?>
                        <p class="np-entry-description"><?php echo esc_html( newspress_sanitize_meta_description( $newspress_single_meta_description ) ); ?></p>
                    <?php endif; ?>
                    <div class="entry-meta"><?php newspress_single_entry_meta(); ?></div>
                </header>
                <?php if ( has_post_thumbnail() ) : ?>
                    <figure class="np-featured">
                        <?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'class' => 'np-featured-img' ) ); ?>
                        <?php
                        $newspress_featured_caption = wp_get_attachment_caption( get_post_thumbnail_id() );
                        if ( $newspress_featured_caption ) :
                            ?>
                            <figcaption class="np-featured-caption"><?php echo wp_kses_post( $newspress_featured_caption ); ?></figcaption>
                        <?php endif; ?>
                    </figure>
                <?php endif; ?>
                <div class="np-article-body-grid">
                    <aside class="np-share-rail" aria-label="<?php esc_attr_e( 'Share article', 'newspress' ); ?>">
                        <?php newspress_share_buttons(); ?>
                    </aside>
                    <div class="entry-content">
                        <?php
                        $newspress_content = apply_filters( 'the_content', get_the_content() );
                        if ( function_exists( 'newspress_add_table_of_contents' ) ) {
                            $newspress_content = newspress_add_table_of_contents( $newspress_content );
                        }
                        echo newspress_insert_article_ads( $newspress_content );
                        wp_link_pages();
                        ?>
                    </div>
                </div>
                <footer class="entry-footer">
                    <?php
                    $newspress_tags_class = get_theme_mod( 'newspress_tags_show_hash', 1 ) ? 'np-tags' : 'np-tags np-tags-no-hash';
                    the_tags( '<div class="' . esc_attr( $newspress_tags_class ) . '">', '', '</div>' );
                    ?>
                </footer>
            </article>
            <?php if ( ! defined( 'NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY' ) || ! get_post_meta( get_the_ID(), NEWSPRESS_HIDE_AUTHOR_PROFILE_KEY, true ) ) { get_template_part( 'template-parts/author-profile' ); } ?>
            <?php get_template_part( 'template-parts/related-posts' ); ?>
            <?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
            <?php newspress_post_navigation_with_thumbs(); ?>
        <?php endwhile; ?>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
