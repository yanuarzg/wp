<?php
/** Header template. */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>!function(){try{var d=document.documentElement,def='<?php echo esc_js( get_theme_mod( 'newspress_default_color_scheme', 'system' ) ); ?>',prev=localStorage.getItem('newspress-theme-default'),s=localStorage.getItem('newspress-theme'),m=window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches;if(prev!==def){localStorage.setItem('newspress-theme-default',def);localStorage.removeItem('newspress-theme');s=null;}var t=s||(def==='dark'?'dark':(def==='light'?'light':(m?'dark':'light')));d.setAttribute('data-theme',t);}catch(e){}}();</script>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="np-scroll-progress" aria-hidden="true"></div>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'newspress' ); ?></a>
<header class="np-site-header">
    <div class="np-mainbar np-container">
        <div class="np-brand">
            <?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?>
                <a class="np-site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
            <?php } ?>
            <div class="np-date" data-clock="<?php echo esc_attr( get_theme_mod( 'newspress_show_clock', 1 ) ); ?>">
                <?php echo esc_html( date_i18n( 'l, d F Y' ) ); ?>
            </div>
        </div>
        <button class="np-menu-toggle" type="button" aria-controls="site-navigation" aria-expanded="false">
            <?php echo newspress_svg_icon( 'menu', 22 ); ?>
            <span class="screen-reader-text"><?php esc_html_e( 'Menu', 'newspress' ); ?></span>
        </button>
        <nav id="site-navigation" class="np-nav" aria-label="<?php esc_attr_e( 'Primary Menu', 'newspress' ); ?>">
            <div class="np-nav-panel">
                <div class="np-mobile-nav-date np-date" data-clock="<?php echo esc_attr( get_theme_mod( 'newspress_show_clock', 1 ) ); ?>">
                    <?php echo esc_html( date_i18n( 'l, d F Y' ) ); ?>
                </div>
                <?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu', 'container' => false, 'fallback_cb' => 'wp_page_menu' ) ); ?>
            </div>
        </nav>
        <div class="np-nav-backdrop" aria-hidden="true"></div>
        <?php if ( get_theme_mod( 'newspress_enable_dark_toggle', 1 ) ) : ?>
            <button class="np-theme-toggle" type="button" data-default-theme="<?php echo esc_attr( get_theme_mod( 'newspress_default_color_scheme', 'system' ) ); ?>" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'newspress' ); ?>" aria-pressed="false"><?php echo newspress_svg_icon( 'dark-mode', 21 ); ?></button>
        <?php endif; ?>
        <button class="np-search-toggle" type="button" aria-label="<?php esc_attr_e( 'Open search', 'newspress' ); ?>" aria-expanded="false" aria-controls="np-search-panel"><?php echo newspress_icon_search(); ?></button>
    </div>
    <div id="np-search-panel" class="np-search-panel" hidden>
        <div class="np-container"><?php get_search_form(); ?></div>
    </div>
</header>
<?php get_template_part( 'template-parts/breaking-news' ); ?>
<?php
if ( function_exists( 'newspress_front_echo_widget_area' ) && is_active_sidebar( 'ad-leaderboard' ) ) {
    echo '<div class="np-ad-leaderboard np-ad-leaderboard-widget">';
    newspress_front_echo_widget_area( 'ad-leaderboard', __( 'Ad Leaderboard', 'newspress' ), 'np-ad-leaderboard-area' );
    echo '</div>';
} else {
    newspress_ad_slot( 'leaderboard' );
}
?>
