<?php /** Footer template. */ ?>
<footer class="np-footer">
    <div class="np-container np-footer-grid">
        <?php
        if ( function_exists( 'newspress_front_echo_widget_area' ) ) {
            newspress_front_echo_widget_area( 'footer-grid', __( 'Footer Grid', 'newspress' ), 'np-footer-grid-widget-area' );
        } elseif ( is_active_sidebar( 'footer-grid' ) ) {
            dynamic_sidebar( 'footer-grid' );
        }
        ?>
        <?php for ( $i = 1; $i <= 4; $i++ ) : ?>
            <?php if ( is_active_sidebar( 'footer-' . $i ) ) : ?>
                <div class="np-footer-column np-widget-area-footer-<?php echo absint( $i ); ?>">
                    <?php
                    if ( function_exists( 'newspress_front_echo_widget_area' ) ) {
                        newspress_front_echo_widget_area( 'footer-' . $i, sprintf( __( 'Footer Column %d', 'newspress' ), $i ) );
                    } elseif ( is_active_sidebar( 'footer-' . $i ) ) {
                        dynamic_sidebar( 'footer-' . $i );
                    }
                    ?>
                </div>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
    <div class="np-footer-bottom np-container">
        <?php $newspress_footer_custom = trim( (string) get_theme_mod( 'newspress_footer_bottom_custom', '' ) ); ?>
        <p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?><?php echo $newspress_footer_custom ? ' ' . wp_kses_post( $newspress_footer_custom ) : '.'; ?></p>
        <?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'fallback_cb' => false, 'depth' => 1 ) ); ?>
    </div>
</footer>
<button class="np-back-to-top" type="button" aria-label="<?php esc_attr_e( 'Back to top', 'newspress' ); ?>">↑</button>
<?php wp_footer(); ?>
</body>
</html>
