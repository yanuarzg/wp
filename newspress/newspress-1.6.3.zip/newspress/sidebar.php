<?php
/** Context-aware sidebar. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$sidebar_id    = 'sidebar-1';
$sidebar_label = __( 'Sidebar', 'newspress' );
$sidebar_class = 'np-sidebar-widget-area';

if ( is_singular( 'post' ) ) {
    $sidebar_id    = 'single-sidebar';
    $sidebar_label = __( 'Single post sidebar', 'newspress' );
    $sidebar_class = 'np-single-sidebar-widget-area';
} elseif ( is_front_page() || is_home() ) {
    $sidebar_id    = 'home-paged-sidebar';
    $sidebar_label = __( 'Blog paged sidebar', 'newspress' );
    $sidebar_class = 'np-home-paged-sidebar-widget-area';
}

if ( ! is_active_sidebar( $sidebar_id ) && ! is_customize_preview() ) {
    return;
}
?>
<aside class="np-sidebar" aria-label="<?php echo esc_attr( $sidebar_label ); ?>">
    <?php
    if ( function_exists( 'newspress_front_echo_widget_area' ) ) {
        newspress_front_echo_widget_area( $sidebar_id, $sidebar_label, $sidebar_class );
    } elseif ( is_active_sidebar( $sidebar_id ) ) {
        dynamic_sidebar( $sidebar_id );
    }
    ?>
</aside>
