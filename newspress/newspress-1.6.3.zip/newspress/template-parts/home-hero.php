<?php
$has_slider = is_active_sidebar( 'home-slider' );
$has_hero   = is_active_sidebar( 'home-hero-grid' );

if ( $has_slider || $has_hero ) : ?>
<section class="np-section np-hero-section">
    <?php if ( $has_slider ) : ?>
        <div class="np-widget-area np-widget-area-home-slider">
            <?php dynamic_sidebar( 'home-slider' ); ?>
        </div>
    <?php endif; ?>

    <?php if ( $has_hero ) : ?>
        <div class="np-widget-area np-widget-area-home-hero-grid">
            <?php dynamic_sidebar( 'home-hero-grid' ); ?>
        </div>
    <?php endif; ?>
</section>
<?php endif; ?>
