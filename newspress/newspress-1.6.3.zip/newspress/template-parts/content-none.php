<section class="no-results not-found">
    <h1><?php esc_html_e( 'Nothing Found', 'newspress' ); ?></h1>
    <p><?php esc_html_e( 'No content matched your request. Try searching.', 'newspress' ); ?></p>
    <?php get_search_form(); ?>
</section>
