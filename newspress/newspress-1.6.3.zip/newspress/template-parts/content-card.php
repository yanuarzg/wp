<?php
$np_card_context = function_exists( 'newspress_card_context' ) ? newspress_card_context() : 'latest';
$np_show_thumb   = ! function_exists( 'newspress_card_show' ) || newspress_card_show( 'thumb', $np_card_context );
$np_show_cat     = ! function_exists( 'newspress_card_show' ) || newspress_card_show( 'category', $np_card_context );
$np_show_meta    = ! function_exists( 'newspress_card_show' ) || newspress_card_show( 'meta', $np_card_context );
$np_show_excerpt = ! function_exists( 'newspress_card_show' ) || newspress_card_show( 'snippet', $np_card_context );
$np_post_classes = 'np-card np-card-context-' . sanitize_html_class( $np_card_context ) . ( $np_show_thumb ? '' : ' np-card-no-thumb' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $np_post_classes ); ?>>
    <?php if ( $np_show_thumb ) : ?>
        <a class="np-card-img" href="<?php the_permalink(); ?>"><?php newspress_thumbnail( 'newspress-card' ); ?></a>
    <?php endif; ?>
    <div class="np-card-body">
        <?php if ( $np_show_cat ) { newspress_category_badge(); } ?>
        <h2 class="np-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <?php if ( $np_show_meta ) : ?><div class="np-meta"><?php newspress_posted_on(); ?></div><?php endif; ?>
        <?php if ( $np_show_excerpt ) : ?><p><?php echo newspress_excerpt( 16 ); ?></p><?php endif; ?>
    </div>
</article>
