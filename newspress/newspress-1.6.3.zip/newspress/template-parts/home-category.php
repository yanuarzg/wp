<?php
$section = get_query_var( 'newspress_section', array() );
$type    = ! empty( $section['type'] ) ? sanitize_key( $section['type'] ) : 'category_grid';
$layout  = ( 'category_list' === $type ) ? 'list' : 'grid';
$cat     = ! empty( $section['category'] ) ? absint( $section['category'] ) : 0;
$title   = ! empty( $section['title'] ) ? $section['title'] : __( 'Latest News', 'newspress' );
$count   = ( 'list' === $layout ) ? 5 : 6;
$args    = array(
    'posts_per_page'      => $count,
    'ignore_sticky_posts' => true,
    'post_status'         => 'publish',
);
if ( $cat ) {
    $args['cat'] = $cat;
}
$q = new WP_Query( $args );
if ( $q->have_posts() ) : ?>
<section class="np-section np-category-section np-category-section-<?php echo esc_attr( $layout ); ?>">
    <div class="np-section-head">
        <h2><?php echo esc_html( $title ); ?></h2>
        <?php if ( $cat ) : ?><a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php esc_html_e( 'View All', 'newspress' ); ?></a><?php endif; ?>
    </div>

    <?php if ( 'list' === $layout ) : ?>
        <div class="np-category-list-panel">
            <?php while ( $q->have_posts() ) : $q->the_post(); ?>
                <article class="np-mini-card np-mini-card-list">
                    <a href="<?php the_permalink(); ?>"><?php newspress_thumbnail( 'newspress-thumb' ); ?></a>
                    <div>
                        <?php newspress_category_badge(); ?>
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <div class="np-meta"><?php newspress_posted_on(); ?></div>
                    </div>
                </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    <?php else : ?>
        <div class="np-category-grid">
            <?php $i = 0; while ( $q->have_posts() ) : $q->the_post(); $i++; ?>
                <?php if ( 1 === $i ) : ?>
                    <article class="np-cat-main">
                        <a href="<?php the_permalink(); ?>"><?php newspress_thumbnail( 'newspress-card' ); ?></a>
                        <?php newspress_category_badge(); ?>
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p><?php echo newspress_excerpt( 18 ); ?></p>
                        <div class="np-meta"><?php newspress_posted_on(); ?></div>
                    </article>
                    <div class="np-cat-list">
                <?php else : ?>
                    <article class="np-mini-card">
                        <a href="<?php the_permalink(); ?>"><?php newspress_thumbnail( 'newspress-thumb' ); ?></a>
                        <div><?php newspress_category_badge(); ?><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><div class="np-meta"><?php newspress_posted_on(); ?></div></div>
                    </article>
                <?php endif; ?>
            <?php endwhile; ?>
            <?php if ( $i > 1 ) : ?></div><?php endif; wp_reset_postdata(); ?>
        </div>
    <?php endif; ?>
</section>
<?php endif; ?>
