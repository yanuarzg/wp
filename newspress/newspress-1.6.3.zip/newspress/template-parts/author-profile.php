<?php
/**
 * Advanced author profile box displayed before related posts.
 *
 * @package NewsPress
 */
$author_id   = (int) get_the_author_meta( 'ID' );
$author_name = get_the_author_meta( 'display_name', $author_id );
$author_bio  = get_the_author_meta( 'description', $author_id );
$author_url  = get_author_posts_url( $author_id );
$author_site = get_the_author_meta( 'user_url', $author_id );
$role        = get_user_meta( $author_id, 'newspress_author_role', true );
$verified    = get_user_meta( $author_id, 'newspress_author_verified', true );
$count       = get_transient( 'newspress_author_posts_' . $author_id );
if ( false === $count ) {
    $count = count_user_posts( $author_id, 'post', true );
    set_transient( 'newspress_author_posts_' . $author_id, $count, 6 * HOUR_IN_SECONDS );
}
$socials = array(
    'instagram' => get_the_author_meta( 'instagram', $author_id ),
    'twitter'   => get_the_author_meta( 'twitter', $author_id ),
    'facebook'  => get_the_author_meta( 'facebook', $author_id ),
    'linkedin'  => get_the_author_meta( 'linkedin', $author_id ),
);
if ( ! $author_name ) {
    $author_name = get_bloginfo( 'name' );
}
$latest = new WP_Query( array(
    'author'              => $author_id,
    'posts_per_page'      => 3,
    'ignore_sticky_posts' => true,
    'post__not_in'        => array( get_the_ID() ),
    'no_found_rows'       => true,
) );
?>
<section class="np-author-profile" aria-labelledby="np-author-profile-title">
    <div class="np-author-avatar">
        <?php echo get_avatar( $author_id, 88, '', $author_name, array( 'class' => 'np-author-avatar-img' ) ); ?>
    </div>
    <div class="np-author-body">
        <p class="np-author-kicker"><?php esc_html_e( 'Author', 'newspress' ); ?><?php if ( $verified ) : ?> <span class="np-author-verified" aria-label="<?php esc_attr_e( 'Verified author', 'newspress' ); ?>">✓</span><?php endif; ?></p>
        <h2 id="np-author-profile-title" class="np-author-name"><a href="<?php echo esc_url( $author_url ); ?>"><?php echo esc_html( $author_name ); ?></a></h2>
        <?php if ( $role ) : ?><p class="np-author-role"><?php echo esc_html( $role ); ?></p><?php endif; ?>
        <?php if ( $author_bio ) : ?>
            <p class="np-author-description"><?php echo esc_html( $author_bio ); ?></p>
        <?php else : ?>
            <p class="np-author-description"><?php printf( esc_html__( 'Baca artikel lain dari %s.', 'newspress' ), esc_html( $author_name ) ); ?></p>
        <?php endif; ?>
        <div class="np-author-links">
            <a href="<?php echo esc_url( $author_url ); ?>"><?php printf( esc_html__( '%s articles', 'newspress' ), number_format_i18n( absint( $count ) ) ); ?></a>
            <?php if ( $author_site ) : ?><a href="<?php echo esc_url( $author_site ); ?>" rel="nofollow noopener" target="_blank"><?php esc_html_e( 'Website', 'newspress' ); ?></a><?php endif; ?>
            <?php foreach ( $socials as $network => $url ) : ?>
                <?php if ( $url ) : ?><a href="<?php echo esc_url( $url ); ?>" rel="nofollow noopener" target="_blank"><?php echo esc_html( ucfirst( $network ) ); ?></a><?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php if ( $latest->have_posts() ) : ?>
            <div class="np-author-latest">
                <strong><?php esc_html_e( 'Latest from this author', 'newspress' ); ?></strong>
                <ul>
                    <?php while ( $latest->have_posts() ) : $latest->the_post(); ?>
                        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                    <?php endwhile; wp_reset_postdata(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</section>
