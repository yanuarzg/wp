<?php
$breaking_label  = trim( (string) get_theme_mod( 'newspress_breaking_label', __( 'Breaking', 'newspress' ) ) );
$breaking_label  = '' !== $breaking_label ? $breaking_label : __( 'Breaking', 'newspress' );
$breaking_source = get_theme_mod( 'newspress_breaking_source', 'tag' );
$breaking_count  = min( 20, max( 1, absint( get_theme_mod( 'newspress_breaking_count', 8 ) ) ) );
$query_args      = array(
    'posts_per_page'      => $breaking_count,
    'ignore_sticky_posts' => true,
    'no_found_rows'       => true,
);

if ( 'category' === $breaking_source ) {
    $category_id = absint( get_theme_mod( 'newspress_breaking_category', 0 ) );
    if ( $category_id ) {
        $query_args['cat'] = $category_id;
    }
} elseif ( 'recent' !== $breaking_source ) {
    $query_args['tag'] = 'breaking-news';
}

$breaking = new WP_Query( $query_args );
if ( ! $breaking->have_posts() && 'recent' !== $breaking_source ) {
    $fallback_args = array(
        'posts_per_page'      => $breaking_count,
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
    );
    $breaking = new WP_Query( $fallback_args );
}

$items = array();
if ( $breaking->have_posts() ) {
    while ( $breaking->have_posts() ) {
        $breaking->the_post();
        $items[] = array(
            'url'   => get_permalink(),
            'title' => get_the_title(),
        );
    }
    wp_reset_postdata();
}
if ( ! empty( $items ) ) : ?>
<div class="np-breaking" role="region" aria-label="<?php esc_attr_e( 'Breaking news', 'newspress' ); ?>">
    <div class="np-container np-breaking-inner">
        <span class="np-breaking-label"><?php echo esc_html( $breaking_label ); ?></span>
        <div class="np-breaking-track">
            <div class="np-breaking-marquee">
                <?php for ( $round = 0; $round < 2; $round++ ) : ?>
                    <?php foreach ( $items as $item ) : ?>
                        <a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['title'] ); ?></a>
                    <?php endforeach; ?>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
