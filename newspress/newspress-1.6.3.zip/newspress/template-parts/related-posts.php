<?php
/** Smarter related posts. */
$post_id = get_the_ID();
$related_ids = array();

if ( ! function_exists( 'newspress_related_collect_ids' ) ) {
function newspress_related_collect_ids( $query_args, &$related_ids, $limit = 6 ) {
    $q = new WP_Query( $query_args );
    if ( $q->have_posts() ) {
        while ( $q->have_posts() && count( $related_ids ) < $limit ) {
            $q->the_post();
            $id = get_the_ID();
            if ( ! in_array( $id, $related_ids, true ) ) {
                $related_ids[] = $id;
            }
        }
    }
    wp_reset_postdata();
}
}

$limit = min( 12, max( 1, absint( get_theme_mod( 'newspress_related_count', 6 ) ) ) );
$tag_ids = wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) );
$cat_ids = wp_get_post_categories( $post_id );
$base = array(
    'post_type'           => 'post',
    'post_status'         => 'publish',
    'posts_per_page'      => $limit,
    'post__not_in'        => array( $post_id ),
    'ignore_sticky_posts' => true,
    'no_found_rows'       => true,
);
if ( $tag_ids ) {
    newspress_related_collect_ids( array_merge( $base, array( 'tag__in' => $tag_ids ) ), $related_ids, $limit );
}
if ( count( $related_ids ) < $limit && $cat_ids ) {
    newspress_related_collect_ids( array_merge( $base, array( 'category__in' => $cat_ids, 'post__not_in' => array_merge( array( $post_id ), $related_ids ) ) ), $related_ids, $limit );
}
if ( count( $related_ids ) < $limit ) {
    $keys = function_exists( 'newspress_views_keys' ) ? newspress_views_keys() : array( 'all' => '_newspress_views_total' );
    newspress_related_collect_ids( array_merge( $base, array( 'post__not_in' => array_merge( array( $post_id ), $related_ids ), 'meta_key' => $keys['all'], 'orderby' => 'meta_value_num', 'order' => 'DESC' ) ), $related_ids, $limit );
}
if ( count( $related_ids ) < $limit ) {
    newspress_related_collect_ids( array_merge( $base, array( 'post__not_in' => array_merge( array( $post_id ), $related_ids ) ) ), $related_ids, $limit );
}

if ( ! $related_ids ) {
    return;
}
$q = new WP_Query( array(
    'post_type' => 'post',
    'post__in' => $related_ids,
    'orderby'  => 'post__in',
    'posts_per_page' => $limit,
    'no_found_rows' => true,
) );
?>
<section class="np-related" aria-labelledby="np-related-title">
    <h2 id="np-related-title"><?php esc_html_e( 'Related Posts', 'newspress' ); ?></h2>
    <?php
    $previous_context = get_query_var( 'newspress_card_context' );
    set_query_var( 'newspress_card_context', 'related' );
    ?>
    <div class="np-related-grid <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'related' ) : 'np-card-list np-card-context-related np-card-layout-grid' ); ?>">
        <?php while ( $q->have_posts() ) : $q->the_post(); ?>
            <?php get_template_part( 'template-parts/content-card' ); ?>
        <?php endwhile; ?>
    </div>
    <?php
    set_query_var( 'newspress_card_context', $previous_context );
    wp_reset_postdata();
    ?>
</section>
