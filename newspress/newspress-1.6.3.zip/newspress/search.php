<?php get_header(); ?>
<main id="primary" class="np-site-main np-container np-layout <?php echo esc_attr( get_theme_mod( 'newspress_layout', 'right-sidebar' ) ); ?>">
    <div class="np-content">
        <?php $np_search_query = trim( get_search_query() ); ?>
        <header class="np-archive-header">
            <h1>
                <?php if ( '' === $np_search_query ) : ?>
                    <?php esc_html_e( 'Search', 'newspress' ); ?>
                <?php else : ?>
                    <?php echo esc_html( sprintf( __( 'Search Results for: %s', 'newspress' ), $np_search_query ) ); ?>
                <?php endif; ?>
            </h1>
        </header>
        <?php if ( '' === $np_search_query ) : ?>
            <?php get_search_form(); ?>
        <?php elseif ( have_posts() ) : ?>
            <div class="np-archive-grid np-latest-list <?php echo esc_attr( function_exists( 'newspress_card_container_classes' ) ? newspress_card_container_classes( 'latest' ) : '' ); ?>">
                <?php $np_previous_context = get_query_var( 'newspress_card_context' ); set_query_var( 'newspress_card_context', 'latest' ); while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; set_query_var( 'newspress_card_context', $np_previous_context ); ?>
            </div>
            <?php the_posts_pagination( array( 'mid_size' => 2, 'prev_text' => __( 'Previous', 'newspress' ), 'next_text' => __( 'Next', 'newspress' ) ) ); ?>
        <?php else : get_template_part( 'template-parts/content', 'none' ); endif; ?>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
