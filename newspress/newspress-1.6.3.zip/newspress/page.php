<?php get_header(); ?>
<main id="primary" class="np-site-main np-container np-page-wrap">
    <?php while ( have_posts() ) : the_post(); ?>
        <?php newspress_breadcrumbs(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'np-article' ); ?>>
            <header class="entry-header"><h1 class="entry-title"><?php the_title(); ?></h1></header>
            <div class="entry-content"><?php the_content(); wp_link_pages(); ?></div>
        </article>
        <?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
