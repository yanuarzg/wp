# NewsPress WordPress Theme

NewsPress adalah theme portal berita ringan dengan layout headline, breaking news, widget homepage, sidebar, slot iklan, share buttons, breadcrumbs, related posts, table of contents, dan schema Article/NewsArticle.

## Instalasi
1. Upload `newspress.zip` melalui Appearance > Themes > Add New > Upload Theme.
2. Aktifkan theme NewsPress.
3. Buat menu di Appearance > Menus dan assign ke Primary Menu.
4. Atur logo, warna, layout, dan slot iklan melalui Appearance > Customize.
5. Atur jumlah row homepage melalui Appearance > Homepage Builder.
6. Atur hero, slider, sidebar, footer, dan area iklan melalui Appearance > Widgets atau Customize > Widgets.

## Breaking News
Ticker otomatis mengambil post dengan tag slug `breaking-news`. Jika tidak ada, theme memakai post terbaru.

## Homepage Builder
Homepage Builder hanya mengatur struktur row dan navigasi latest posts. Komponen visual homepage dikelola lewat widget area agar bisa diedit dari Customizer Widgets.

## Catatan
Theme ini tidak memakai Bootstrap dan tidak bergantung pada jQuery di frontend.

## Version 1.4.1
- Added single post date/time format control in Customizer > NewsPress Options.
- Added published date and updated date visibility toggles for single post meta.
- Added view counter display below/after the Share label in the article share widget.
- Removed bold weight from post view counters.
- Continued 1.4 series security and demo-import hardening.

## Version 1.4.6
- Added local CryptoJS/OpenSSL-compatible domain license validation.
- Added Appearance > NewsPress License admin page.
- Added obfuscated local license secret fragments.
- Added license guard helpers for premium/admin features.
- Locked Demo Import/Export/Backup/Restore when license is inactive or validation code is tampered.


## Version 1.4.7
- Locked Customizer access when the local NewsPress license is inactive.
- Added 24-hour local license activation grace period with deadline display.
- Added frontend license alert and 10-second redirect to YzTheme after grace period expires.
- Added deadline information to admin notices and Demo Import locked notice.

## Version 1.4.8
- Added GitHub-based NewsPress theme updater using `update.json` from the GitHub update repository.
- Theme auto-update package is locked behind active local license validation.
- Added update manifest caching and package URL validation for GitHub hosts.

## Version 1.4.9
- Kept bundled demo/default-import.json and removed demo/README.txt.
- Simplified One Click Demo Import page copy and removed default-demo packaging instructions.
- Added bundled demo file availability notice.
- Updated license helper text with YzTheme member area link.

## Version 1.5.1
- Maintenance update package for testing NewsPress GitHub theme updater.
- Confirms update delivery from the new repository: https://github.com/yanuarzg/wp/tree/main/newspress.

## Version 1.5.0
- Changed NewsPress update manifest URL to the new GitHub repository: `https://github.com/yanuarzg/wp/tree/main/newspress`.
- Future update checks now read `https://raw.githubusercontent.com/yanuarzg/wp/main/newspress/update.json`.
- Update package URL now targets `https://raw.githubusercontent.com/yanuarzg/wp/main/newspress/newspress-1.x.x.zip`.


## Version 1.5.2
- Added WA Support button beside Save License on the NewsPress License page.
- This release is also intended to test the NewsPress GitHub theme updater flow.

## Version 1.5.3
- Fixed blank WordPress "View version details" modal in the GitHub theme updater.
- The updater now uses the internal WordPress theme-information modal URL and keeps the GitHub URL as the update homepage inside the modal.
- Added fallback description/changelog sections for safer update detail rendering.

## Version 1.5.4
- Fixed demo export/import so Categories and Posts are included in exported JSON.
- Improved import order: categories/posts are imported before menus.
- Legacy bundled default-import.json now falls back to built-in demo posts/categories when missing.
- Menu import now replaces existing items in the target menu to avoid skipped imports.

## Version 1.5.5
- Improved demo export/import for featured images, widget settings, Customizer settings, author mapping, and original post dates.
- Featured images are now sideloaded during JSON import when remote images are accessible.
- Widget options import now preserves widget instances and settings more reliably.
## Version 1.5.6
- Reworked demo export/import mapping for widgets, categories, homepage sections, and Customizer category references.
- Export now adds category/menu refs for NewsPress widget instances so category-based widgets survive import to a different site.
- Import now remaps widget category/category_id/cat fields by exported slug/old category map and resets invalid legacy category IDs to all categories instead of leaving broken selections.
- Preserves widget instance settings more safely while still sanitizing imported values.

## Version 1.5.7
- Improved demo export/import for featured images. Export now embeds thumbnail data when possible and import falls back to authenticated-style remote download.


## Version 1.5.9

- Added support for encrypted JSON annual license payloads.
- Added support for encrypted JSON lifetime licenses with wildcard subdomains.
- Legacy encrypted-domain license keys remain supported.
- License admin page now shows license type, mode, issue date, expiry date, remaining days, and wildcard scope.

## Version 1.5.8
- Added visible Demo Import progress overlay to prevent blank loading during large JSON/media import.
- Replaced bundled demo/default-import.json with the provided exported demo file.
