<?php
/**
 * NewsPress lightweight local license validation.
 *
 * Supports CryptoJS/OpenSSL-compatible salted AES passphrase keys.
 * This is deterrent-level protection for local/domain validation.
 *
 * @package NewsPress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function newspress_license_secret() {
    $parts = array(
        'bmV3',       // new
        'c3A=',       // sp
        'cmVzcw==',   // ress
        'QEA=',       // @@
        'IyM=',       // ##
        'Mjc=',       // 27
    );

    $secret = '';
    foreach ( $parts as $part ) {
        $decoded = base64_decode( $part, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        if ( false !== $decoded ) {
            $secret .= $decoded;
        }
    }

    return $secret;
}

function newspress_license_normalize_domain( $domain ) {
    $domain = strtolower( trim( (string) $domain ) );
    $domain = preg_replace( '#^https?://#', '', $domain );
    $domain = preg_replace( '#/.*$#', '', $domain );
    $domain = preg_replace( '#:\\d+$#', '', $domain );
    $domain = preg_replace( '#^www\\.#', '', $domain );

    return sanitize_text_field( $domain );
}

function newspress_license_current_domain() {
    $host = wp_parse_url( home_url(), PHP_URL_HOST );

    return newspress_license_normalize_domain( $host );
}

function newspress_license_evp_bytes_to_key( $password, $salt, $key_len = 32, $iv_len = 16 ) {
    $derived = '';
    $block   = '';

    while ( strlen( $derived ) < ( $key_len + $iv_len ) ) {
        $block    = md5( $block . $password . $salt, true );
        $derived .= $block;
    }

    return array(
        substr( $derived, 0, $key_len ),
        substr( $derived, $key_len, $iv_len ),
    );
}

function newspress_license_decrypt_cryptojs( $encrypted, $password = '' ) {
    if ( ! function_exists( 'openssl_decrypt' ) ) {
        return false;
    }

    $encrypted = trim( (string) $encrypted );
    $password  = '' !== $password ? $password : newspress_license_secret();
    $raw       = base64_decode( $encrypted, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

    if ( ! $raw || strlen( $raw ) < 17 ) {
        return false;
    }

    if ( 'Salted__' !== substr( $raw, 0, 8 ) ) {
        return false;
    }

    $salt       = substr( $raw, 8, 8 );
    $ciphertext = substr( $raw, 16 );
    list( $key, $iv ) = newspress_license_evp_bytes_to_key( $password, $salt );

    $plain = openssl_decrypt( $ciphertext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

    if ( false === $plain ) {
        return false;
    }

    return trim( $plain );
}

function newspress_license_parse_domains( $plain ) {
    $plain = trim( (string) $plain );

    if ( '' === $plain ) {
        return array();
    }

    $json = json_decode( $plain, true );

    if ( is_array( $json ) ) {
        if ( ! empty( $json['product'] ) && 'newspress' !== sanitize_key( $json['product'] ) ) {
            return array();
        }

        if ( ! empty( $json['domain'] ) ) {
            return array( newspress_license_normalize_domain( $json['domain'] ) );
        }

        if ( ! empty( $json['domains'] ) && is_array( $json['domains'] ) ) {
            return array_filter( array_map( 'newspress_license_normalize_domain', $json['domains'] ) );
        }
    }

    $parts = preg_split( '/[\\s,|;]+/', $plain );

    return array_filter( array_map( 'newspress_license_normalize_domain', (array) $parts ) );
}

function newspress_license_domain_matches( $current, $licensed ) {
    $current  = newspress_license_normalize_domain( $current );
    $licensed = newspress_license_normalize_domain( $licensed );

    if ( ! $current || ! $licensed ) {
        return false;
    }

    if ( $current === $licensed ) {
        return true;
    }

    if ( 0 === strpos( $licensed, '*.' ) ) {
        $root   = substr( $licensed, 2 );
        $suffix = '.' . $root;

        return $current === $root || substr( $current, -strlen( $suffix ) ) === $suffix;
    }

    return false;
}

function newspress_license_core_available() {
    return function_exists( 'newspress_license_secret' )
        && function_exists( 'newspress_license_decrypt_cryptojs' )
        && function_exists( 'newspress_license_current_domain' )
        && function_exists( 'newspress_license_domain_matches' );
}

function newspress_license_integrity_token() {
    if ( ! function_exists( 'newspress_license_secret' ) ) {
        return '';
    }

    return hash( 'sha256', 'newspress|local-license|cryptojs|domain|1.4|' . newspress_license_secret() );
}

function newspress_license_integrity_valid() {
    $expected = '9590bdeb621d093baac62ca329b7c9bb4a5ce2e8d09d701640097d5b4346c543';

    return hash_equals( $expected, newspress_license_integrity_token() );
}

function newspress_license_get_key() {
    return trim( (string) get_option( 'newspress_license_key', '' ) );
}

function newspress_license_get_status() {
    $key     = newspress_license_get_key();
    $current = newspress_license_current_domain();

    $status = array(
        'valid'           => false,
        'status'          => 'empty',
        'current_domain'  => $current,
        'licensed_domain' => '',
        'message'         => __( 'License key is empty.', 'newspress' ),
        'plain'           => '',
    );

    if ( ! newspress_license_core_available() || ! newspress_license_integrity_valid() ) {
        $status['status']  = 'tampered';
        $status['message'] = __( 'License validation files appear to be modified.', 'newspress' );
        return $status;
    }

    if ( '' === $key ) {
        return $status;
    }

    $plain = newspress_license_decrypt_cryptojs( $key );

    if ( ! $plain ) {
        $status['status']  = 'invalid_key';
        $status['message'] = __( 'License key cannot be decrypted.', 'newspress' );
        return $status;
    }

    $domains = newspress_license_parse_domains( $plain );

    if ( empty( $domains ) ) {
        $status['status']  = 'invalid_payload';
        $status['message'] = __( 'License key does not contain a valid NewsPress domain.', 'newspress' );
        $status['plain']   = $plain;
        return $status;
    }

    foreach ( $domains as $domain ) {
        if ( newspress_license_domain_matches( $current, $domain ) ) {
            $status['valid']           = true;
            $status['status']          = 'active';
            $status['licensed_domain'] = $domain;
            $status['message']         = __( 'License is active.', 'newspress' );
            $status['plain']           = $plain;
            return $status;
        }
    }

    $status['status']          = 'domain_mismatch';
    $status['licensed_domain'] = implode( ', ', $domains );
    $status['message']         = __( 'License key is not valid for this domain.', 'newspress' );
    $status['plain']           = $plain;

    return $status;
}

function newspress_license_is_valid() {
    $status = newspress_license_get_status();

    return ! empty( $status['valid'] );
}

function newspress_license_can_use_premium_feature() {
    return newspress_license_core_available() && newspress_license_integrity_valid() && newspress_license_is_valid();
}

function newspress_license_grace_period_seconds() {
    return (int) apply_filters( 'newspress_license_grace_period_seconds', DAY_IN_SECONDS );
}

function newspress_license_grace_started_at() {
    $started = absint( get_option( 'newspress_license_grace_started_at', 0 ) );

    if ( ! $started ) {
        $started = current_time( 'timestamp' );
        update_option( 'newspress_license_grace_started_at', $started, false );
    }

    return $started;
}

function newspress_license_grace_deadline() {
    return newspress_license_grace_started_at() + newspress_license_grace_period_seconds();
}

function newspress_license_grace_expired() {
    if ( newspress_license_is_valid() ) {
        return false;
    }

    return current_time( 'timestamp' ) > newspress_license_grace_deadline();
}

function newspress_license_format_timestamp( $timestamp ) {
    $format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

    return date_i18n( $format, absint( $timestamp ) );
}

function newspress_license_deadline_text() {
    return newspress_license_format_timestamp( newspress_license_grace_deadline() );
}

function newspress_license_update_grace_state() {
    if ( newspress_license_is_valid() ) {
        delete_option( 'newspress_license_grace_started_at' );
        return;
    }

    newspress_license_grace_started_at();
}
add_action( 'init', 'newspress_license_update_grace_state', 1 );
add_action( 'after_switch_theme', 'newspress_license_grace_started_at' );

function newspress_license_block_customizer() {
    if ( newspress_license_is_valid() ) {
        return;
    }

    $message  = '<h1>' . esc_html__( 'NewsPress License Required', 'newspress' ) . '</h1>';
    $message .= '<p>' . esc_html__( 'Customizer access is locked until the NewsPress license is activated for this domain.', 'newspress' ) . '</p>';
    $message .= '<p><strong>' . esc_html__( 'Activation deadline:', 'newspress' ) . '</strong> ' . esc_html( newspress_license_deadline_text() ) . '</p>';
    $message .= '<p><a class="button button-primary" href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'Activate NewsPress License', 'newspress' ) . '</a></p>';

    wp_die( $message, esc_html__( 'NewsPress License Required', 'newspress' ), array( 'response' => 403 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_license_maybe_block_customizer_request() {
    global $pagenow;

    if ( is_admin() && 'customize.php' === $pagenow ) {
        newspress_license_block_customizer();
    }
}
add_action( 'admin_init', 'newspress_license_maybe_block_customizer_request', 1 );
add_action( 'customize_controls_init', 'newspress_license_block_customizer', 1 );

function newspress_license_frontend_redirect_notice() {
    if ( is_admin() || wp_doing_ajax() || wp_is_json_request() || newspress_license_is_valid() || ! newspress_license_grace_expired() ) {
        return;
    }

    $current_domain = newspress_license_current_domain();
    if ( 'yztheme.my.id' === $current_domain ) {
        return;
    }

    $message = __( 'Situs ini belum mengaktifkan lisensi. Dapatkan lisensi resmi di member area YzTheme.', 'newspress' );
    $target  = 'https://yztheme.my.id/';
    ?>
    <script>
    (function(){
        var message = <?php echo wp_json_encode( $message ); ?>;
        var target = <?php echo wp_json_encode( $target ); ?>;
        try { window.alert(message); } catch(e) {}
        window.setTimeout(function(){ window.location.href = target; }, 10000);
    })();
    </script>
    <?php
}
add_action( 'wp_footer', 'newspress_license_frontend_redirect_notice', 999 );

function newspress_license_admin_menu() {
    add_theme_page(
        __( 'NewsPress License', 'newspress' ),
        __( 'NewsPress License', 'newspress' ),
        'manage_options',
        'newspress-license',
        'newspress_license_admin_page'
    );
}
add_action( 'admin_menu', 'newspress_license_admin_menu' );

function newspress_license_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( isset( $_POST['newspress_license_save'] ) && isset( $_POST['newspress_license_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['newspress_license_nonce'] ) ), 'newspress_license_action' ) ) {
        $key = isset( $_POST['newspress_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['newspress_license_key'] ) ) : '';
        update_option( 'newspress_license_key', $key, false );
        delete_transient( 'newspress_license_status' );
        if ( newspress_license_is_valid() ) {
            delete_option( 'newspress_license_grace_started_at' );
        } else {
            newspress_license_grace_started_at();
        }
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'License key saved.', 'newspress' ) . '</p></div>';
    }

    $status = newspress_license_get_status();
    ?>
    <div class="wrap newspress-license-page">
        <h1><?php esc_html_e( 'NewsPress License', 'newspress' ); ?></h1>

        <?php if ( $status['valid'] ) : ?>
            <div class="notice notice-success inline"><p><strong><?php esc_html_e( 'Active:', 'newspress' ); ?></strong> <?php echo esc_html( $status['licensed_domain'] ); ?></p></div>
        <?php else : ?>
            <div class="notice notice-error inline"><p><strong><?php esc_html_e( 'Inactive:', 'newspress' ); ?></strong> <?php echo esc_html( $status['message'] ); ?></p></div>
        <?php endif; ?>

        <table class="widefat striped" style="max-width:760px;margin:16px 0;">
            <tbody>
                <tr>
                    <th style="width:220px;"><?php esc_html_e( 'Current domain', 'newspress' ); ?></th>
                    <td><code><?php echo esc_html( $status['current_domain'] ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Licensed domain', 'newspress' ); ?></th>
                    <td><code><?php echo esc_html( $status['licensed_domain'] ? $status['licensed_domain'] : '-' ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Status', 'newspress' ); ?></th>
                    <td><?php echo esc_html( $status['message'] ); ?></td>
                </tr>
                <?php if ( ! $status['valid'] ) : ?>
                    <tr>
                        <th><?php esc_html_e( 'Activation deadline', 'newspress' ); ?></th>
                        <td><strong><?php echo esc_html( newspress_license_deadline_text() ); ?></strong></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <form method="post" style="max-width:760px;">
            <?php wp_nonce_field( 'newspress_license_action', 'newspress_license_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="newspress_license_key"><?php esc_html_e( 'License key', 'newspress' ); ?></label></th>
                    <td>
                        <textarea id="newspress_license_key" name="newspress_license_key" rows="4" class="large-text code" placeholder="U2FsdGVkX1..."><?php echo esc_textarea( newspress_license_get_key() ); ?></textarea>
                        <p class="description">
                            <?php esc_html_e( 'Paste license key for this domain.', 'newspress' ); ?>
                            <a href="<?php echo esc_url( 'https://www.yztheme.my.id/p/member-area.html' ); ?>" target="_blank" rel="noopener noreferrer">
                                <?php esc_html_e( 'Open YzTheme member Area.', 'newspress' ); ?>
                            </a>
                        </p>
                    </td>
                </tr>
            </table>
            <?php
            $newspress_license_support_text = rawurlencode( __( 'Halo Admin YzTheme, saya membutuhkan bantuan untuk lisensi NewsPress.', 'newspress' ) );
            $newspress_license_support_url  = 'https://wa.me/6289507785333?text=' . $newspress_license_support_text;
            ?>
            <p>
                <button type="submit" name="newspress_license_save" class="button button-primary"><?php esc_html_e( 'Save License', 'newspress' ); ?></button>
                <a class="button" href="<?php echo esc_url( $newspress_license_support_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'WA Support', 'newspress' ); ?></a>
            </p>
        </form>
    </div>
    <?php
}

function newspress_license_admin_notice() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( $screen && in_array( $screen->id, array( 'appearance_page_newspress-license', 'appearance_page_newspress-demo-import' ), true ) ) {
        return;
    }

    if ( newspress_license_is_valid() ) {
        return;
    }

    $expired = newspress_license_grace_expired();

    echo '<div class="notice ' . ( $expired ? 'notice-error' : 'notice-warning' ) . '"><p>';
    echo esc_html__( 'NewsPress license is not active for this domain.', 'newspress' );
    echo ' <strong>' . esc_html__( 'Activation deadline:', 'newspress' ) . '</strong> ' . esc_html( newspress_license_deadline_text() ) . '.';
    if ( $expired ) {
        echo ' ' . esc_html__( 'The grace period has expired; frontend visitors will see a license alert and be redirected to YzTheme.', 'newspress' );
    }
    echo ' <a href="' . esc_url( admin_url( 'themes.php?page=newspress-license' ) ) . '">' . esc_html__( 'Activate license', 'newspress' ) . '</a>';
    echo '</p></div>';
}
add_action( 'admin_notices', 'newspress_license_admin_notice' );
