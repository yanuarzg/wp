<?php
/**
 * One click demo import/export for NewsPress.
 *
 * @package NewsPress
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_demo_import_license_is_active() {
    return function_exists( 'newspress_license_can_use_premium_feature' ) && newspress_license_can_use_premium_feature();
}

function newspress_demo_import_license_locked_notice() {
    $license_url = admin_url( 'themes.php?page=newspress-license' );
    ?>
    <div class="wrap newspress-demo-import">
        <h1><?php esc_html_e( 'NewsPress One Click Demo Import', 'newspress' ); ?></h1>
        <div class="notice notice-error inline">
            <p>
                <strong><?php esc_html_e( 'License required.', 'newspress' ); ?></strong>
                <?php esc_html_e( 'Please activate your NewsPress license before using Demo Import, Export, Backup, or Restore.', 'newspress' ); ?>
                <?php if ( function_exists( 'newspress_license_deadline_text' ) ) : ?>
                    <br><strong><?php esc_html_e( 'Activation deadline:', 'newspress' ); ?></strong> <?php echo esc_html( newspress_license_deadline_text() ); ?>
                <?php endif; ?>
                <a href="<?php echo esc_url( $license_url ); ?>"><?php esc_html_e( 'Activate license', 'newspress' ); ?></a>
            </p>
        </div>
    </div>
    <?php
}

function newspress_demo_import_menu() {
    add_theme_page(
        __( 'NewsPress Demo Import', 'newspress' ),
        __( 'NewsPress Demo Import', 'newspress' ),
        'manage_options',
        'newspress-demo-import',
        'newspress_demo_import_page'
    );
}
add_action( 'admin_menu', 'newspress_demo_import_menu' );

add_action( 'admin_init', 'newspress_demo_maybe_download_export' );

function newspress_demo_maybe_download_export() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( ! isset( $_POST['newspress_demo_export'] ) ) {
        return;
    }

    if ( empty( $_GET['page'] ) || 'newspress-demo-import' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
        return;
    }

    if ( ! isset( $_POST['newspress_demo_import_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['newspress_demo_import_nonce'] ) ), 'newspress_demo_import_action' ) ) {
        wp_die( esc_html__( 'Security check failed.', 'newspress' ) );
    }

    if ( ! newspress_demo_import_license_is_active() ) {
        wp_die( esc_html__( 'Please activate your NewsPress license before exporting demo setup.', 'newspress' ) );
    }

    newspress_demo_download_export();
}

function newspress_demo_import_parts() {
    return array(
        'categories' => __( 'Categories', 'newspress' ),
        'posts'      => __( 'Demo posts', 'newspress' ),
        'menus'      => __( 'Menus', 'newspress' ),
        'widgets'    => __( 'Widgets', 'newspress' ),
        'customizer' => __( 'Customizer settings', 'newspress' ),
        'homepage'   => __( 'Homepage Builder settings', 'newspress' ),
    );
}

function newspress_demo_get_requested_parts() {
    $available = array_keys( newspress_demo_import_parts() );
    $posted    = isset( $_POST['newspress_demo_parts'] ) ? (array) wp_unslash( $_POST['newspress_demo_parts'] ) : $available;
    $posted    = array_map( 'sanitize_key', $posted );
    $parts     = array_fill_keys( $available, false );

    foreach ( $posted as $part ) {
        if ( array_key_exists( $part, $parts ) ) {
            $parts[ $part ] = true;
        }
    }

    return $parts;
}

function newspress_demo_import_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( ! newspress_demo_import_license_is_active() ) {
        newspress_demo_import_license_locked_notice();
        return;
    }

    $message = '';
    $error   = '';

    if ( isset( $_POST['newspress_demo_import'] ) && check_admin_referer( 'newspress_demo_import_action', 'newspress_demo_import_nonce' ) ) {
        $parts   = newspress_demo_get_requested_parts();
        $payload = newspress_demo_get_uploaded_payload();

        if ( is_wp_error( $payload ) ) {
            $error = $payload->get_error_message();
        } else {
            newspress_demo_save_backup( 'before_import' );
            $result  = newspress_run_demo_import( $parts, $payload );
            $message = sprintf(
                __( 'Import finished. Created/updated %1$d posts and %2$d categories. Menus: %3$d. Widget areas: %4$d.', 'newspress' ),
                absint( $result['posts'] ),
                absint( $result['categories'] ),
                absint( $result['menus'] ),
                absint( $result['sidebars'] )
            );
        }
    }

    if ( isset( $_POST['newspress_demo_create_backup'] ) && check_admin_referer( 'newspress_demo_import_action', 'newspress_demo_import_nonce' ) ) {
        newspress_demo_save_backup( 'manual' );
        $message = __( 'Current NewsPress setup backup saved.', 'newspress' );
    }

    if ( isset( $_POST['newspress_demo_restore_backup'] ) && check_admin_referer( 'newspress_demo_import_action', 'newspress_demo_import_nonce' ) ) {
        $restored = newspress_demo_restore_backup();
        if ( is_wp_error( $restored ) ) {
            $error = $restored->get_error_message();
        } else {
            $message = __( 'Last NewsPress setup backup restored.', 'newspress' );
        }
    }

    if ( isset( $_POST['newspress_demo_reset'] ) && check_admin_referer( 'newspress_demo_import_action', 'newspress_demo_import_nonce' ) ) {
        newspress_reset_demo_import_flag();
        $message = __( 'Demo import flag reset. You can import again.', 'newspress' );
    }

    $parts             = newspress_demo_import_parts();
    $backup            = newspress_demo_get_backup();
    $bundled_demo_file = trailingslashit( NEWSPRESS_DIR ) . 'demo/default-import.json';
    $has_bundled_demo  = file_exists( $bundled_demo_file );
    ?>
    <div class="wrap newspress-demo-import">
        <h1><?php esc_html_e( 'NewsPress One Click Demo Import', 'newspress' ); ?></h1>
        <?php if ( $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
        <?php if ( $error ) : ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div><?php endif; ?>

        <p><?php esc_html_e( 'Choose only the parts you want to import. Existing content is not deleted.', 'newspress' ); ?></p>
        <div class="notice notice-warning inline"><p><?php esc_html_e( 'Use export JSON only from a trusted NewsPress site. Import can replace widgets, menu locations, Customizer colors/text, and homepage builder settings. A settings backup is saved automatically before import.', 'newspress' ); ?></p></div>
        <?php if ( ! empty( $backup['backup_at'] ) ) : ?>
            <p><strong><?php esc_html_e( 'Last settings backup:', 'newspress' ); ?></strong> <?php echo esc_html( $backup['backup_at'] ); ?></p>
        <?php else : ?>
            <p><strong><?php esc_html_e( 'Last settings backup:', 'newspress' ); ?></strong> <?php esc_html_e( 'Not available yet.', 'newspress' ); ?></p>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field( 'newspress_demo_import_action', 'newspress_demo_import_nonce' ); ?>

            <h2><?php esc_html_e( 'Import Options', 'newspress' ); ?></h2>
            <fieldset style="display:grid;gap:8px;max-width:520px;margin:12px 0 20px;">
                <?php foreach ( $parts as $key => $label ) : ?>
                    <label>
                        <input type="checkbox" name="newspress_demo_parts[]" value="<?php echo esc_attr( $key ); ?>" checked>
                        <?php echo esc_html( $label ); ?>
                    </label>
                <?php endforeach; ?>
            </fieldset>

            <h2><?php esc_html_e( 'Optional: Import from Export File', 'newspress' ); ?></h2>
            <p>
                <input type="file" name="newspress_demo_json" accept="application/json,.json">
            </p>
            <?php if ( $has_bundled_demo ) : ?>
                <p class="description">
                    <?php esc_html_e( 'Bundled demo file detected:', 'newspress' ); ?> <code>demo/default-import.json</code>
                </p>
            <?php else : ?>
                <p class="description"><strong><?php esc_html_e( 'Bundled demo file is missing.', 'newspress' ); ?></strong></p>
            <?php endif; ?>
            <p class="description"><?php esc_html_e( 'Leave empty to use the bundled default demo. Maximum JSON size: 2 MB.', 'newspress' ); ?></p>

            <p style="margin-top:20px;">
                <button type="submit" name="newspress_demo_import" class="button button-primary button-hero"><?php esc_html_e( 'Import Demo Parts', 'newspress' ); ?></button>
                <button type="submit" name="newspress_demo_export" class="button button-hero"><?php esc_html_e( 'Export Current Setup', 'newspress' ); ?></button>
                <button type="submit" name="newspress_demo_create_backup" class="button"><?php esc_html_e( 'Save Backup Now', 'newspress' ); ?></button>
                <button type="submit" name="newspress_demo_restore_backup" class="button" onclick="return confirm('<?php echo esc_js( __( 'Restore the last NewsPress settings backup? This will replace current Customizer, homepage, widget, and menu locations.', 'newspress' ) ); ?>');" <?php disabled( empty( $backup ) ); ?>><?php esc_html_e( 'Restore Last Backup', 'newspress' ); ?></button>
                <button type="submit" name="newspress_demo_reset" class="button"><?php esc_html_e( 'Reset Import Flag', 'newspress' ); ?></button>
            </p>
        </form>
    </div>
    <?php
}

function newspress_demo_categories() {
    return array( 'Headline', 'Nasional', 'Ekonomi', 'Teknologi', 'Olahraga', 'Lifestyle', 'Internasional', 'Otomotif' );
}

function newspress_demo_get_uploaded_payload() {
    if ( empty( $_FILES['newspress_demo_json']['tmp_name'] ) ) {
        return newspress_demo_get_bundled_payload();
    }

    $file = $_FILES['newspress_demo_json'];

    if ( ! empty( $file['error'] ) ) {
        return new WP_Error( 'upload_error', __( 'The uploaded JSON file could not be read.', 'newspress' ) );
    }

    if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
        return new WP_Error( 'invalid_upload', __( 'Invalid uploaded file.', 'newspress' ) );
    }

    $filename = isset( $file['name'] ) ? sanitize_file_name( wp_unslash( $file['name'] ) ) : '';
    $ext      = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
    if ( 'json' !== $ext ) {
        return new WP_Error( 'invalid_extension', __( 'Only .json export files are allowed.', 'newspress' ) );
    }

    $size = isset( $file['size'] ) ? absint( $file['size'] ) : 0;
    if ( $size <= 0 || $size > 2 * MB_IN_BYTES ) {
        return new WP_Error( 'invalid_size', __( 'The JSON file is empty or larger than 2 MB.', 'newspress' ) );
    }

    $json = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
    if ( ! $json ) {
        return new WP_Error( 'empty_json', __( 'The uploaded JSON file is empty.', 'newspress' ) );
    }

    $payload = json_decode( $json, true );
    if ( ! is_array( $payload ) ) {
        return new WP_Error( 'invalid_json', __( 'Invalid NewsPress export JSON.', 'newspress' ) );
    }

    $validation = newspress_demo_validate_payload( $payload, true );
    if ( is_wp_error( $validation ) ) {
        return $validation;
    }

    return $payload;
}

function newspress_demo_get_bundled_payload() {
    $file = trailingslashit( NEWSPRESS_DIR ) . 'demo/default-import.json';
    if ( ! file_exists( $file ) ) {
        return array();
    }

    $json = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
    if ( ! $json ) {
        return array();
    }

    $payload = json_decode( $json, true );
    if ( ! is_array( $payload ) ) {
        return array();
    }

    return is_wp_error( newspress_demo_validate_payload( $payload, false ) ) ? array() : $payload;
}

function newspress_demo_validate_payload( $payload, $strict = true ) {
    if ( empty( $payload ) ) {
        return true;
    }

    if ( $strict && empty( $payload['newspress_export_version'] ) ) {
        return new WP_Error( 'missing_export_version', __( 'This is not a valid NewsPress export file.', 'newspress' ) );
    }

    if ( ! empty( $payload['theme'] ) && 'newspress' !== sanitize_key( $payload['theme'] ) ) {
        return new WP_Error( 'wrong_theme', __( 'This export file is not for NewsPress.', 'newspress' ) );
    }

    $allowed = array( 'newspress_export_version', 'theme', 'exported_at', 'backup_at', 'reason', 'theme_mods', 'homepage', 'widgets', 'menus' );
    foreach ( array_keys( $payload ) as $key ) {
        if ( ! in_array( $key, $allowed, true ) ) {
            unset( $payload[ $key ] );
        }
    }

    return true;
}

function newspress_run_demo_import( $parts = array(), $payload = array() ) {
    $parts = wp_parse_args( $parts, array(
        'categories' => true,
        'posts'      => true,
        'menus'      => true,
        'widgets'    => true,
        'customizer' => true,
        'homepage'   => true,
    ) );

    $result = array(
        'posts'      => 0,
        'categories' => 0,
        'menus'      => 0,
        'sidebars'   => 0,
    );
    $cat_ids = array();

    if ( ! empty( $payload ) ) {
        $export_result = newspress_apply_exported_setup( $payload, $parts );
        foreach ( $result as $key => $value ) {
            $result[ $key ] += isset( $export_result[ $key ] ) ? absint( $export_result[ $key ] ) : 0;
        }
    }

    if ( empty( $payload ) || empty( $payload['newspress_export_version'] ) ) {
        if ( $parts['categories'] || $parts['posts'] || $parts['menus'] ) {
            foreach ( newspress_demo_categories() as $cat_name ) {
                $term = term_exists( $cat_name, 'category' );
                if ( ! $term && $parts['categories'] ) {
                    $term = wp_insert_term( $cat_name, 'category' );
                    if ( ! is_wp_error( $term ) ) {
                        $result['categories']++;
                    }
                }
                if ( ! is_wp_error( $term ) && $term ) {
                    $cat_ids[ $cat_name ] = is_array( $term ) ? absint( $term['term_id'] ) : absint( $term );
                }
            }
        }

        if ( $parts['posts'] ) {
            $result['posts'] += newspress_demo_create_posts( $cat_ids );
        }

        if ( $parts['menus'] ) {
            $result['menus'] += newspress_demo_setup_menu( $cat_ids );
        }

        if ( $parts['widgets'] ) {
            $result['sidebars'] += newspress_demo_setup_widgets();
        }

        if ( $parts['customizer'] ) {
            newspress_demo_setup_customizer();
        }

        if ( $parts['homepage'] ) {
            newspress_demo_setup_homepage();
        }
    }

    update_option( 'newspress_demo_imported', current_time( 'mysql' ) );

    return $result;
}

function newspress_demo_create_posts( $cat_ids ) {
    $titles = array(
        'Agenda Politik Nasional Hari Ini Jadi Sorotan Publik',
        'Ekonomi Digital Tumbuh, Pelaku UMKM Mulai Beralih Online',
        'Tim Sepak Bola Nasional Siapkan Strategi Baru Musim Ini',
        'Pembaruan Teknologi AI Lokal Diperkenalkan untuk Pelaku Bisnis',
        'Pemerintah Siapkan Kebijakan Transportasi Perkotaan Terbaru',
        'Cuaca Ekstrem, Warga Diminta Waspada di Sejumlah Wilayah',
        'Pasar Modal Menguat Setelah Sentimen Global Membaik',
        'Inovasi Energi Bersih Jadi Fokus Industri Tahun Ini',
        'Komunitas Kreatif Dorong Wisata Lokal Makin Dikenal',
        'Pendidikan Digital Mendorong Akses Belajar Lebih Merata',
        'Layanan Publik Berbasis Aplikasi Mulai Diperluas',
        'Tren Otomotif Ramah Lingkungan Meningkat di Indonesia',
    );

    $created_posts = 0;
    foreach ( $titles as $i => $title ) {
        $existing = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => 'any',
            'meta_key'       => '_newspress_demo_key',
            'meta_value'     => sanitize_title( $title ),
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ) );
        if ( $existing ) {
            continue;
        }
        $cat_names = array_values( newspress_demo_categories() );
        $cat       = $cat_names[ $i % count( $cat_names ) ];
        $post_cats = array_filter( array( $cat_ids[ $cat ] ?? 0, $cat_ids['Headline'] ?? 0 ) );
        $content   = '<p>Ini adalah contoh artikel demo NewsPress untuk membantu Anda melihat susunan portal berita secara langsung setelah theme diaktifkan.</p>';
        $content  .= '<h2>Latar Belakang</h2><p>Paragraf demo ini menampilkan ritme artikel berita yang bersih, ringkas, dan mudah dibaca di perangkat mobile maupun desktop.</p>';
        $content  .= '<h2>Perkembangan Terbaru</h2><p>Bagian ini dapat diganti dengan berita aktual sesuai kebutuhan redaksi. Gunakan featured image agar tampilan homepage lebih kuat.</p>';
        $content  .= '<h3>Respons Publik</h3><p>Tambahkan kutipan, data pendukung, dan tautan internal untuk memperkuat kualitas artikel.</p>';
        $post_id = wp_insert_post( array(
            'post_title'    => $title,
            'post_status'   => 'publish',
            'post_author'   => get_current_user_id(),
            'post_category' => $post_cats,
            'post_excerpt'  => 'Contoh ringkasan artikel demo untuk mengisi tampilan NewsPress.',
            'post_content'  => $content,
        ) );
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_newspress_demo_key', sanitize_title( $title ) );
            update_post_meta( $post_id, defined( 'NEWSPRESS_META_DESCRIPTION_KEY' ) ? NEWSPRESS_META_DESCRIPTION_KEY : '_newspress_meta_description', 'Contoh meta deskripsi demo NewsPress yang dapat diganti melalui panel editor artikel.' );
            $created_posts++;
        }
    }
    return $created_posts;
}

function newspress_demo_setup_menu( $cat_ids ) {
    $menu_name = 'NewsPress Demo Menu';
    $menu_id = wp_get_nav_menu_object( $menu_name );
    if ( ! $menu_id ) {
        $menu_id = wp_create_nav_menu( $menu_name );
    } else {
        $menu_id = $menu_id->term_id;
    }
    if ( is_wp_error( $menu_id ) ) {
        return 0;
    }
    $locations = get_theme_mod( 'nav_menu_locations', array() );
    $locations['primary'] = $menu_id;
    set_theme_mod( 'nav_menu_locations', $locations );

    $existing_items = wp_get_nav_menu_items( $menu_id );
    if ( ! empty( $existing_items ) ) {
        return 0;
    }
    wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title'  => __( 'Home', 'newspress' ),
        'menu-item-url'    => home_url( '/' ),
        'menu-item-status' => 'publish',
    ) );
    $created = 1;
    foreach ( array_slice( $cat_ids, 0, 6, true ) as $name => $term_id ) {
        $item_id = wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'     => $name,
            'menu-item-object'    => 'category',
            'menu-item-object-id' => $term_id,
            'menu-item-type'      => 'taxonomy',
            'menu-item-status'    => 'publish',
        ) );
        if ( $item_id && ! is_wp_error( $item_id ) ) {
            $created++;
        }
    }
    return $created;
}

function newspress_demo_setup_widgets() {
    $sidebars = wp_get_sidebars_widgets();
    $changed  = 0;

    foreach ( array(
        'home-hero-grid' => array( 'newspress_hero_grid-2' ),
        'home-slider'    => array( 'newspress_recent_slider-2' ),
        'sidebar-1'      => array( 'newspress_popular_posts-2', 'newspress_recent_posts-2', 'newspress_random_list-2' ),
    ) as $sidebar_id => $widgets ) {
        if ( empty( $sidebars[ $sidebar_id ] ) ) {
            $sidebars[ $sidebar_id ] = $widgets;
            $changed++;
        }
    }

    update_option( 'widget_newspress_hero_grid', array(
        2 => array( 'title' => '', 'source' => 'latest', 'category' => 0, 'count' => 3, 'show_excerpt' => 1 ),
        '_multiwidget' => 1,
    ) );
    update_option( 'widget_newspress_recent_slider', array(
        2 => array( 'title' => 'Headline', 'num_posts' => 5, 'category_id' => 0, 'show_category' => 1, 'show_snippet' => 0, 'snippet_length' => 120, 'autoplay' => 1, 'autoplay_speed' => 5000 ),
        '_multiwidget' => 1,
    ) );
    update_option( 'widget_newspress_popular_posts', array(
        2 => array( 'title' => 'Terpopuler', 'range' => 'week', 'count' => 5 ),
        '_multiwidget' => 1,
    ) );
    update_option( 'widget_newspress_recent_posts', array(
        2 => array( 'title' => 'Berita Terkini', 'count' => 5 ),
        '_multiwidget' => 1,
    ) );
    update_option( 'widget_newspress_random_list', array(
        2 => array( 'title' => 'Pilihan Redaksi', 'category' => 0, 'count' => 5 ),
        '_multiwidget' => 1,
    ) );
    wp_set_sidebars_widgets( $sidebars );

    return $changed;
}

function newspress_demo_setup_customizer() {
    set_theme_mod( 'newspress_primary_color', '#00579c' );
    set_theme_mod( 'newspress_accent_color', '#f07f00' );
    set_theme_mod( 'newspress_layout', 'right-sidebar' );
    set_theme_mod( 'newspress_sticky_sidebar', 1 );
    set_theme_mod( 'newspress_enable_dark_toggle', 1 );
}

function newspress_demo_setup_homepage() {
    if ( ! get_option( 'newspress_home_settings' ) ) {
        update_option( 'newspress_home_settings', array(
            'main_rows'          => 5,
            'posts_per_row'      => 5,
            'show_home_top'      => 0,
            'load_more_min'      => 10,
            'latest_nav_mode'    => 'load_more',
            'row_ad_enabled'     => 1,
        ) );
    }
}


function newspress_demo_get_backup() {
    $backup = get_option( 'newspress_demo_last_backup', array() );
    return is_array( $backup ) ? $backup : array();
}

function newspress_demo_save_backup( $reason = 'manual' ) {
    $payload              = newspress_demo_build_export_payload();
    $payload['backup_at'] = current_time( 'mysql' );
    $payload['reason']    = sanitize_key( $reason );

    update_option( 'newspress_demo_last_backup', $payload, false );

    return $payload;
}

function newspress_demo_restore_backup() {
    $backup = newspress_demo_get_backup();
    if ( empty( $backup ) ) {
        return new WP_Error( 'no_backup', __( 'No NewsPress setup backup is available yet.', 'newspress' ) );
    }

    $validation = newspress_demo_validate_payload( $backup, true );
    if ( is_wp_error( $validation ) ) {
        return $validation;
    }

    $parts = array(
        'categories' => false,
        'posts'      => false,
        'menus'      => true,
        'widgets'    => true,
        'customizer' => true,
        'homepage'   => true,
    );

    return newspress_apply_exported_setup( $backup, $parts );
}

function newspress_demo_download_export() {
    $payload  = newspress_demo_build_export_payload();
    $filename = 'newspress-export-' . gmdate( 'Ymd-His' ) . '.json';

    while ( ob_get_level() ) {
        ob_end_clean();
    }

    nocache_headers();
    header( 'Content-Type: application/json; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
    echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    exit;
}

function newspress_demo_build_export_payload() {
    return array(
        'newspress_export_version' => '1.1',
        'theme'                    => 'newspress',
        'exported_at'              => current_time( 'mysql' ),
        'theme_mods'               => newspress_demo_export_theme_mods(),
        'homepage'                 => array(
            'settings' => get_option( 'newspress_home_settings', array() ),
            'sections' => get_option( 'newspress_home_sections', array() ),
        ),
        'widgets'                  => newspress_demo_export_widgets(),
        'menus'                    => newspress_demo_export_menus(),
    );
}

function newspress_demo_export_theme_mods() {
    $mods   = get_theme_mods();
    $export = array();

    foreach ( (array) $mods as $key => $value ) {
        if ( 0 === strpos( $key, 'newspress_' ) || 'nav_menu_locations' === $key ) {
            $export[ $key ] = $value;
        }
    }

    return $export;
}

function newspress_demo_export_widgets() {
    global $wpdb;

    $sidebars = wp_get_sidebars_widgets();
    $options  = array();
    $bases    = array();

    foreach ( $sidebars as $sidebar_widgets ) {
        if ( ! is_array( $sidebar_widgets ) ) {
            continue;
        }
        foreach ( $sidebar_widgets as $widget_id ) {
            $base = preg_replace( '/-\d+$/', '', $widget_id );
            if ( $base ) {
                $bases[ 'widget_' . $base ] = true;
            }
        }
    }

    $like_options = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'widget\\_%'" );
    foreach ( (array) $like_options as $option_name ) {
        if ( newspress_demo_is_allowed_widget_option( $option_name ) && ( isset( $bases[ $option_name ] ) || 0 === strpos( $option_name, 'widget_newspress_' ) ) ) {
            $options[ $option_name ] = get_option( $option_name );
        }
    }

    return array(
        'sidebars_widgets' => $sidebars,
        'options'          => $options,
    );
}

function newspress_demo_is_allowed_widget_option( $option_name ) {
    if ( ! is_string( $option_name ) ) {
        return false;
    }

    if ( 0 === strpos( $option_name, 'widget_newspress_' ) ) {
        return true;
    }

    return in_array( $option_name, array( 'widget_block', 'widget_text', 'widget_custom_html', 'widget_media_image', 'widget_nav_menu' ), true );
}

function newspress_demo_export_menus() {
    $export    = array( 'locations' => array(), 'menus' => array() );
    $locations = get_nav_menu_locations();

    foreach ( $locations as $location => $menu_id ) {
        $menu = wp_get_nav_menu_object( $menu_id );
        if ( $menu ) {
            $export['locations'][ $location ] = $menu->name;
        }
    }

    foreach ( wp_get_nav_menus() as $menu ) {
        $items = wp_get_nav_menu_items( $menu->term_id );
        $export['menus'][] = array(
            'name'  => $menu->name,
            'items' => array_map( 'newspress_demo_simplify_menu_item', (array) $items ),
        );
    }

    return $export;
}

function newspress_demo_simplify_menu_item( $item ) {
    $object_slug = '';
    if ( 'taxonomy' === $item->type && $item->object && $item->object_id ) {
        $term = get_term( $item->object_id, $item->object );
        if ( $term && ! is_wp_error( $term ) ) {
            $object_slug = $term->slug;
        }
    } elseif ( 'post_type' === $item->type && $item->object_id ) {
        $post = get_post( $item->object_id );
        if ( $post ) {
            $object_slug = $post->post_name;
        }
    }

    return array(
        'db_id'        => absint( $item->db_id ),
        'title'        => $item->title,
        'url'          => $item->url,
        'object'       => $item->object,
        'object_id'    => absint( $item->object_id ),
        'object_slug'  => $object_slug,
        'type'         => $item->type,
        'menu_order'   => absint( $item->menu_order ),
        'parent_db_id' => absint( $item->menu_item_parent ),
        'target'       => $item->target,
        'classes'      => array_values( array_filter( (array) $item->classes ) ),
        'xfn'          => $item->xfn,
        'description'  => $item->description,
    );
}

function newspress_apply_exported_setup( $payload, $parts ) {
    $result = array( 'posts' => 0, 'categories' => 0, 'menus' => 0, 'sidebars' => 0 );

    if ( ! empty( $parts['customizer'] ) && ! empty( $payload['theme_mods'] ) && is_array( $payload['theme_mods'] ) ) {
        foreach ( $payload['theme_mods'] as $key => $value ) {
            $key = sanitize_key( $key );
            if ( 'nav_menu_locations' === $key ) {
                if ( empty( $parts['menus'] ) ) {
                    continue;
                }
                set_theme_mod( $key, array_map( 'absint', (array) $value ) );
                continue;
            }
            if ( 0 !== strpos( $key, 'newspress_' ) ) {
                continue;
            }
            set_theme_mod( $key, newspress_demo_sanitize_import_value( $key, $value ) );
        }
    }

    if ( ! empty( $parts['homepage'] ) && ! empty( $payload['homepage'] ) && is_array( $payload['homepage'] ) ) {
        if ( isset( $payload['homepage']['settings'] ) ) {
            update_option( 'newspress_home_settings', newspress_demo_sanitize_import_value( 'newspress_home_settings', $payload['homepage']['settings'] ) );
        }
        if ( isset( $payload['homepage']['sections'] ) ) {
            update_option( 'newspress_home_sections', newspress_demo_sanitize_import_value( 'newspress_home_sections', $payload['homepage']['sections'] ) );
        }
    }

    if ( ! empty( $parts['widgets'] ) && ! empty( $payload['widgets'] ) && is_array( $payload['widgets'] ) ) {
        $result['sidebars'] = newspress_demo_import_widgets( $payload['widgets'] );
    }

    if ( ! empty( $parts['menus'] ) && ! empty( $payload['menus'] ) && is_array( $payload['menus'] ) ) {
        $result['menus'] = newspress_demo_import_menus( $payload['menus'] );
    }

    return $result;
}

function newspress_demo_sanitize_import_value( $key, $value ) {
    if ( is_array( $value ) ) {
        $clean = array();
        foreach ( $value as $sub_key => $sub_value ) {
            $clean[ sanitize_key( (string) $sub_key ) ] = newspress_demo_sanitize_import_value( $key . '_' . $sub_key, $sub_value );
        }
        return $clean;
    }

    if ( is_bool( $value ) ) {
        return $value;
    }

    if ( is_int( $value ) || is_float( $value ) ) {
        return $value;
    }

    $value = (string) $value;

    if ( false !== strpos( $key, 'footer' ) || false !== strpos( $key, 'html' ) || false !== strpos( $key, 'custom_css' ) ) {
        return wp_kses_post( $value );
    }

    if ( false !== strpos( $key, 'url' ) || false !== strpos( $key, 'link' ) ) {
        return esc_url_raw( $value );
    }

    if ( false !== strpos( $key, 'color' ) ) {
        $hex = sanitize_hex_color( $value );
        return $hex ? $hex : sanitize_text_field( $value );
    }

    return sanitize_text_field( $value );
}

function newspress_demo_import_widgets( $widgets ) {
    $allowed_widget_ids = array();

    if ( ! empty( $widgets['options'] ) && is_array( $widgets['options'] ) ) {
        foreach ( $widgets['options'] as $option_name => $option_value ) {
            $option_name = sanitize_key( $option_name );
            if ( ! newspress_demo_is_allowed_widget_option( $option_name ) ) {
                continue;
            }
            update_option( $option_name, newspress_demo_sanitize_import_value( $option_name, $option_value ) );
            $base = preg_replace( '/^widget_/', '', $option_name );
            if ( is_array( $option_value ) ) {
                foreach ( array_keys( $option_value ) as $number ) {
                    if ( is_numeric( $number ) ) {
                        $allowed_widget_ids[ $base . '-' . absint( $number ) ] = true;
                    }
                }
            }
        }
    }

    $updated = 0;
    if ( ! empty( $widgets['sidebars_widgets'] ) && is_array( $widgets['sidebars_widgets'] ) ) {
        global $wp_registered_sidebars;
        $current  = wp_get_sidebars_widgets();
        $sidebars = $current;

        foreach ( $widgets['sidebars_widgets'] as $sidebar_id => $sidebar_widgets ) {
            $sidebar_id = sanitize_key( $sidebar_id );
            if ( 'wp_inactive_widgets' !== $sidebar_id && empty( $wp_registered_sidebars[ $sidebar_id ] ) ) {
                continue;
            }
            if ( ! is_array( $sidebar_widgets ) ) {
                continue;
            }
            $clean_widgets = array();
            foreach ( $sidebar_widgets as $widget_id ) {
                $widget_id = sanitize_key( $widget_id );
                if ( isset( $allowed_widget_ids[ $widget_id ] ) ) {
                    $clean_widgets[] = $widget_id;
                }
            }
            $sidebars[ $sidebar_id ] = $clean_widgets;
            $updated++;
        }

        wp_set_sidebars_widgets( $sidebars );
    }

    return $updated;
}

function newspress_demo_import_menus( $menus ) {
    $created_menus = array();
    $created_items = 0;

    if ( ! empty( $menus['menus'] ) && is_array( $menus['menus'] ) ) {
        foreach ( $menus['menus'] as $menu_data ) {
            if ( empty( $menu_data['name'] ) ) {
                continue;
            }
            $menu_name = sanitize_text_field( $menu_data['name'] );
            $menu_obj  = wp_get_nav_menu_object( $menu_name );
            $menu_id   = $menu_obj ? $menu_obj->term_id : wp_create_nav_menu( $menu_name );
            if ( is_wp_error( $menu_id ) ) {
                continue;
            }
            $created_menus[ $menu_name ] = $menu_id;

            $existing_items = wp_get_nav_menu_items( $menu_id );
            if ( ! empty( $existing_items ) || empty( $menu_data['items'] ) || ! is_array( $menu_data['items'] ) ) {
                continue;
            }

            $items = $menu_data['items'];
            usort( $items, static function( $a, $b ) {
                return absint( $a['menu_order'] ?? 0 ) <=> absint( $b['menu_order'] ?? 0 );
            } );

            $item_map = array();
            foreach ( $items as $item ) {
                $old_id    = absint( $item['db_id'] ?? 0 );
                $parent_id = absint( $item['parent_db_id'] ?? 0 );
                $args      = newspress_demo_prepare_menu_item_args( $item );

                if ( $parent_id && isset( $item_map[ $parent_id ] ) ) {
                    $args['menu-item-parent-id'] = absint( $item_map[ $parent_id ] );
                }

                $new_id = wp_update_nav_menu_item( $menu_id, 0, $args );
                if ( $new_id && ! is_wp_error( $new_id ) ) {
                    $created_items++;
                    if ( $old_id ) {
                        $item_map[ $old_id ] = $new_id;
                    }
                }
            }
        }
    }

    if ( ! empty( $menus['locations'] ) && is_array( $menus['locations'] ) ) {
        $locations = get_theme_mod( 'nav_menu_locations', array() );
        foreach ( $menus['locations'] as $location => $menu_name ) {
            $location  = sanitize_key( $location );
            $menu_name = sanitize_text_field( $menu_name );
            if ( isset( $created_menus[ $menu_name ] ) ) {
                $locations[ $location ] = absint( $created_menus[ $menu_name ] );
            }
        }
        set_theme_mod( 'nav_menu_locations', $locations );
    }

    return $created_items;
}

function newspress_demo_prepare_menu_item_args( $item ) {
    $title       = sanitize_text_field( $item['title'] ?? '' );
    $type        = sanitize_key( $item['type'] ?? 'custom' );
    $object      = sanitize_key( $item['object'] ?? '' );
    $object_id   = absint( $item['object_id'] ?? 0 );
    $object_slug = sanitize_title( $item['object_slug'] ?? '' );

    if ( 'taxonomy' === $type && $object && $object_slug ) {
        $term = get_term_by( 'slug', $object_slug, $object );
        if ( $term && ! is_wp_error( $term ) ) {
            $object_id = absint( $term->term_id );
        }
    }

    if ( 'post_type' === $type && $object && $object_slug ) {
        $post = get_page_by_path( $object_slug, OBJECT, $object );
        if ( $post ) {
            $object_id = absint( $post->ID );
        }
    }

    $args = array(
        'menu-item-title'       => $title,
        'menu-item-status'      => 'publish',
        'menu-item-position'    => absint( $item['menu_order'] ?? 0 ),
        'menu-item-target'      => sanitize_key( $item['target'] ?? '' ),
        'menu-item-classes'     => implode( ' ', array_map( 'sanitize_html_class', (array) ( $item['classes'] ?? array() ) ) ),
        'menu-item-xfn'         => sanitize_text_field( $item['xfn'] ?? '' ),
        'menu-item-description' => sanitize_text_field( $item['description'] ?? '' ),
    );

    if ( in_array( $type, array( 'taxonomy', 'post_type' ), true ) && $object && $object_id ) {
        $args['menu-item-type']      = $type;
        $args['menu-item-object']    = $object;
        $args['menu-item-object-id'] = $object_id;
    } else {
        $args['menu-item-type'] = 'custom';
        $args['menu-item-url']  = esc_url_raw( $item['url'] ?? home_url( '/' ) );
    }

    return $args;
}

function newspress_reset_demo_import_flag() {
    delete_option( 'newspress_demo_imported' );
}
