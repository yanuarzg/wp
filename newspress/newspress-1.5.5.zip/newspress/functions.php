<?php
/**
 * NewsPress functions and definitions.
 *
 * @package NewsPress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'NEWSPRESS_VERSION', '1.5.5' );
define( 'NEWSPRESS_DIR', get_template_directory() );
define( 'NEWSPRESS_URI', get_template_directory_uri() );

require_once NEWSPRESS_DIR . '/inc/setup.php';
require_once NEWSPRESS_DIR . '/inc/enqueue.php';
require_once NEWSPRESS_DIR . '/inc/template-tags.php';
require_once NEWSPRESS_DIR . '/inc/front-page-helpers.php';
require_once NEWSPRESS_DIR . '/inc/customizer.php';
require_once NEWSPRESS_DIR . '/inc/widgets.php';
require_once NEWSPRESS_DIR . '/inc/homepage-builder.php';
require_once NEWSPRESS_DIR . '/inc/post-meta.php';
require_once NEWSPRESS_DIR . '/inc/schema.php';
require_once NEWSPRESS_DIR . '/inc/seo.php';
require_once NEWSPRESS_DIR . '/inc/license.php';
require_once NEWSPRESS_DIR . '/inc/theme-updater.php';

require_once NEWSPRESS_DIR . '/inc/performance.php';
require_once NEWSPRESS_DIR . '/inc/demo-import.php';
require_once NEWSPRESS_DIR . '/inc/author-fields.php';
