<?php
/** Template helper functions. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function newspress_get_date_format() {
    $format = trim( (string) get_theme_mod( 'newspress_single_date_format', 'l, d F Y | H:i \\W\\I\\B' ) );
    return '' !== $format ? $format : 'l, d F Y | H:i \\W\\I\\B';
}

function newspress_get_date_display_mode() {
    $mode = get_theme_mod( 'newspress_date_display_mode', 'format' );
    return in_array( $mode, array( 'format', 'ago' ), true ) ? $mode : 'format';
}

function newspress_format_datetime( $timestamp ) {
    $timestamp = absint( $timestamp );
    if ( ! $timestamp ) {
        return '';
    }

    if ( 'ago' === newspress_get_date_display_mode() ) {
        return sprintf(
            /* translators: %s: human readable time difference. */
            __( '%s ago', 'newspress' ),
            human_time_diff( $timestamp, current_time( 'timestamp' ) )
        );
    }

    return date_i18n( newspress_get_date_format(), $timestamp );
}

function newspress_get_post_date_text( $post_id = null, $type = 'published' ) {
    $post_id   = $post_id ? absint( $post_id ) : get_the_ID();
    $timestamp = 'modified' === $type ? get_post_modified_time( 'U', false, $post_id ) : get_post_time( 'U', false, $post_id );

    return newspress_format_datetime( $timestamp );
}

function newspress_posted_on( $context = 'archive' ) {
    $timestamp = get_the_time( 'U' );
    $display   = newspress_format_datetime( $timestamp );
    $class     = 'single' === $context && get_theme_mod( 'newspress_show_single_updated_date', 0 ) ? 'entry-date published' : 'entry-date published updated';

    printf(
        '<span class="posted-on"><time class="%1$s" datetime="%2$s">%3$s</time></span>',
        esc_attr( $class ),
        esc_attr( get_the_date( DATE_W3C ) ),
        esc_html( $display )
    );
}

function newspress_updated_on() {
    $published = absint( get_the_time( 'U' ) );
    $updated   = absint( get_the_modified_time( 'U' ) );

    if ( ! $updated || $updated <= $published + MINUTE_IN_SECONDS ) {
        return;
    }

    printf(
        '<span class="updated-on"><span class="np-meta-label">%1$s</span> <time class="updated" datetime="%2$s">%3$s</time></span>',
        esc_html__( 'Update', 'newspress' ),
        esc_attr( get_the_modified_date( DATE_W3C ) ),
        esc_html( newspress_format_datetime( $updated ) )
    );
}

function newspress_single_entry_meta() {
    $items = array();

    ob_start();
    newspress_posted_by();
    $items[] = ob_get_clean();

    if ( get_theme_mod( 'newspress_show_single_published_date', 1 ) ) {
        ob_start();
        newspress_posted_on( 'single' );
        $published_html = ob_get_clean();
        if ( $published_html ) {
            $items[] = $published_html;
        }
    }

    if ( get_theme_mod( 'newspress_show_single_updated_date', 0 ) ) {
        ob_start();
        newspress_updated_on();
        $updated_html = ob_get_clean();
        if ( $updated_html ) {
            $items[] = $updated_html;
        }
    }

    $items[] = esc_html( newspress_reading_time() );

    $views_html = newspress_get_post_views_html();
    if ( $views_html ) {
        $items[] = $views_html;
    }

    echo implode( ' <span class="np-meta-sep">/</span> ', array_filter( $items ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_posted_by() {
    printf(
        '<span class="byline"><span class="np-meta-label">%s</span> <a class="url fn n" href="%s">%s</a></span>',
        esc_html__( 'Penulis', 'newspress' ),
        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
        esc_html( get_the_author() )
    );
}

function newspress_reading_time( $post_id = null ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    $content = wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $post_id ) ) );

    if ( function_exists( 'mb_strlen' ) ) {
        preg_match_all( '/[\p{L}\p{N}]+/u', $content, $matches );
        $words = ! empty( $matches[0] ) ? count( $matches[0] ) : 0;
    } else {
        $words = str_word_count( $content );
    }

    $minutes = max( 1, (int) ceil( $words / 250 ) );
    return sprintf( _n( '%s min read', '%s min read', $minutes, 'newspress' ), number_format_i18n( $minutes ) );
}

function newspress_get_post_views_count( $post_id = null, $range = 'all' ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return 0;
    }

    $range = sanitize_key( $range );
    $key   = '_newspress_views_total';

    if ( function_exists( 'newspress_views_keys' ) ) {
        $keys = newspress_views_keys();
        if ( isset( $keys[ $range ] ) ) {
            $key = $keys[ $range ];
        }
    }

    return max( 0, absint( get_post_meta( $post_id, $key, true ) ) );
}

function newspress_get_post_shares_count( $post_id = null ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return 0;
    }

    return max( 0, absint( get_post_meta( $post_id, '_newspress_shares_total', true ) ) );
}

function newspress_get_post_views_html( $post_id = null ) {
    if ( ! get_theme_mod( 'newspress_show_single_views', 1 ) ) {
        return '';
    }

    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $views = newspress_get_post_views_count( $post_id, 'all' );
    $label = trim( (string) get_theme_mod( 'newspress_single_views_label', __( 'Dilihat', 'newspress' ) ) );
    $label = '' !== $label ? $label : __( 'Dilihat', 'newspress' );

    return sprintf(
        '<span class="np-post-views"><span class="np-post-views-count">%1$s</span> <span class="np-post-views-label">%2$s</span></span>',
        esc_html( number_format_i18n( $views ) ),
        esc_html( $label )
    );
}

function newspress_post_views() {
    echo newspress_get_post_views_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function newspress_excerpt( $words = 20 ) {
    return esc_html( wp_trim_words( get_the_excerpt(), $words, '...' ) );
}

function newspress_card_context() {
    $context = get_query_var( 'newspress_card_context' );
    $context = is_string( $context ) ? sanitize_key( $context ) : 'latest';
    return in_array( $context, array( 'latest', 'related', 'archive' ), true ) ? $context : 'latest';
}

function newspress_card_context_key( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    return 'related' === $context ? 'newspress_related_' : 'newspress_home_latest_';
}

function newspress_card_layout( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    $default = 'related' === $context ? 'grid' : 'list';
    $layout  = get_theme_mod( newspress_card_context_key( $context ) . 'layout', $default );
    return in_array( $layout, array( 'list', 'grid' ), true ) ? $layout : $default;
}

function newspress_card_show( $part, $context = '' ) {
    $part = sanitize_key( $part );
    if ( ! in_array( $part, array( 'thumb', 'snippet', 'meta', 'category' ), true ) ) {
        return true;
    }
    return (bool) get_theme_mod( newspress_card_context_key( $context ) . 'show_' . $part, 1 );
}

function newspress_card_container_classes( $context = '' ) {
    $context = $context ? sanitize_key( $context ) : newspress_card_context();
    $classes = array(
        'np-card-list',
        'np-card-context-' . $context,
        'np-card-layout-' . newspress_card_layout( $context ),
    );
    foreach ( array( 'thumb', 'snippet', 'meta', 'category' ) as $part ) {
        $classes[] = newspress_card_show( $part, $context ) ? 'has-' . $part : 'hide-' . $part;
    }
    return implode( ' ', array_map( 'sanitize_html_class', $classes ) );
}

function newspress_get_trending_terms( $limit = 7, $taxonomy = '', $range = '' ) {
    $limit    = min( 20, max( 1, absint( $limit ) ) );
    $taxonomy = in_array( $taxonomy, array( 'post_tag', 'category' ), true ) ? $taxonomy : get_theme_mod( 'newspress_trending_source', 'post_tag' );
    $taxonomy = in_array( $taxonomy, array( 'post_tag', 'category' ), true ) ? $taxonomy : 'post_tag';
    $range    = in_array( $range, array( 'all', 'today', '7days', '30days' ), true ) ? $range : get_theme_mod( 'newspress_trending_range', '7days' );
    $range    = in_array( $range, array( 'all', 'today', '7days', '30days' ), true ) ? $range : '7days';
    $cache_key = 'newspress_trending_' . sanitize_key( $taxonomy ) . '_' . sanitize_key( $range ) . '_' . $limit;
    $terms = get_transient( $cache_key );

    if ( false !== $terms ) {
        return is_array( $terms ) ? $terms : array();
    }

    if ( 'all' === $range ) {
        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'number'     => $limit,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'hide_empty' => true,
        ) );
        $terms = is_wp_error( $terms ) ? array() : $terms;
        set_transient( $cache_key, $terms, 30 * MINUTE_IN_SECONDS );
        return $terms;
    }

    $after = 'today' === $range ? '1 day ago' : ( '30days' === $range ? '30 days ago' : '7 days ago' );
    $query = new WP_Query( array(
        'post_type'              => 'post',
        'post_status'            => 'publish',
        'posts_per_page'         => 200,
        'fields'                 => 'ids',
        'ignore_sticky_posts'    => true,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'date_query'             => array(
            array(
                'after'     => $after,
                'inclusive' => true,
            ),
        ),
    ) );

    $term_counts = array();
    foreach ( $query->posts as $post_id ) {
        $post_terms = wp_get_post_terms( $post_id, $taxonomy );
        if ( is_wp_error( $post_terms ) || empty( $post_terms ) ) {
            continue;
        }
        foreach ( $post_terms as $term ) {
            $term_id = absint( $term->term_id );
            if ( ! isset( $term_counts[ $term_id ] ) ) {
                $term_counts[ $term_id ] = array( 'term' => $term, 'count' => 0 );
            }
            $term_counts[ $term_id ]['count']++;
        }
    }

    uasort( $term_counts, function( $a, $b ) {
        if ( $a['count'] === $b['count'] ) {
            return strcasecmp( $a['term']->name, $b['term']->name );
        }
        return $b['count'] <=> $a['count'];
    } );

    $terms = array_map( function( $item ) {
        return $item['term'];
    }, array_slice( $term_counts, 0, $limit ) );

    if ( empty( $terms ) ) {
        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'number'     => $limit,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'hide_empty' => true,
        ) );
        $terms = is_wp_error( $terms ) ? array() : $terms;
    }

    set_transient( $cache_key, $terms, 30 * MINUTE_IN_SECONDS );
    return is_array( $terms ) ? $terms : array();
}

function newspress_get_trending_tags( $limit = 5 ) {
    return newspress_get_trending_terms( $limit, 'post_tag' );
}

function newspress_flush_trending_tags_cache() {
    for ( $i = 1; $i <= 20; $i++ ) {
        delete_transient( 'newspress_trending_tags_' . $i );
        foreach ( array( 'post_tag', 'category' ) as $taxonomy ) {
            foreach ( array( 'all', 'today', '7days', '30days' ) as $range ) {
                delete_transient( 'newspress_trending_' . $taxonomy . '_' . $range . '_' . $i );
            }
        }
    }
}
add_action( 'created_term', 'newspress_flush_trending_tags_cache' );
add_action( 'edited_term', 'newspress_flush_trending_tags_cache' );
add_action( 'delete_term', 'newspress_flush_trending_tags_cache' );
add_action( 'save_post_post', 'newspress_flush_trending_tags_cache' );
add_action( 'trashed_post', 'newspress_flush_trending_tags_cache' );
add_action( 'deleted_post', 'newspress_flush_trending_tags_cache' );

function newspress_flush_author_post_count_cache( $post_id ) {
    $post = get_post( $post_id );
    if ( $post && ! empty( $post->post_author ) ) {
        delete_transient( 'newspress_author_posts_' . absint( $post->post_author ) );
    }
}
add_action( 'save_post_post', 'newspress_flush_author_post_count_cache' );
add_action( 'trashed_post', 'newspress_flush_author_post_count_cache' );
add_action( 'deleted_post', 'newspress_flush_author_post_count_cache' );

function newspress_thumbnail( $size = 'newspress-card', $class = '', $attr = array() ) {
    if ( has_post_thumbnail() ) {
        $defaults = array(
            'class'    => trim( 'np-img ' . $class ),
            'loading'  => 'lazy',
            'decoding' => 'async',
        );
        $attr = wp_parse_args( $attr, $defaults );
        $attr['class'] = esc_attr( $attr['class'] );
        the_post_thumbnail( $size, $attr );
    } else {
        echo '<div class="np-img np-img-placeholder ' . esc_attr( $class ) . '">' . esc_html__( 'No Image', 'newspress' ) . '</div>';
    }
}

function newspress_breadcrumbs() {
    if ( is_front_page() ) { return; }
    echo '<nav class="np-breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'newspress' ) . '</a>';
    if ( is_category() || is_single() ) {
        $cat = get_the_category();
        if ( ! empty( $cat ) ) {
            echo '<span>/</span><a href="' . esc_url( get_category_link( $cat[0]->term_id ) ) . '">' . esc_html( $cat[0]->name ) . '</a>';
        }
        // Intentionally hide the current article title to keep breadcrumbs compact.
    } elseif ( is_page() ) {
        echo '<span>/</span><span>' . esc_html( get_the_title() ) . '</span>';
    } elseif ( is_search() ) {
        echo '<span>/</span><span>' . esc_html__( 'Search', 'newspress' ) . '</span>';
    }
    echo '</nav>';
}

function newspress_ads_should_display() {
    return ! ( is_user_logged_in() && get_theme_mod( 'newspress_ad_hide_logged_in', 0 ) );
}

function newspress_ad_label_text() {
    $label = get_theme_mod( 'newspress_ad_label', __( 'Advertisement', 'newspress' ) );
    return $label ? $label : __( 'Advertisement', 'newspress' );
}

function newspress_ad_slot( $key ) {
    if ( ! newspress_ads_should_display() ) { return; }
    $html = trim( (string) get_theme_mod( 'newspress_ad_' . $key, '' ) );
    if ( '' === $html ) {
        return;
    }
    echo '<div class="np-ad np-ad-' . esc_attr( $key ) . '">' . newspress_get_safe_ad_code( $html ) . '</div>';
}

function newspress_get_article_ad_markup( $key, $widget_area, $dummy_label ) {
    if ( ! newspress_ads_should_display() ) { return ''; }
    if ( is_active_sidebar( $widget_area ) ) {
        ob_start();
        dynamic_sidebar( $widget_area );
        $widgets = trim( ob_get_clean() );
        if ( $widgets ) {
            return '<div class="np-article-ad-widget np-article-ad-' . esc_attr( $key ) . '">' . $widgets . '</div>';
        }
    }

    $html = trim( (string) get_theme_mod( 'newspress_ad_' . $key, '' ) );

    if ( ! $html && 'article_middle' === $key ) {
        $html = trim( (string) get_theme_mod( 'newspress_ad_inarticle', '' ) );
    }

    if ( $html ) {
        return '<div class="np-ad np-ad-inarticle np-ad-' . esc_attr( $key ) . '">' . newspress_get_safe_ad_code( $html ) . '</div>';
    }

    return '';
}

function newspress_insert_article_ads( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || is_preview() ) {
        return $content;
    }

    $before = newspress_get_article_ad_markup( 'article_before', 'article-ad-before', 'Advertisement before article' );
    $middle = newspress_get_article_ad_markup( 'article_middle', 'article-ad-middle', 'Advertisement' );
    $after  = newspress_get_article_ad_markup( 'article_after', 'article-ad-after', 'Advertisement after article' );

    if ( false === stripos( $content, '</p>' ) ) {
        return $before . $content . $middle . $after;
    }

    $paragraphs = explode( '</p>', $content );
    $rebuilt = array();
    $paragraph_count = 0;
    $middle_inserted = false;

    foreach ( $paragraphs as $paragraph ) {
        if ( '' === trim( $paragraph ) ) {
            continue;
        }
        $rebuilt[] = $paragraph . '</p>';
        $paragraph_count++;
    }

    if ( empty( $rebuilt ) ) {
        return $before . $content . $middle . $after;
    }

    $middle_at = max( 1, min( count( $rebuilt ), absint( get_theme_mod( 'newspress_ad_middle_paragraph', 4 ) ) ) );
    $output = $before;

    foreach ( $rebuilt as $index => $paragraph ) {
        $output .= $paragraph;
        if ( ! $middle_inserted && ( $index + 1 ) === $middle_at ) {
            $output .= $middle;
            $middle_inserted = true;
        }
    }

    $output .= $after;

    return $output;
}

function newspress_slugify_heading_id( $text, $fallback ) {
    $slug = sanitize_title( wp_strip_all_tags( $text ) );
    return $slug ? $slug : 'section-' . absint( $fallback );
}

function newspress_add_table_of_contents( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( defined( 'NEWSPRESS_DISABLE_TOC_KEY' ) && get_post_meta( get_the_ID(), NEWSPRESS_DISABLE_TOC_KEY, true ) ) {
        return $content;
    }
    if ( ! preg_match_all( '/<h([2-6])([^>]*)>(.*?)<\/h\1>/is', $content, $matches, PREG_SET_ORDER ) || count( $matches ) < 2 ) {
        return $content;
    }

    $items    = array();
    $used_ids = array();
    $counts   = array( 2 => 0, 3 => 0, 4 => 0, 5 => 0 );
    $i        = 0;

    $content = preg_replace_callback( '/<h([2-6])([^>]*)>(.*?)<\/h\1>/is', function( $m ) use ( &$items, &$used_ids, &$counts, &$i ) {
        $i++;
        $level = absint( $m[1] );
        $attrs = $m[2];
        $inner = $m[3];
        $text  = trim( wp_strip_all_tags( $inner ) );

        if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $attrs, $id_match ) ) {
            $id = sanitize_title( $id_match[1] );
        } else {
            $id   = newspress_slugify_heading_id( $text, $i );
            $base = $id;
            $n    = 2;
            while ( in_array( $id, $used_ids, true ) ) {
                $id = $base . '-' . $n;
                $n++;
            }
            $attrs .= ' id="' . esc_attr( $id ) . '"';
        }

        $used_ids[] = $id;

        if ( $level >= 2 && $level <= 5 ) {
            for ( $parent = 2; $parent < $level; $parent++ ) {
                if ( empty( $counts[ $parent ] ) ) {
                    $counts[ $parent ] = 1;
                }
            }
            $counts[ $level ]++;
            for ( $child = $level + 1; $child <= 5; $child++ ) {
                $counts[ $child ] = 0;
            }
            $parts = array();
            for ( $n_level = 2; $n_level <= $level; $n_level++ ) {
                if ( ! empty( $counts[ $n_level ] ) ) {
                    $parts[] = $counts[ $n_level ];
                }
            }
            $marker = implode( '.', $parts ) . '.';
        } else {
            $marker = '-';
        }

        $items[] = array(
            'id'     => $id,
            'text'   => $text,
            'level'  => $level,
            'marker' => $marker,
        );

        return '<h' . $level . $attrs . '>' . $inner . '</h' . $level . '>';
    }, $content );

    if ( count( $items ) < 2 ) {
        return $content;
    }

    $toc = '<nav class="np-toc" aria-label="' . esc_attr__( 'Table of contents', 'newspress' ) . '"><button class="np-toc-toggle" type="button" aria-expanded="true">' . esc_html__( 'Daftar Isi', 'newspress' ) . '</button><ol class="np-toc-list">';
    foreach ( $items as $item ) {
        $toc .= '<li class="np-toc-level-' . absint( $item['level'] ) . '"><a href="#' . esc_attr( $item['id'] ) . '"><span class="np-toc-marker" aria-hidden="true">' . esc_html( $item['marker'] ) . '</span><span class="np-toc-text">' . esc_html( $item['text'] ) . '</span></a></li>';
    }
    $toc .= '</ol></nav>';

    return $toc . $content;
}

function newspress_svg_icon( $name, $size = 20 ) {
    $size = absint( $size );
    $icons = array(
        // All inline SVG icon paths in NewsPress are sourced from RemixIcon (Apache-2.0).
        'search' => '<path d="M18.031 16.6168L22.3137 20.8995L20.8995 22.3137L16.6168 18.031C15.0769 19.263 13.124 20 11 20C6.032 20 2 15.968 2 11C2 6.032 6.032 2 11 2C15.968 2 20 6.032 20 11C20 13.124 19.263 15.0769 18.031 16.6168ZM16.0247 15.8748C17.2475 14.6146 18 12.8956 18 11C18 7.1325 14.8675 4 11 4C7.1325 4 4 7.1325 4 11C4 14.8675 7.1325 18 11 18C12.8956 18 14.6146 17.2475 15.8748 16.0247L16.0247 15.8748Z"/>',
        'menu' => '<path d="M3 4H21V6H3V4ZM3 11H21V13H3V11ZM3 18H21V20H3V18Z"/>',
        'facebook' => '<path d="M14 13.5H16.5L17.5 9.5H14V7.5C14 6.47062 14 5.5 16 5.5H17.5V2.1401C17.1743 2.09685 15.943 2 14.6429 2C11.9284 2 10 3.65686 10 6.69971V9.5H7V13.5H10V22H14V13.5Z"/>',
        'x' => '<path d="M17.6874 3.0625L12.6907 8.77425L8.37045 3.0625H2.11328L9.58961 12.8387L2.50378 20.9375H5.53795L11.0068 14.6886L15.7863 20.9375H21.8885L14.095 10.6342L20.7198 3.0625H17.6874ZM16.6232 19.1225L5.65436 4.78217H7.45745L18.3034 19.1225H16.6232Z"/>',
        'whatsapp' => '<path d="M12.001 2C17.5238 2 22.001 6.47715 22.001 12C22.001 17.5228 17.5238 22 12.001 22C10.1671 22 8.44851 21.5064 6.97086 20.6447L2.00516 22L3.35712 17.0315C2.49494 15.5536 2.00098 13.8345 2.00098 12C2.00098 6.47715 6.47813 2 12.001 2ZM8.59339 7.30019L8.39232 7.30833C8.26293 7.31742 8.13607 7.34902 8.02057 7.40811C7.93392 7.45244 7.85348 7.51651 7.72709 7.63586C7.60774 7.74855 7.53857 7.84697 7.46569 7.94186C7.09599 8.4232 6.89729 9.01405 6.90098 9.62098C6.90299 10.1116 7.03043 10.5884 7.23169 11.0336C7.63982 11.9364 8.31288 12.8908 9.20194 13.7759C9.4155 13.9885 9.62473 14.2034 9.85034 14.402C10.9538 15.3736 12.2688 16.0742 13.6907 16.4482C13.6907 16.4482 14.2507 16.5342 14.2589 16.5347C14.4444 16.5447 14.6296 16.5313 14.8153 16.5218C15.1066 16.5068 15.391 16.428 15.6484 16.2909C15.8139 16.2028 15.8922 16.159 16.0311 16.0714C16.0311 16.0714 16.0737 16.0426 16.1559 15.9814C16.2909 15.8808 16.3743 15.81 16.4866 15.6934C16.5694 15.6074 16.6406 15.5058 16.6956 15.3913C16.7738 15.2281 16.8525 14.9166 16.8838 14.6579C16.9077 14.4603 16.9005 14.3523 16.8979 14.2854C16.8936 14.1778 16.8047 14.0671 16.7073 14.0201L16.1258 13.7587C16.1258 13.7587 15.2563 13.3803 14.7245 13.1377C14.6691 13.1124 14.6085 13.1007 14.5476 13.097C14.4142 13.0888 14.2647 13.1236 14.1696 13.2238C14.1646 13.2218 14.0984 13.279 13.3749 14.1555C13.335 14.2032 13.2415 14.3069 13.0798 14.2972C13.0554 14.2955 13.0311 14.292 13.0074 14.2858C12.9419 14.2685 12.8781 14.2457 12.8157 14.2193C12.692 14.1668 12.6486 14.1469 12.5641 14.1105C11.9868 13.8583 11.457 13.5209 10.9887 13.108C10.8631 12.9974 10.7463 12.8783 10.6259 12.7616C10.2057 12.3543 9.86169 11.9211 9.60577 11.4938C9.5918 11.4705 9.57027 11.4368 9.54708 11.3991C9.50521 11.331 9.45903 11.25 9.44455 11.1944C9.40738 11.0473 9.50599 10.9291 9.50599 10.9291C9.50599 10.9291 9.74939 10.663 9.86248 10.5183C9.97128 10.379 10.0652 10.2428 10.125 10.1457C10.2428 9.95633 10.2801 9.76062 10.2182 9.60963C9.93764 8.92565 9.64818 8.24536 9.34986 7.56894C9.29098 7.43545 9.11585 7.33846 8.95659 7.32007C8.90265 7.31384 8.84875 7.30758 8.79459 7.30402C8.66053 7.29748 8.5262 7.29892 8.39232 7.30833L8.59339 7.30019Z"/>',
        'link' => '<path d="M18.3638 15.5355L16.9496 14.1213L18.3638 12.7071C20.3164 10.7545 20.3164 7.58866 18.3638 5.63604C16.4112 3.68341 13.2453 3.68341 11.2927 5.63604L9.87849 7.05025L8.46428 5.63604L9.87849 4.22182C12.6122 1.48815 17.0443 1.48815 19.778 4.22182C22.5117 6.95549 22.5117 11.3876 19.778 14.1213L18.3638 15.5355ZM15.5353 18.364L14.1211 19.7782C11.3875 22.5118 6.95531 22.5118 4.22164 19.7782C1.48797 17.0445 1.48797 12.6123 4.22164 9.87868L5.63585 8.46446L7.05007 9.87868L5.63585 11.2929C3.68323 13.2455 3.68323 16.4113 5.63585 18.364C7.58847 20.3166 10.7543 20.3166 12.7069 18.364L14.1211 16.9497L15.5353 18.364ZM14.8282 7.75736L16.2425 9.17157L9.17139 16.2426L7.75717 14.8284L14.8282 7.75736Z"/>',
        'share' => '<path d="M13.1202 17.0228L8.92129 14.7324C8.19135 15.5125 7.15261 16 6 16C3.79086 16 2 14.2091 2 12C2 9.79086 3.79086 8 6 8C7.15255 8 8.19125 8.48746 8.92118 9.26746L13.1202 6.97713C13.0417 6.66441 13 6.33707 13 6C13 3.79086 14.7909 2 17 2C19.2091 2 21 3.79086 21 6C21 8.20914 19.2091 10 17 10C15.8474 10 14.8087 9.51251 14.0787 8.73246L9.87977 11.0228C9.9583 11.3355 10 11.6629 10 12C10 12.3371 9.95831 12.6644 9.87981 12.9771L14.0788 15.2675C14.8087 14.4875 15.8474 14 17 14C19.2091 14 21 15.7909 21 18C21 20.2091 19.2091 22 17 22C14.7909 22 13 20.2091 13 18C13 17.6629 13.0417 17.3355 13.1202 17.0228ZM6 14C7.10457 14 8 13.1046 8 12C8 10.8954 7.10457 10 6 10C4.89543 10 4 10.8954 4 12C4 13.1046 4.89543 14 6 14ZM17 8C18.1046 8 19 7.10457 19 6C19 4.89543 18.1046 4 17 4C15.8954 4 15 4.89543 15 6C15 7.10457 15.8954 8 17 8ZM17 20C18.1046 20 19 19.1046 19 18C19 16.8954 18.1046 16 17 16C15.8954 16 15 16.8954 15 18C15 19.1046 15.8954 20 17 20Z"/>',
        'telegram' => '<path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM12.3584 9.38246C11.3857 9.78702 9.4418 10.6244 6.5266 11.8945C6.05321 12.0827 5.80524 12.2669 5.78266 12.4469C5.74451 12.7513 6.12561 12.8711 6.64458 13.0343C6.71517 13.0565 6.78832 13.0795 6.8633 13.1039C7.37388 13.2698 8.06071 13.464 8.41776 13.4717C8.74164 13.4787 9.10313 13.3452 9.50222 13.0711C12.226 11.2325 13.632 10.3032 13.7203 10.2832C13.7826 10.269 13.8689 10.2513 13.9273 10.3032C13.9858 10.3552 13.98 10.4536 13.9739 10.48C13.9361 10.641 12.4401 12.0318 11.666 12.7515C11.4351 12.9661 11.2101 13.1853 10.9833 13.4039C10.509 13.8611 10.1533 14.204 11.003 14.764C11.8644 15.3317 12.7323 15.8982 13.5724 16.4971C13.9867 16.7925 14.359 17.0579 14.8188 17.0156C15.0861 16.991 15.3621 16.7397 15.5022 15.9903C15.8335 14.2193 16.4847 10.3821 16.6352 8.80083C16.6484 8.6623 16.6318 8.485 16.6185 8.40717C16.6052 8.32934 16.5773 8.21844 16.4762 8.13635C16.3563 8.03913 16.1714 8.01863 16.0887 8.02009C15.7125 8.02672 15.1355 8.22737 12.3584 9.38246Z"/>',
        'line' => '<path d="M18.6635 10.8404C18.6635 11.1279 18.4293 11.3654 18.1385 11.3654H16.676V12.3029H18.1385C18.4293 12.3029 18.6635 12.5387 18.6635 12.8279C18.6635 13.1145 18.4293 13.352 18.1385 13.352H16.1501C15.8626 13.352 15.6276 13.1145 15.6276 12.8279V8.85202C15.6276 8.56452 15.8626 8.32702 16.1526 8.32702H18.141C18.4293 8.32702 18.6635 8.56452 18.6635 8.85202C18.6635 9.14286 18.4293 9.37702 18.1385 9.37702H16.676V10.3145H18.1385C18.4293 10.3145 18.6635 10.552 18.6635 10.8404ZM14.566 13.3245C14.5126 13.342 14.4551 13.3504 14.4001 13.3504C14.2243 13.3504 14.0743 13.2754 13.9751 13.142L11.9393 10.3779V12.8279C11.9393 13.1145 11.7068 13.352 11.4135 13.352C11.1251 13.352 10.8918 13.1145 10.8918 12.8279V8.85202C10.8918 8.62702 11.036 8.42702 11.2501 8.35619C11.3001 8.33702 11.3635 8.32869 11.4118 8.32869C11.5743 8.32869 11.7243 8.41536 11.8243 8.54036L13.876 11.3154V8.85202C13.876 8.56452 14.111 8.32702 14.401 8.32702C14.6885 8.32702 14.926 8.56452 14.926 8.85202V12.8279C14.926 13.0529 14.781 13.2529 14.566 13.3245ZM9.61598 13.352C9.32848 13.352 9.09348 13.1145 9.09348 12.8279V8.85202C9.09348 8.56452 9.32848 8.32702 9.61848 8.32702C9.90681 8.32702 10.1418 8.56452 10.1418 8.85202V12.8279C10.1418 13.1145 9.90681 13.352 9.61598 13.352ZM8.08681 13.352H6.09848C5.81098 13.352 5.57348 13.1145 5.57348 12.8279V8.85202C5.57348 8.56452 5.81098 8.32702 6.09848 8.32702C6.38848 8.32702 6.62348 8.56452 6.62348 8.85202V12.3029H8.08681C8.37681 12.3029 8.61098 12.5387 8.61098 12.8279C8.61098 13.1145 8.37598 13.352 8.08681 13.352ZM12.001 2.57202C6.48848 2.57202 2.00098 6.21452 2.00098 10.6904C2.00098 14.6995 5.55931 18.0587 10.3635 18.697C10.6893 18.7654 11.1326 18.912 11.2451 19.1887C11.3451 19.4395 11.311 19.827 11.2768 20.0887L11.1401 20.9387C11.1026 21.1895 10.9401 21.927 12.0143 21.4762C13.0901 21.027 17.7776 18.0779 19.8776 15.6637C21.3143 14.0895 22.001 12.477 22.001 10.6904C22.001 6.21452 17.5135 2.57202 12.001 2.57202Z"/>',
        'linkedin' => '<path d="M6.94048 4.99993C6.94011 5.81424 6.44608 6.54702 5.69134 6.85273C4.9366 7.15845 4.07187 6.97605 3.5049 6.39155C2.93793 5.80704 2.78195 4.93715 3.1105 4.19207C3.43906 3.44699 4.18654 2.9755 5.00048 2.99993C6.08155 3.03238 6.94097 3.91837 6.94048 4.99993ZM7.00048 8.47993H3.00048V20.9999H7.00048V8.47993ZM13.3205 8.47993H9.34048V20.9999H13.2805V14.4299C13.2805 10.7699 18.0505 10.4299 18.0505 14.4299V20.9999H22.0005V13.0699C22.0005 6.89993 14.9405 7.12993 13.2805 10.1599L13.3205 8.47993Z"/>',
        'pinterest' => '<path d="M13.3717 2.09442C8.42512 1.41268 3.73383 4.48505 2.38064 9.29256C1.02745 14.1001 3.42711 19.1692 8.00271 21.1689C7.94264 20.4008 7.99735 19.628 8.16502 18.8761C8.34964 18.0374 9.46121 13.4132 9.46121 13.4132C9.23971 12.9173 9.12893 12.379 9.13659 11.8359C9.13659 10.3509 9.99353 9.24295 11.0597 9.24295C11.4472 9.23718 11.8181 9.40028 12.0758 9.68981C12.3335 9.97934 12.4526 10.3667 12.402 10.751C12.402 11.6512 11.8236 13.0131 11.5228 14.2903C11.4014 14.7656 11.5131 15.2703 11.8237 15.65C12.1343 16.0296 12.6069 16.2389 13.0967 16.2139C14.9944 16.2139 16.2675 13.7825 16.2675 10.9126C16.2675 8.71205 14.8098 7.0655 12.1243 7.0655C10.826 7.01531 9.56388 7.4996 8.63223 8.40543C7.70057 9.31126 7.18084 10.5595 7.19423 11.859C7.16563 12.5722 7.39566 13.2717 7.84194 13.8287C8.01361 13.9564 8.07985 14.1825 8.00425 14.3827C7.9581 14.5673 7.84194 15.0059 7.79578 15.1675C7.77632 15.278 7.70559 15.3728 7.60516 15.4228C7.50473 15.4729 7.38651 15.4724 7.28654 15.4214C5.9019 14.8674 5.24957 13.3439 5.24957 11.6051C5.24957 8.75822 7.63424 5.3497 12.4036 5.3497C16.1998 5.3497 18.723 8.1273 18.723 11.0972C18.723 15.0059 16.5468 17.9451 13.3298 17.9451C12.3526 17.9761 11.4273 17.5061 10.8759 16.6986C10.8759 16.6986 10.2974 19.0146 10.1835 19.4531C9.95101 20.2099 9.60779 20.9281 9.16505 21.5844C10.0877 21.8643 11.0471 22.0044 12.0113 22C14.6636 22.0017 17.2078 20.9484 19.0829 19.072C20.958 17.1957 22.0099 14.6504 22.0069 11.9975C22.004 7.00306 18.3183 2.77616 13.3717 2.09442Z"/>',
        'bluesky' => '<path d="M12 11.3884C11.0942 9.62673 8.62833 6.34423 6.335 4.7259C4.13833 3.17506 3.30083 3.4434 2.75167 3.69256C2.11583 3.9784 2 4.95506 2 5.52839C2 6.10339 2.315 10.2367 2.52 10.9276C3.19917 13.2076 5.61417 13.9776 7.83917 13.7309C4.57917 14.2142 1.68333 15.4017 5.48083 19.6292C9.65833 23.9542 11.2058 18.7017 12 16.0392C12.7942 18.7017 13.7083 23.7651 18.4442 19.6292C22 16.0392 19.4208 14.2142 16.1608 13.7309C18.3858 13.9784 20.8008 13.2076 21.48 10.9276C21.685 10.2376 22 6.10256 22 5.52923C22 4.95423 21.8842 3.97839 21.2483 3.6909C20.6992 3.44256 19.8617 3.17423 17.665 4.72423C15.3717 6.34506 12.9058 9.62756 12 11.3884Z"/>',
        'threads' => '<path d="M16.7051 11.1081C16.543 8.12137 14.911 6.41148 12.1708 6.39398C10.5193 6.3838 9.13771 7.08389 8.29233 8.36664L9.79941 9.40046C10.4334 8.43852 11.4342 8.24015 12.1593 8.24685C13.0616 8.2526 13.7425 8.51494 14.1832 9.02653C14.5038 9.39899 14.7183 9.91367 14.8245 10.5632C14.0246 10.4273 13.1594 10.3855 12.2345 10.4385C9.62919 10.5886 7.95426 12.1081 8.06675 14.2194C8.12384 15.2904 8.65739 16.2118 9.56906 16.8137C10.3399 17.3225 11.3326 17.5713 12.3644 17.515C13.727 17.4403 14.7959 16.9205 15.5416 15.9699C16.1079 15.248 16.4661 14.3125 16.6243 13.1338C17.2737 13.5257 17.7549 14.0414 18.0207 14.6613C18.4726 15.7151 18.499 17.4469 17.086 18.8587C15.848 20.0955 14.3598 20.6306 12.1108 20.6471C9.61601 20.6286 7.72924 19.8285 6.50253 18.269C5.35381 16.8088 4.76014 14.6996 4.73799 12C4.76014 9.30038 5.35381 7.19117 6.50253 5.73092C7.72924 4.17147 9.61597 3.37141 12.1107 3.35287C14.6236 3.37155 16.5433 4.17547 17.8169 5.74244C18.4415 6.51086 18.9123 7.47721 19.2227 8.60394L20.9888 8.13274C20.6125 6.74587 20.0205 5.55078 19.2148 4.55966C17.582 2.55073 15.1816 1.52134 12.1046 1.5C9.03385 1.52127 6.6725 2.55457 5.08614 4.57117C3.67451 6.3657 2.94634 8.87742 2.92188 12.0074C2.94634 15.1373 3.67451 17.6343 5.08614 19.4289C6.6725 21.4454 9.04616 22.4788 12.1169 22.5C14.847 22.4811 16.7713 21.7663 18.3566 20.1825C20.4307 18.1103 20.3682 15.513 19.6846 13.9185C19.1595 12.6943 18.1141 11.7129 16.7051 11.1081ZM12.2669 15.6648C11.125 15.7291 9.93869 15.2166 9.88019 14.1188C9.83684 13.3048 10.4595 12.3966 12.3369 12.2884C13.2594 12.2352 14.1138 12.2976 14.8701 12.463C14.6538 15.1648 13.3848 15.6035 12.2669 15.6648Z"/>',
        'instagram' => '<path d="M12.001 9C10.3436 9 9.00098 10.3431 9.00098 12C9.00098 13.6573 10.3441 15 12.001 15C13.6583 15 15.001 13.6569 15.001 12C15.001 10.3427 13.6579 9 12.001 9ZM12.001 7C14.7614 7 17.001 9.2371 17.001 12C17.001 14.7605 14.7639 17 12.001 17C9.24051 17 7.00098 14.7629 7.00098 12C7.00098 9.23953 9.23808 7 12.001 7ZM18.501 6.74915C18.501 7.43926 17.9402 7.99917 17.251 7.99917C16.5609 7.99917 16.001 7.4384 16.001 6.74915C16.001 6.0599 16.5617 5.5 17.251 5.5C17.9393 5.49913 18.501 6.0599 18.501 6.74915ZM12.001 4C9.5265 4 9.12318 4.00655 7.97227 4.0578C7.18815 4.09461 6.66253 4.20007 6.17416 4.38967C5.74016 4.55799 5.42709 4.75898 5.09352 5.09255C4.75867 5.4274 4.55804 5.73963 4.3904 6.17383C4.20036 6.66332 4.09493 7.18811 4.05878 7.97115C4.00703 9.0752 4.00098 9.46105 4.00098 12C4.00098 14.4745 4.00753 14.8778 4.05877 16.0286C4.0956 16.8124 4.2012 17.3388 4.39034 17.826C4.5591 18.2606 4.7605 18.5744 5.09246 18.9064C5.42863 19.2421 5.74179 19.4434 6.17187 19.6094C6.66619 19.8005 7.19148 19.9061 7.97212 19.9422C9.07618 19.9939 9.46203 20 12.001 20C14.4755 20 14.8788 19.9934 16.0296 19.9422C16.8117 19.9055 17.3385 19.7996 17.827 19.6106C18.2604 19.4423 18.5752 19.2402 18.9074 18.9085C19.2436 18.5718 19.4445 18.2594 19.6107 17.8283C19.8013 17.3358 19.9071 16.8098 19.9432 16.0289C19.9949 14.9248 20.001 14.5389 20.001 12C20.001 9.52552 19.9944 9.12221 19.9432 7.97137C19.9064 7.18906 19.8005 6.66149 19.6113 6.17318C19.4434 5.74038 19.2417 5.42635 18.9084 5.09255C18.573 4.75715 18.2616 4.55693 17.8271 4.38942C17.338 4.19954 16.8124 4.09396 16.0298 4.05781C14.9258 4.00605 14.5399 4 12.001 4ZM12.001 2C14.7176 2 15.0568 2.01 16.1235 2.06C17.1876 2.10917 17.9135 2.2775 18.551 2.525C19.2101 2.77917 19.7668 3.1225 20.3226 3.67833C20.8776 4.23417 21.221 4.7925 21.476 5.45C21.7226 6.08667 21.891 6.81333 21.941 7.8775C21.9885 8.94417 22.001 9.28333 22.001 12C22.001 14.7167 21.991 15.0558 21.941 16.1225C21.8918 17.1867 21.7226 17.9125 21.476 18.55C21.2218 19.2092 20.8776 19.7658 20.3226 20.3217C19.7668 20.8767 19.2076 21.22 18.551 21.475C17.9135 21.7217 17.1876 21.89 16.1235 21.94C15.0568 21.9875 14.7176 22 12.001 22C9.28431 22 8.94514 21.99 7.87848 21.94C6.81431 21.8908 6.08931 21.7217 5.45098 21.475C4.79264 21.2208 4.23514 20.8767 3.67931 20.3217C3.12348 19.7658 2.78098 19.2067 2.52598 18.55C2.27848 17.9125 2.11098 17.1867 2.06098 16.1225C2.01348 15.0558 2.00098 14.7167 2.00098 12C2.00098 9.28333 2.01098 8.94417 2.06098 7.8775C2.11014 6.8125 2.27848 6.0875 2.52598 5.45C2.78014 4.79167 3.12348 4.23417 3.67931 3.67833C4.23514 3.1225 4.79348 2.78 5.45098 2.525C6.08848 2.2775 6.81348 2.11 7.87848 2.06C8.94514 2.0125 9.28431 2 12.001 2Z"/>',
        'tiktok' => '<path d="M16 8.24537V15.5C16 19.0899 13.0899 22 9.5 22C5.91015 22 3 19.0899 3 15.5C3 11.9101 5.91015 9 9.5 9C10.0163 9 10.5185 9.06019 11 9.17393V12.3368C10.5454 12.1208 10.0368 12 9.5 12C7.567 12 6 13.567 6 15.5C6 17.433 7.567 19 9.5 19C11.433 19 13 17.433 13 15.5V2H16C16 4.76142 18.2386 7 21 7V10C19.1081 10 17.3696 9.34328 16 8.24537Z"/>',
        'youtube' => '<path d="M12.2439 4C12.778 4.00294 14.1143 4.01586 15.5341 4.07273L16.0375 4.09468C17.467 4.16236 18.8953 4.27798 19.6037 4.4755C20.5486 4.74095 21.2913 5.5155 21.5423 6.49732C21.942 8.05641 21.992 11.0994 21.9982 11.8358L21.9991 11.9884L21.9991 11.9991C21.9991 11.9991 21.9991 12.0028 21.9991 12.0099L21.9982 12.1625C21.992 12.8989 21.942 15.9419 21.5423 17.501C21.2878 18.4864 20.5451 19.261 19.6037 19.5228C18.8953 19.7203 17.467 19.8359 16.0375 19.9036L15.5341 19.9255C14.1143 19.9824 12.778 19.9953 12.2439 19.9983L12.0095 19.9991L11.9991 19.9991C11.9991 19.9991 11.9956 19.9991 11.9887 19.9991L11.7545 19.9983C10.6241 19.9921 5.89772 19.941 4.39451 19.5228C3.4496 19.2573 2.70692 18.4828 2.45587 17.501C2.0562 15.9419 2.00624 12.8989 2 12.1625V11.8358C2.00624 11.0994 2.0562 8.05641 2.45587 6.49732C2.7104 5.51186 3.45308 4.73732 4.39451 4.4755C5.89772 4.05723 10.6241 4.00622 11.7545 4H12.2439ZM9.99911 8.49914V15.4991L15.9991 11.9991L9.99911 8.49914Z"/>',
        'chevron-left' => '<path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"/>',
        'chevron-right' => '<path d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z"/>',
        'schedule' => '<path d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM13 12H17V14H11V7H13V12Z"/>',
        'dark-mode' => '<path d="M10 7C10 10.866 13.134 14 17 14C18.9584 14 20.729 13.1957 21.9995 11.8995C22 11.933 22 11.9665 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C12.0335 2 12.067 2 12.1005 2.00049C10.8043 3.27098 10 5.04157 10 7ZM4 12C4 16.4183 7.58172 20 12 20C15.0583 20 17.7158 18.2839 19.062 15.7621C18.3945 15.9187 17.7035 16 17 16C12.0294 16 8 11.9706 8 7C8 6.29648 8.08133 5.60547 8.2379 4.938C5.71611 6.28423 4 8.9417 4 12Z"/>',
        'light-mode' => '<path d="M12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C15.3137 6 18 8.68629 18 12C18 15.3137 15.3137 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16ZM11 1H13V4H11V1ZM11 20H13V23H11V20ZM3.51472 4.92893L4.92893 3.51472L7.05025 5.63604L5.63604 7.05025L3.51472 4.92893ZM16.9497 18.364L18.364 16.9497L20.4853 19.0711L19.0711 20.4853L16.9497 18.364ZM19.0711 3.51472L20.4853 4.92893L18.364 7.05025L16.9497 5.63604L19.0711 3.51472ZM5.63604 16.9497L7.05025 18.364L4.92893 20.4853L3.51472 19.0711L5.63604 16.9497ZM23 11V13H20V11H23ZM4 11V13H1V11H4Z"/>',
    );
    $name = sanitize_key( $name );
    $path = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['search'];
    return '<svg class="np-icon np-icon-' . esc_attr( $name ) . ' np-icon-remix" width="' . esc_attr( $size ) . '" height="' . esc_attr( $size ) . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg">' . $path . '</svg>';
}

function newspress_share_button_enabled( $key ) {
    $defaults = array(
        'native' => 1, 'copy' => 1, 'facebook' => 1, 'x' => 1, 'whatsapp' => 1, 'telegram' => 1, 'line' => 1,
        'bluesky' => 0, 'instagram' => 0, 'linkedin' => 0, 'pinterest' => 0, 'tiktok' => 0, 'threads' => 0,
    );
    $key = sanitize_key( $key );
    $default = isset( $defaults[ $key ] ) ? $defaults[ $key ] : 0;
    return (bool) get_theme_mod( 'newspress_share_' . $key, $default );
}

function newspress_get_share_count_html( $post_id = null ) {
    if ( ! get_theme_mod( 'newspress_show_share_count', 1 ) ) {
        return '';
    }

    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $shares = newspress_get_post_shares_count( $post_id );

    return sprintf(
        '<span class="np-share-total" data-np-share-count-wrap><span class="np-share-total-count" data-np-share-count>%1$s</span> <span class="np-share-total-label">%2$s</span></span>',
        esc_html( number_format_i18n( $shares ) ),
        esc_html__( 'Share', 'newspress' )
    );
}

function newspress_share_buttons() {
    $raw_url   = get_permalink();
    $raw_title = get_the_title();
    $url       = rawurlencode( $raw_url );
    $title     = rawurlencode( $raw_title );
    $image     = has_post_thumbnail() ? rawurlencode( get_the_post_thumbnail_url( get_the_ID(), 'large' ) ) : '';

    $links = array(
        'bluesky'   => array( 'label' => 'Bluesky', 'href' => 'https://bsky.app/intent/compose?text=' . $title . '%20' . $url ),
        'facebook'  => array( 'label' => 'Facebook', 'href' => 'https://www.facebook.com/sharer/sharer.php?u=' . $url ),
        'instagram' => array( 'label' => 'Instagram', 'href' => 'https://www.instagram.com/' ),
        'line'      => array( 'label' => 'Line', 'href' => 'https://social-plugins.line.me/lineit/share?url=' . $url ),
        'linkedin'  => array( 'label' => 'LinkedIn', 'href' => 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url ),
        'pinterest' => array( 'label' => 'Pinterest', 'href' => 'https://pinterest.com/pin/create/button/?url=' . $url . ( $image ? '&media=' . $image : '' ) . '&description=' . $title ),
        'telegram'  => array( 'label' => 'Telegram', 'href' => 'https://t.me/share/url?url=' . $url . '&text=' . $title ),
        'tiktok'    => array( 'label' => 'TikTok', 'href' => 'https://www.tiktok.com/' ),
        'threads'   => array( 'label' => 'Threads', 'href' => 'https://www.threads.net/intent/post?text=' . $title . '%20' . $url ),
        'whatsapp'  => array( 'label' => 'WhatsApp', 'href' => 'https://api.whatsapp.com/send?text=' . $title . '%20' . $url ),
        'x'         => array( 'label' => 'X', 'href' => 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title ),
    );

    echo '<div class="np-share" aria-label="' . esc_attr__( 'Share this article', 'newspress' ) . '">';
    $share_count_html = newspress_get_share_count_html();
    echo '<span class="np-share-label">';
    if ( $share_count_html ) {
        echo $share_count_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else {
        echo esc_html__( 'Share', 'newspress' );
    }
    echo '</span>';

    if ( newspress_share_button_enabled( 'native' ) ) {
        echo '<button type="button" class="np-share-btn np-share-native" data-np-share-track="native" data-np-web-share aria-label="' . esc_attr__( 'Share with device', 'newspress' ) . '">' . newspress_svg_icon( 'share', 18 ) . '<span>' . esc_html__( 'Share', 'newspress' ) . '</span></button>';
    }
    if ( newspress_share_button_enabled( 'copy' ) ) {
        echo '<button type="button" class="np-share-btn np-share-copy" data-np-share-track="copy" data-copy-link="' . esc_url( $raw_url ) . '" aria-label="' . esc_attr__( 'Copy link', 'newspress' ) . '">' . newspress_svg_icon( 'link', 18 ) . '<span>' . esc_html__( 'Copy', 'newspress' ) . '</span></button>';
    }

    foreach ( $links as $icon => $data ) {
        if ( ! newspress_share_button_enabled( $icon ) || empty( $data['href'] ) || empty( $data['label'] ) ) {
            continue;
        }
        echo '<a class="np-share-btn np-share-' . esc_attr( $icon ) . '" target="_blank" rel="noopener noreferrer" data-np-share-track="' . esc_attr( $icon ) . '" href="' . esc_url( $data['href'] ) . '" aria-label="' . esc_attr( $data['label'] ) . '">' . newspress_svg_icon( $icon, 18 ) . '<span>' . esc_html( $data['label'] ) . '</span></a>';
    }
    echo '</div>';
}

function newspress_icon_search() {
    return newspress_svg_icon( 'search', 22 );
}

function newspress_mobile_sticky_ad() {
    if ( ! get_theme_mod( 'newspress_enable_mobile_sticky_ad', 0 ) || ! newspress_ads_should_display() ) {
        return;
    }
    $html = trim( (string) get_theme_mod( 'newspress_ad_mobile_sticky', '' ) );
    if ( '' === $html ) {
        return;
    }
    echo '<div class="np-mobile-sticky-ad"><button type="button" class="np-mobile-sticky-ad-close" aria-label="' . esc_attr__( 'Close advertisement', 'newspress' ) . '">×</button>' . newspress_get_safe_ad_code( $html ) . '</div>';
}
add_action( 'wp_footer', 'newspress_mobile_sticky_ad', 20 );

function newspress_get_safe_ad_code( $html ) {
    // Ad code is saved through Customizer by users with edit_theme_options.
    // Output it as stored so AdSense scripts are not stripped for logged-out visitors.
    return (string) $html;
}

/**
 * Print a compact linked primary category badge.
 */
function newspress_category_badge() {
    $categories = get_the_category();
    if ( empty( $categories ) || is_wp_error( $categories ) ) {
        return;
    }
    $category = $categories[0];
    echo '<a class="np-category-badge" href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>';
}


/**
 * Print previous/next post navigation with thumbnails.
 */
function newspress_post_navigation_with_thumbs() {
    $previous = get_previous_post();
    $next     = get_next_post();

    if ( ! $previous && ! $next ) {
        return;
    }

    echo '<nav class="navigation post-navigation np-post-navigation" aria-label="' . esc_attr__( 'Post navigation', 'newspress' ) . '">';
    echo '<div class="nav-links">';

    if ( $previous ) {
        $thumb = has_post_thumbnail( $previous->ID )
            ? get_the_post_thumbnail( $previous->ID, 'thumbnail', array( 'class' => 'np-post-nav-img', 'loading' => 'lazy', 'decoding' => 'async' ) )
            : '<span class="np-post-nav-placeholder">' . newspress_svg_icon( 'chevron-left', 22 ) . '</span>';

        echo '<div class="nav-previous"><a href="' . esc_url( get_permalink( $previous ) ) . '">';
        echo '<span class="np-post-nav-thumb">' . $thumb . '</span>';
        echo '<span class="np-post-nav-body"><span class="np-post-nav-label">' . esc_html__( 'Previous Article', 'newspress' ) . '</span><span class="np-post-nav-title">' . esc_html( get_the_title( $previous ) ) . '</span></span>';
        echo '</a></div>';
    }

    if ( $next ) {
        $thumb = has_post_thumbnail( $next->ID )
            ? get_the_post_thumbnail( $next->ID, 'thumbnail', array( 'class' => 'np-post-nav-img', 'loading' => 'lazy', 'decoding' => 'async' ) )
            : '<span class="np-post-nav-placeholder">' . newspress_svg_icon( 'chevron-right', 22 ) . '</span>';

        echo '<div class="nav-next"><a href="' . esc_url( get_permalink( $next ) ) . '">';
        echo '<span class="np-post-nav-body"><span class="np-post-nav-label">' . esc_html__( 'Next Article', 'newspress' ) . '</span><span class="np-post-nav-title">' . esc_html( get_the_title( $next ) ) . '</span></span>';
        echo '<span class="np-post-nav-thumb">' . $thumb . '</span>';
        echo '</a></div>';
    }

    echo '</div></nav>';
}
