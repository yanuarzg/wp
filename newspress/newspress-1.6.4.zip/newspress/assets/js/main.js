(function(){
  const root=document.documentElement;
  const header=document.querySelector('.np-site-header');
  const progress=document.querySelector('.np-scroll-progress');
  const backTop=document.querySelector('.np-back-to-top');
  const menuToggle=document.querySelector('.np-menu-toggle');
  const nav=document.querySelector('.np-nav');
  const searchToggle=document.querySelector('.np-search-toggle');
  const searchPanel=document.getElementById('np-search-panel');
  const navBackdrop=document.querySelector('.np-nav-backdrop');
  const themeToggle=document.querySelector('.np-theme-toggle');
  const safeStorage={get(key){try{return localStorage.getItem(key);}catch(e){return null;}},set(key,value){try{localStorage.setItem(key,value);}catch(e){}}};
  const icons={dark:'<svg class="np-icon np-icon-dark-mode np-icon-remix" width="21" height="21" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M10 7C10 10.866 13.134 14 17 14C18.9584 14 20.729 13.1957 21.9995 11.8995C22 11.933 22 11.9665 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C12.0335 2 12.067 2 12.1005 2.00049C10.8043 3.27098 10 5.04157 10 7ZM4 12C4 16.4183 7.58172 20 12 20C15.0583 20 17.7158 18.2839 19.062 15.7621C18.3945 15.9187 17.7035 16 17 16C12.0294 16 8 11.9706 8 7C8 6.29648 8.08133 5.60547 8.2379 4.938C5.71611 6.28423 4 8.9417 4 12Z"/></svg>',light:'<svg class="np-icon np-icon-light-mode np-icon-remix" width="21" height="21" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C15.3137 6 18 8.68629 18 12C18 15.3137 15.3137 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16ZM11 1H13V4H11V1ZM11 20H13V23H11V20ZM3.51472 4.92893L4.92893 3.51472L7.05025 5.63604L5.63604 7.05025L3.51472 4.92893ZM16.9497 18.364L18.364 16.9497L20.4853 19.0711L19.0711 20.4853L16.9497 18.364ZM19.0711 3.51472L20.4853 4.92893L18.364 7.05025L16.9497 5.63604L19.0711 3.51472ZM5.63604 16.9497L7.05025 18.364L4.92893 20.4853L3.51472 19.0711L5.63604 16.9497ZM23 11V13H20V11H23ZM4 11V13H1V11H4Z"/></svg>'};
  function onScroll(){const y=window.scrollY||window.pageYOffset;if(header){header.classList.toggle('is-scrolled',y>8);}if(progress){const doc=root.scrollHeight-window.innerHeight;progress.style.width=(doc>0?Math.min(100,(y/doc)*100):0)+'%';}if(backTop){backTop.classList.toggle('is-visible',y>420);}}
  onScroll(); window.addEventListener('scroll',onScroll,{passive:true});
  if(backTop){backTop.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));}
  function closeMenu(){if(nav){nav.classList.remove('is-open');}document.body.classList.remove('np-menu-open');if(menuToggle){menuToggle.setAttribute('aria-expanded','false');}}
  if(menuToggle&&nav){menuToggle.addEventListener('click',()=>{const open=!nav.classList.contains('is-open');nav.classList.toggle('is-open',open);document.body.classList.toggle('np-menu-open',open);menuToggle.setAttribute('aria-expanded',open?'true':'false');});document.addEventListener('click',(event)=>{if(!nav.classList.contains('is-open'))return;if(nav.contains(event.target)||menuToggle.contains(event.target))return;closeMenu();});}
  if(navBackdrop){navBackdrop.addEventListener('click',closeMenu);}
  if(searchToggle&&searchPanel){searchToggle.addEventListener('click',()=>{const hidden=searchPanel.hasAttribute('hidden');if(hidden){searchPanel.removeAttribute('hidden');const input=searchPanel.querySelector('input[type="search"]');if(input){setTimeout(()=>input.focus(),40);}searchToggle.setAttribute('aria-label','Close search');}else{searchPanel.setAttribute('hidden','');searchToggle.setAttribute('aria-label','Open search');}searchToggle.setAttribute('aria-expanded',hidden?'true':'false');});}
  document.addEventListener('keydown',(event)=>{if(event.key!=='Escape')return;closeMenu();if(searchPanel&&!searchPanel.hasAttribute('hidden')){searchPanel.setAttribute('hidden','');if(searchToggle){searchToggle.setAttribute('aria-expanded','false');searchToggle.setAttribute('aria-label','Open search');}}});
  const clocks=[...document.querySelectorAll('[data-clock="1"],[data-clock-mobile="1"]')];
  if(clocks.length){const tick=()=>{const d=new Date();const text=d.toLocaleString(root.lang||'id-ID',{weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});clocks.forEach(el=>{el.textContent=text;});};tick();setInterval(tick,30000);}
  const savedTheme=safeStorage.get('newspress-theme');
  const prefersDark=window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches;
  const defaultTheme=(themeToggle&&themeToggle.dataset.defaultTheme)||'system';
  const initialTheme=savedTheme||(defaultTheme==='dark'?'dark':(defaultTheme==='light'?'light':(prefersDark?'dark':'light')));
  function applyTheme(theme){const dark=theme==='dark';root.setAttribute('data-theme',dark?'dark':'light');if(themeToggle){themeToggle.setAttribute('aria-pressed',dark?'true':'false');themeToggle.innerHTML=dark?icons.light:icons.dark;}}
  applyTheme(initialTheme);
  if(themeToggle){themeToggle.addEventListener('click',()=>{const next=root.getAttribute('data-theme')==='dark'?'light':'dark';safeStorage.set('newspress-theme',next);applyTheme(next);});}
  document.addEventListener('click',async(event)=>{
    const btn=event.target.closest('[data-load-more="1"]');
    if(!btn||btn.disabled||btn.classList.contains('is-loading'))return;
    const endpoint=btn.dataset.endpoint;
    const restEndpoint=btn.dataset.restEndpoint;
    const offset=parseInt(btn.dataset.offset||'0',10);
    const count=parseInt(btn.dataset.count||'5',10);
    const latestLists=[...document.querySelectorAll('.np-latest-list')];
    const target=document.querySelector('.np-latest-list-load-target')||(latestLists.length?latestLists[latestLists.length-1]:null);
    if(!target)return;
    const oldText=btn.textContent;
    btn.classList.add('is-loading');
    btn.disabled=true;
    btn.textContent='Loading...';
    try{
      let payload=null;
      if(endpoint){
        const form=new FormData();
        form.append('action','newspress_load_more');
        form.append('nonce',btn.dataset.nonce||'');
        form.append('offset',String(offset));
        form.append('count',String(count));
        const res=await fetch(endpoint,{method:'POST',body:form,credentials:'same-origin'});
        const json=await res.json();
        payload=json&&json.success?json.data:json;
      }
      if((!payload||typeof payload.html==='undefined')&&restEndpoint){
        const url=new URL(restEndpoint,window.location.href);
        url.searchParams.set('offset',String(offset));
        url.searchParams.set('count',String(count));
        const res=await fetch(url.toString(),{credentials:'same-origin'});
        payload=await res.json();
      }
      if(payload&&payload.html){target.insertAdjacentHTML('beforeend',payload.html);}
      const next=(payload&&payload.nextOffset)?payload.nextOffset:(offset+count);
      btn.dataset.offset=String(next);
      if(!payload||!payload.hasMore){
        btn.disabled=true;
        btn.classList.add('is-disabled');
        btn.textContent='No More Posts';
      }else{
        btn.disabled=false;
        btn.classList.remove('is-disabled');
        btn.textContent='Load More';
      }
    }catch(e){
      btn.disabled=false;
      btn.classList.remove('is-disabled');
      btn.textContent='Try Again';
    }finally{
      btn.classList.remove('is-loading');
    }
  });

  function npFormatNumber(value){try{return new Intl.NumberFormat(root.lang||'id-ID').format(value);}catch(e){return String(value);}}
  function npUpdateShareCount(count){
    const value=parseInt(count,10);
    if(Number.isNaN(value))return;
    document.querySelectorAll('[data-np-share-count]').forEach((el)=>{el.textContent=npFormatNumber(value);});
  }
  async function npTrackShare(service){
    if(!window.newspressData||!newspressData.isSinglePost||!newspressData.postId||!newspressData.shareEndpoint){return;}
    try{
      const res=await fetch(newspressData.shareEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({post_id:newspressData.postId,service:service||'share'}),keepalive:true,credentials:'same-origin'});
      const json=await res.json();
      if(json&&typeof json.count!=='undefined'){npUpdateShareCount(json.count);}
    }catch(e){}
  }
  document.addEventListener('click', async (event)=>{
    const shareBtn=event.target.closest('[data-np-share-track]');
    if(shareBtn){npTrackShare(shareBtn.getAttribute('data-np-share-track')||'share');}
    const nativeBtn=event.target.closest('[data-np-web-share]');
    if(nativeBtn){
      const shareData={title:document.title,url:window.location.href};
      if(navigator.share){try{await navigator.share(shareData);}catch(e){}}
      else{
        const url=window.location.href;
        try{await navigator.clipboard.writeText(url); nativeBtn.classList.add('is-copied'); setTimeout(()=>nativeBtn.classList.remove('is-copied'),1200);}catch(e){window.prompt('Copy link',url);}
      }
    }
    const copyBtn=event.target.closest('[data-copy-link]');
    if(copyBtn){
      const url=copyBtn.getAttribute('data-copy-link')||window.location.href;
      try{await navigator.clipboard.writeText(url); copyBtn.classList.add('is-copied'); setTimeout(()=>copyBtn.classList.remove('is-copied'),1200);}catch(e){window.prompt('Copy link',url);}
    }
    const tocBtn=event.target.closest('.np-toc-toggle');
    if(tocBtn){
      const toc=tocBtn.closest('.np-toc');
      const list=toc&&toc.querySelector('.np-toc-list');
      const open=tocBtn.getAttribute('aria-expanded')!=='false';
      tocBtn.setAttribute('aria-expanded',open?'false':'true');
      if(list){list.hidden=open;}
    }
    const closeAd=event.target.closest('.np-mobile-sticky-ad-close');
    if(closeAd){
      const ad=closeAd.closest('.np-mobile-sticky-ad');
      if(ad){ad.remove();document.body.classList.remove('np-has-mobile-sticky-ad');}
    }
  });
  if(document.querySelector('.np-mobile-sticky-ad')){document.body.classList.add('np-has-mobile-sticky-ad');}

  document.querySelectorAll('[data-np-slider="1"]').forEach((wrap)=>{
    const track=wrap.querySelector('.np-slider-track');
    const slides=[...wrap.querySelectorAll('.np-slide')];
    const dotsWrap=wrap.querySelector('.np-slider-dots');
    const prevBtn=wrap.querySelector('.np-slider-prev');
    const nextBtn=wrap.querySelector('.np-slider-next');
    const total=slides.length;
    if(!track||!total)return;
    let current=0;
    let timer=null;
    const autoplay=wrap.dataset.autoplay==='true';
    const speed=Math.max(1000,parseInt(wrap.dataset.speed||'5000',10)||5000);
    const dots=[];
    if(dotsWrap){
      slides.forEach((_,i)=>{
        const dot=document.createElement('button');
        dot.type='button';
        dot.className='np-slider-dot'+(i===0?' is-active':'');
        dot.setAttribute('aria-label','Slide '+(i+1));
        dot.addEventListener('click',()=>{goTo(i);resetTimer();});
        dotsWrap.appendChild(dot);
        dots.push(dot);
      });
    }
    function goTo(index){
      if(index<0)index=total-1;
      if(index>=total)index=0;
      current=index;
      track.style.transform='translateX(-'+(current*100)+'%)';
      dots.forEach((dot,i)=>dot.classList.toggle('is-active',i===current));
    }
    function next(){goTo(current+1);} function prev(){goTo(current-1);}
    function startTimer(){if(autoplay&&total>1){timer=setInterval(next,speed);}}
    function resetTimer(){if(timer)clearInterval(timer);startTimer();}
    nextBtn&&nextBtn.addEventListener('click',()=>{next();resetTimer();});
    prevBtn&&prevBtn.addEventListener('click',()=>{prev();resetTimer();});
    let startX=0;
    wrap.addEventListener('touchstart',(e)=>{startX=e.touches[0].clientX;},{passive:true});
    wrap.addEventListener('touchend',(e)=>{const diff=startX-e.changedTouches[0].clientX;if(Math.abs(diff)>42){diff>0?next():prev();resetTimer();}},{passive:true});
    wrap.addEventListener('mouseenter',()=>{if(timer)clearInterval(timer);});
    wrap.addEventListener('mouseleave',startTimer);
    startTimer();
  });

})();
(function(){
  if(!window.newspressData||!newspressData.isSinglePost||!newspressData.postId||!newspressData.viewEndpoint){return;}
  var key='np_viewed_'+newspressData.postId;
  try{if(sessionStorage.getItem(key)){return;}sessionStorage.setItem(key,'1');}catch(e){}
  var payload=JSON.stringify({post_id:newspressData.postId});
  if(navigator.sendBeacon){try{var blob=new Blob([payload],{type:'application/json'});navigator.sendBeacon(newspressData.viewEndpoint,blob);return;}catch(e){}}
  try{fetch(newspressData.viewEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:payload,keepalive:true,credentials:'same-origin'});}catch(e){}
})();
