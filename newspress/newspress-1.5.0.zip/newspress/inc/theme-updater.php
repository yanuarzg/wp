<?php
/**
 * GitHub theme updater for NewsPress.
 *
 * Uses a small JSON manifest stored in the NewsPress GitHub update repo.
 *
 * @package NewsPress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'NEWSPRESS_UPDATE_MANIFEST_URL' ) ) {
    define( 'NEWSPRESS_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/yanuarzg/wp/main/newspress/update.json' );
}

if ( ! defined( 'NEWSPRESS_UPDATE_REPO_URL' ) ) {
    define( 'NEWSPRESS_UPDATE_REPO_URL', 'https://github.com/yanuarzg/wp/tree/main/newspress' );
}

function newspress_updater_license_allows_updates() {
    return function_exists( 'newspress_license_can_use_premium_feature' )
        ? newspress_license_can_use_premium_feature()
        : true;
}

function newspress_updater_allowed_url( $url ) {
    $host = wp_parse_url( $url, PHP_URL_HOST );
    if ( ! $host ) {
        return false;
    }

    $allowed_hosts = array(
        'raw.githubusercontent.com',
        'github.com',
        'objects.githubusercontent.com',
    );

    return in_array( strtolower( $host ), $allowed_hosts, true );
}

function newspress_updater_normalize_manifest( $data ) {
    if ( ! is_array( $data ) ) {
        return new WP_Error( 'invalid_manifest', __( 'Invalid NewsPress update manifest.', 'newspress' ) );
    }

    $version      = isset( $data['version'] ) ? sanitize_text_field( $data['version'] ) : '';
    $download_url = isset( $data['download_url'] ) ? esc_url_raw( $data['download_url'] ) : '';
    $details_url  = isset( $data['details_url'] ) ? esc_url_raw( $data['details_url'] ) : NEWSPRESS_UPDATE_REPO_URL;
    $theme        = isset( $data['theme'] ) ? sanitize_key( $data['theme'] ) : 'newspress';

    if ( 'newspress' !== $theme || '' === $version || '' === $download_url ) {
        return new WP_Error( 'incomplete_manifest', __( 'Incomplete NewsPress update manifest.', 'newspress' ) );
    }

    if ( ! newspress_updater_allowed_url( $download_url ) ) {
        return new WP_Error( 'invalid_package_host', __( 'NewsPress update package host is not allowed.', 'newspress' ) );
    }

    $filename = basename( (string) wp_parse_url( $download_url, PHP_URL_PATH ) );
    if ( ! preg_match( '/^newspress-[0-9][0-9A-Za-z._-]*\.zip$/', $filename ) ) {
        return new WP_Error( 'invalid_package_name', __( 'NewsPress update package filename is not valid.', 'newspress' ) );
    }

    $sections = array();
    if ( ! empty( $data['sections'] ) && is_array( $data['sections'] ) ) {
        foreach ( $data['sections'] as $section_key => $section_value ) {
            $sections[ sanitize_key( $section_key ) ] = wp_kses_post( $section_value );
        }
    }

    if ( empty( $sections['description'] ) ) {
        $sections['description'] = __( 'NewsPress theme update from YzTheme GitHub repository.', 'newspress' );
    }

    return array(
        'theme'        => 'newspress',
        'version'      => $version,
        'download_url' => $download_url,
        'details_url'  => $details_url ? $details_url : NEWSPRESS_UPDATE_REPO_URL,
        'requires'     => isset( $data['requires'] ) ? sanitize_text_field( $data['requires'] ) : '',
        'tested'       => isset( $data['tested'] ) ? sanitize_text_field( $data['tested'] ) : '',
        'requires_php' => isset( $data['requires_php'] ) ? sanitize_text_field( $data['requires_php'] ) : '',
        'last_updated' => isset( $data['last_updated'] ) ? sanitize_text_field( $data['last_updated'] ) : '',
        'sections'     => $sections,
    );
}

function newspress_updater_get_manifest( $force = false ) {
    $cache_key = 'newspress_update_manifest';

    if ( ! $force ) {
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
    }

    $manifest_url = esc_url_raw( apply_filters( 'newspress_update_manifest_url', NEWSPRESS_UPDATE_MANIFEST_URL ) );

    if ( ! newspress_updater_allowed_url( $manifest_url ) ) {
        return new WP_Error( 'invalid_manifest_host', __( 'NewsPress update manifest host is not allowed.', 'newspress' ) );
    }

    $response = wp_remote_get( $manifest_url, array(
        'timeout'     => 15,
        'redirection' => 3,
        'headers'     => array(
            'Accept'     => 'application/json',
            'User-Agent' => 'NewsPress/' . ( defined( 'NEWSPRESS_VERSION' ) ? NEWSPRESS_VERSION : 'unknown' ) . '; ' . home_url( '/' ),
        ),
    ) );

    if ( is_wp_error( $response ) ) {
        set_transient( $cache_key, $response, 30 * MINUTE_IN_SECONDS );
        return $response;
    }

    $code = absint( wp_remote_retrieve_response_code( $response ) );
    if ( 200 !== $code ) {
        $error = new WP_Error( 'manifest_http_error', sprintf( 'HTTP %d', $code ) );
        set_transient( $cache_key, $error, 30 * MINUTE_IN_SECONDS );
        return $error;
    }

    $body = wp_remote_retrieve_body( $response );
    $json = json_decode( $body, true );
    $data = newspress_updater_normalize_manifest( $json );

    set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );

    return $data;
}

function newspress_updater_clear_cache() {
    delete_transient( 'newspress_update_manifest' );
}
add_action( 'upgrader_process_complete', 'newspress_updater_clear_cache' );
add_action( 'switch_theme', 'newspress_updater_clear_cache' );

function newspress_updater_check( $transient ) {
    if ( empty( $transient ) || ! is_object( $transient ) ) {
        return $transient;
    }

    if ( ! newspress_updater_license_allows_updates() ) {
        return $transient;
    }

    $stylesheet = get_stylesheet();
    $template   = get_template();

    if ( 'newspress' !== $stylesheet && 'newspress' !== $template ) {
        return $transient;
    }

    $manifest = newspress_updater_get_manifest();
    if ( is_wp_error( $manifest ) || empty( $manifest['version'] ) ) {
        return $transient;
    }

    $current_version = defined( 'NEWSPRESS_VERSION' ) ? NEWSPRESS_VERSION : wp_get_theme( $template )->get( 'Version' );

    if ( version_compare( $manifest['version'], $current_version, '<=' ) ) {
        return $transient;
    }

    $theme_slug = 'newspress' === $template ? $template : $stylesheet;

    $transient->response[ $theme_slug ] = array_filter( array(
        'theme'        => $theme_slug,
        'new_version'  => $manifest['version'],
        'url'          => $manifest['details_url'],
        'package'      => $manifest['download_url'],
        'requires'     => $manifest['requires'],
        'requires_php' => $manifest['requires_php'],
    ) );

    return $transient;
}
add_filter( 'pre_set_site_transient_update_themes', 'newspress_updater_check' );

function newspress_updater_theme_info( $result, $action, $args ) {
    if ( 'theme_information' !== $action || empty( $args->slug ) || 'newspress' !== $args->slug ) {
        return $result;
    }

    $manifest = newspress_updater_get_manifest();
    if ( is_wp_error( $manifest ) ) {
        return $result;
    }

    $theme = wp_get_theme( 'newspress' );
    $info  = new stdClass();

    $info->name          = $theme->get( 'Name' ) ? $theme->get( 'Name' ) : 'NewsPress';
    $info->slug          = 'newspress';
    $info->version       = $manifest['version'];
    $info->author        = $theme->get( 'Author' );
    $info->author_homepage = $theme->get( 'AuthorURI' );
    $info->requires      = $manifest['requires'];
    $info->tested        = $manifest['tested'];
    $info->requires_php  = $manifest['requires_php'];
    $info->last_updated  = $manifest['last_updated'];
    $info->homepage      = $manifest['details_url'];
    $info->download_link = $manifest['download_url'];
    $info->sections      = $manifest['sections'];

    return $info;
}
add_filter( 'themes_api', 'newspress_updater_theme_info', 10, 3 );

function newspress_updater_admin_notice() {
    if ( ! current_user_can( 'update_themes' ) || newspress_updater_license_allows_updates() ) {
        return;
    }

    $url = function_exists( 'newspress_license_admin_url' ) ? newspress_license_admin_url() : admin_url( 'themes.php?page=newspress-license' );

    echo '<div class="notice notice-warning"><p>';
    echo esc_html__( 'NewsPress auto update is locked until the license is activated.', 'newspress' );
    echo ' <a href="' . esc_url( $url ) . '">' . esc_html__( 'Activate license', 'newspress' ) . '</a>';
    echo '</p></div>';
}
add_action( 'admin_notices', 'newspress_updater_admin_notice' );
